; File: main.asm
; Gramado Boot Manager - MIAMI-DOS
; Main entry point for Gramado Boot Manager (MIAMI.BIN)
; Author: Fred Nora (2005+)
;
; Credits: 
;
; + MS-DOS 1.25, 2.0 and 4.0 (MIT License)
;   https://github.com/microsoft/MS-DOS
;
; + MikeOS (BSD License)
;   https://mikeos.sourceforge.net/
;
; Description:
;   This assembly file implements the 16/32-bit boot manager responsible for:
;     - Displaying an interactive boot menu or launching a CLI
;     - Loading the selected bootloader image into memory
;     - Passing disk parameters and boot configuration to the bootloader
;     - Transitioning from 16-bit real mode to 32-bit protected mode
;
; Features:
;   * Simple GUI/menu for boot selection (OK/Cancel dialog)
;   * Embedded command interpreter for non-interactive/server systems
;   * Reads/writes disk configuration sectors
;   * Handles disk geometry and BIOS parameter gathering
;   * Modular: includes for drivers, FS, dialogs, etc.
;
; Build Info:
;   - Loaded at 0x0000:0x8000 (32 KiB image)
;   - Compatible with BIOS and VESA video modes (default: 800x600)
;   - Extensively commented for maintainability and learning
;-----------------------------------------------------------------------------

;------------------------------------------------------------
; Boot Manager Flow:
; 1. Setup segments and stack
; 2. Read disk geometry (heads, sectors, cylinders)
; 3. Read boot configuration sector to select menu or skip
; 4. If menu: show dialog, accept input
; 5. Load bootloader image and jump to it
;------------------------------------------------------------

;-------------------------------------------------
; Table of Contents
;  - Entry point and setup ............. [bm_main]
;  - Disk geometry and config .......... [disk_setup]
;  - Menu logic and dialog ............. [menu_loop]
;  - Bootloader loading ................ [load_bootloader_image]
;  - Data and messages ................. [DATA]
;  - 32-bit includes ................... [bootmanager_main]
;-------------------------------------------------

; What is this?
; This is a boot manager, it is able to load files,
; has a popup window with two buttons and a embedded command interpreter.

; Purpose:
; the main goal of this program is loading the bootloader image into the 
; memory and jump to it passing some parameters.

; #todo
; Create the bootloader METAFILE.
; We need to create a configuration method 
; where we have the option to open the initial window or not.
; It is necessary for non-interactive systems like server machine.
; Maybe we're gonna use a form of metafile in the empy sectors 
; of the disk. This metafile will contain the flag that
; say if we're gonna open the window or not.
; The metafile will have some more options.

;-----------------------------------------------------------------------------
; Video Mode Configuration
;-----------------------------------------------------------------------------
; The default Gramado mode and video mode are set here.
; These can be changed by modifying the following constants:
; ============
; VirtualBox:
; ===============
; Oracle VirtualBox: 0x0112   640x480x24bpp
; Oracle VirtualBox: 0x0115   800x600x24BPP
; Oracle VirtualBox: 0x0118  1024x768x24BPP
; Nvidia GeForce:  
; =================
; GeForce_8400_GS equ 0x06E4  
; GeForce 8400 GS: 0x0115   800x600x32BPP
; The main resolution is 800x600x24.
; The only way to change the resolution for now is 
; changing a global variable in this document.


;---------------------------------------------------
; #importante
; This image was loaded in 0H:8000H.
; It's easier to handle the gdt stuff 
; when the org is in 8000H and the segment is 0H.
; 32768 - 65535 (hex: 8000h - FFFFh)

; #bugbug
; 32KB is the limit for this program?
; We are almost there.

;       +------------+
;       |     ...    | 
;       |------------| 
;       | BLGRAM.BIN | 
;       |   (32bit)  | Boot loader in C.
;       |------------| 0x2000:0x0000
;       |            | 
;       |     ...    | 
;       |            | 
;       |------------| 0x0000:0xFFFF
;       |            | 
;       | MIAMI.BIN  | 
;       | (16/32bit) | The entry point
;  >>>  |------------| 0x0000:0x8000
;       |            |
;       |------------| 0x0000:0x6000
;       |   INITIAL  | Initial stack address.
;       |    STACK   | It goes down.
;       |------------| 
;       |            |
;       |------------| 
;       |  FAT/ROOT  |
;       |------------| 0x0000:0x1000
;       |            |
;       +------------+

; --------------------------------------------------------


;;=====================================
;;    Entry point do Boot Manager    ;;
;;=====================================
;; The gramado mode
;; it will select the video mode.
;; The video mode depends on the gramado mode.
;; See: rmStartGUI on pm.inc
;; This is the default mode.
;; But actually the mode is selected by the user
;; in the command shell.
;; It's like a 'gamemode'.

;-----------------------------------------------------------------------------
; Video Mode Configuration
;-----------------------------------------------------------------------------
; The default Gramado mode and video mode are set here.
; These can be changed by modifying the following constants:
;
; GRAMADO_DEFAULT_MODE:
;   0x00 = 320x200 (jail)
;   0x01 = 640x480 (p1)
;   0x02 = 800x600 (home, default)
;   0x03 = 1024x768 (p2)
;
; G_VIDEO_MODE:
;   0x0112 = 640x480x24bpp (default)
;   0x0115 = 800x600x24bpp
;   0x0118 = 1024x768x24bpp
;
; To change resolution, update the values below.
;-----------------------------------------------------------------------------

;;GRAMADO_DEFAULT_MODE EQU  0x00  ; jail        320x200
;;GRAMADO_DEFAULT_MODE EQU  0x01  ; p1          640x480
GRAMADO_DEFAULT_MODE EQU  0x02  ; home        800x600
;;GRAMADO_DEFAULT_MODE EQU  0x03  ; p2          1024x768
;;GRAMADO_DEFAULT_MODE EQU  0x04  ; castle      ??
;;GRAMADO_DEFAULT_MODE EQU  0x05  ; california  ??
;; ...

;; == Selecting the mode =======================
;; This is the default video mode.
;; we will use this if the 'gramado mode' fail.
;; the video mode depends on the 'gramado mode'
;; Global variables to set the video mode 
;; Well tested modes.
;; ok on qemu.
;; It works on nvidia geforce too, but with 32bpp.

;; 24bpp on qemu
;; G_VIDEO_MODE EQU  0x010F    ;320x200
G_VIDEO_MODE EQU  0x0112    ;640x480
;; G_VIDEO_MODE EQU  0x0115    ;800x600
;; G_VIDEO_MODE EQU  0x0118    ;1024x768
;; ...
;; ======================================


;==============================================================================
; Gramado OS Boot Manager - Main File (main.asm)
;==============================================================================
; Purpose:
;   - Provide a simple boot manager for Gramado OS
;   - Let user select between GUI boot, CLI, or other options
;   - Load the chosen bootloader into memory and transfer control
;
; Control Flow:
;   1. Setup segments/stack
;   2. Get disk geometry and boot config
;   3. Show menu or skip to boot
;   4. Load bootloader and jump
;==============================================================================
; We are in 0000H:8000H
; 32768 - 65535 (hex: 8000h - FFFFh)
; 32KiB space for BM2.BIN
[ORG 0x8000]
[bits 16]

; Entry point.
; This is the entry point for the BM.BIN.
; Jump after the data area.
os_call_vectors:
    jmp bm_main
    ;jmp bm_vector1
    ;jmp bm_vector2
    ;jmp bm_vector3
    ;jmp bm_vector4
    ; ...

; Data
; see: dos16/disk.inc
ROOTDIRSTART EQU  (bootmanagerOEM_ID)
ROOTDIRSIZE  EQU  (bootmanagerOEM_ID+4)
; ...


;-----------------------------------------------------------------------------
; 16-bit Entry Point (bm_main)
;-----------------------------------------------------------------------------
; This is the main entry for the Boot Manager (BM2.BIN).
; - Sets up segment registers and stack (stack at 0x0000:0x6000)
; - Saves disk number (passed in DL)
; /dev/sda - 0x80
; /dev/sdb - 0x81
; /dev/sdc - 0x82
; /dev/sdd - 0x83
; - Initializes data segments and prepares for hardware interrogation
; - Reads disk geometry (heads, sectors/track, cylinders)
; - Writes/reads boot configuration sector to determine boot mode/menu
; IN: 
;     DL = Disl number.
;-----------------------------------------------------------------------------
bm_main:

; Set up registers.
; Adjust segment registers and stack.
; Stack located at 0000:0x6000.
; Code located at 0000:0x8000. 

    cli
    mov ax, 0x0000
    mov ss, ax
    mov sp, 0x6000 
    sti

; The default direction for string operations
; will be 'up' - incrementing address in RAM
    cld

; Data segments in 0x0000.
    mov ax, 0x0000
    mov ds, ax
    mov es, ax

; Save boot disk info for later use
    mov byte [bootmanagerDriveNumber], dl
    mov byte [META$FILE.DISK_NUMBER], dl
    mov byte [DISKINFO16_disk_number], dl

; =====================
; Reset keyboard controller.
; see:
; http://www.ctyme.com/intr/int-16.htm

; Int 16/AX=0601h - AAKEYS - EMPTY KEY-EVENT BUFFER
    ;xor ax, ax
    ;mov ax,  0601h
    ;int 0x16

; Int 16/AH=04h - Tandy 2000 - KEYBOARD - FLUSH KEYBOARD BUFFER
    ;xor ax, ax
    ;mov ah,  04h
    ;int 0x16

; Int 16/AH=25h - HUNTER 16 - RESET KEYBOARD
    ;xor ax, ax
    ;mov ah,  25h
    ;int 0x16

; Int 16/AX=6F09h - HP Vectra EX-BIOS - F16_KBD_RESET - RESET KEYBOARD TO DEFAULTS
    ;xor ax, ax
    ;mov ax,  6F09h
    ;int 0x16

; Int 16/AH=FFh - KEYBOARD - KBUF extensions - ADD KEY TO TAIL OF KEYBOARD BUFFER
    ;xor ax, ax
    ;mov ah,  0xFF
    ;int 0x16

; #test
; Set the keyboard repeat rate to the max
    ;; mov ax, 0x0305
    ;; xor bx,bx 
    ;; int 0x16

; get keystroke
; Int 16/AH=00h - KEYBOARD - GET KEYSTROKE
; On extended keyboards, this function discards any extended keystrokes, 
; returning only when a non-extended keystroke is available. 
    ;xor ax, ax
    ;int 0x16

;-----------------------------------------------------------------------------
; BIOS Disk Parameter Query (INT 13h, AH=08h)
;-----------------------------------------------------------------------------
; Retrieves the disk's physical geometry:
;   - Number of heads
;   - Sectors per track
;   - Number of cylinders
; Results are saved for later use by the bootloader and config routines.
;-----------------------------------------------------------------------------
; Return: CF set on error.
; AH = status (07h).
; CF clear if successful.
; AH = 00h.
; AL = 00h on at least some BIOSes.
; BL = drive type (AT/PS2 floppies only). 
; CH = low eight bits of maximum cylinder number.
; CL = maximum sector number (bits 5-0).
;      high two bits of maximum cylinder number (bits 7-6).
; DH = maximum head number.
; DL = number of drives.

    xor ax, ax
    mov ah, byte 08h
    int 0x13 

; Heads.
; Numero de heads.
; Logical last index of heads = (number_of - 1). 
; (Because index starts with 0).
; Obs: 
; O valor de Heads foi gravado no BPB mas precisar� ser passado a diante
; para uso posterior.

; Heads: DH = highest head number (0-based), add 1 for count
    xor ax, ax
    mov al, dh
    inc ax    ;From 0-based to count.
    ;Number of heads.
    mov word [bootmanagerNumHeads], ax
    mov word [META$FILE.HEADS], ax
    mov word [DISKINFO16_heads], ax

; Sectors Per Track e Cylinders.
; Essas informações apresentam meio truncadas
; O valor do número de cilindros é aprentado
; de forma parcial, uma parte em cada registrador.
; spt:
; bits [5:0] logical last index of sectors per track = number_of 
; (because index starts with 1).
; cyl:
; bits [7:6] [15:8] logical last index of cylinders = number_of - 1 
; (because index starts with 0).
; Sectors Per Track - (SPT).
; "Esconde 2 bits que pertencem a quantidade de setores".
; Obs: 
; O valor de SPT foi gravado no BPB mas precisar 
; ser passado a diante para uso posterior.

; Sectors per Track: Bits 5-0 of CL
    xor eax, eax 
    mov al, cl
    and al, byte 00111111b            ;03Fh
    mov byte [SectorsPerTrack], al    ;BPB (word).
    ;Sectors per track.
    mov ah, 0                                  ; enviamos apenas 'al' 
    mov word [bootmanagerSectorsPerTrack], ax  ; enviamos apenas 'al'
    mov word [META$FILE.SPT], ax
    mov word [DISKINFO16_spt], ax   

; Cylinders
; Obs: 
; O valor de CylinderNumbers foi gravado em variável 
; mas precisar ser passado a diante para uso posterior.

; Cylinders: Combine bits 6-7 of CL and all bits of CH
    xor eax, eax
    mov al, cl           ; Two high bits of cylinder number in bits 6&7.
    and al, 11000000b    ; Mask it.
    shl ax, 2            ; Move them to bits 8&9.
    mov al, ch           ; Rest of the cylinder bits.(low 8 bits)
    inc eax              ; Number is 0-based.
    ; Numero de cilindros do disco.
    mov word [save_cylinder_numbers], ax
    mov word [META$FILE.CYLINDERS], ax
    mov word [DISKINFO16_cylinders], ax


; ===========================================
; #test

;------------------------------------------------------------------------------
; Boot Disk Signature Injection and Identification
;------------------------------------------------------------------------------
; We write a unique signature to a known sector (e.g., sector 4) on the boot disk.
; - The signature is also passed as a parameter to the next boot stage.
; - The next stage (e.g., kernel) can scan all disks/ATA ports for this signature
;   to reliably identify the true boot disk, regardless of BIOS drive number.
;   This is especially useful in systems with multiple disks, VMs, or ambiguous setups.
; - The signature includes fixed values, the disk number, and random bytes for uniqueness.
;------------------------------------------------------------------------------

; Generate a signature.
; Signature: 0xEE, 0xAA, 0xD8, 0x??
; #todo: 
; In the future we're gonna use some random value generated on the fly.
    mov al, 0xEE
    mov byte [CONFIG_BUFFER2 +0], al 
    mov al, 0xAA
    mov byte [CONFIG_BUFFER2 +1], al 
    mov al, 0xD8
    mov byte [CONFIG_BUFFER2 +2], al 
    mov al, [bootmanagerDriveNumber]  ; Disk number from boot manager
    mov byte [CONFIG_BUFFER2 +3], al 
; Get one more byte. Return in AL.
; See: finish.inc
    call get_random_byte
    mov byte [CONFIG_BUFFER2 + 4], al   ; Store the random result in your signature
    call get_random_byte
    mov byte [CONFIG_BUFFER2 + 5], al   ; Store the random result in your signature
    call get_random_byte
    mov byte [CONFIG_BUFFER2 + 6], al   ; Store the random result in your signature
    call get_random_byte
    mov byte [CONFIG_BUFFER2 + 7], al   ; Store the random result in your signature

; Sector 4
; Write disk configuration
    MOV AH, 0x03            ; BIOS write sector function
    MOV AL, 0x01            ; Write 1 sector
    MOV CH, 0x00            ; Cylinder 0
    MOV CL, 0x04            ; Sector 4 (1-based index)
    MOV DH, 0x00            ; Head 0
    MOV DL, [bootmanagerDriveNumber]  ; Disk number from boot manager
    MOV BX, CONFIG_BUFFER2  ; Memory location containing the config data
    INT 0x13                ; Call BIOS disk services

; ===========================================
; #test

;------------------------------------------------------------------------------
; Feature: Skip Boot Menu for Headless Mode
; -----------------------------------------------------------------------------
; If the configuration sector contains the flag to skip the menu ('S'),
; the system will boot directly, enabling headless or automated startup.
; Useful for servers, VMs, and non-interactive environments.
; Configuration is read from sector 2, byte 0:
;   0x4D ('M'): Show menu
;   0x53 ('S'): Skip menu (headless mode)
;------------------------------------------------------------------------------

; Byte 0: 
; Boot Mode (0x4D = Menu, 0x53 = Skip)
; Bytes 1-3: 
; Signature ("CNF")
; Byte 4:    
; Graphics Mode (0x00 = 320x200, 0x01 = 640x480, 0x02 = 800x600)

; Sector 2
; Read boot configuration 
; Read configuration sector to determine if we should skip the menu
    MOV AH, 0x02        ; BIOS read sector function
    MOV AL, 0x01        ; Read 1 sector
    MOV CH, 0x00        ; Cylinder 0
    MOV CL, 0x02        ; Sector 2 (1-based index)
    MOV DH, 0x00        ; Head 0
    MOV DL, [bootmanagerDriveNumber]  ; Disk number
    MOV BX, CONFIG_BUFFER      ; Memory location to store data
    INT 0x13            ; Call BIOS

; Compare first byte
; Evaluate the configuration byte for menu behavior

    ; M?
    MOV AL, [CONFIG_BUFFER]  ; Load first byte of sector into AL
    CMP AL, 0x4D             ; Compare with 'M' (ASCII)
    JE MATCH_FOUND           ; Jump if match found

    ; S?
    MOV AL, [CONFIG_BUFFER]  ; Load first byte of sector into AL
    CMP AL, 0x53             ; Compare with 'S' (ASCII)
    JE SKIP_MENU             ; Jump if match found

; Default option. Open the menu.
NoValidOption:
    jmp menu_loop

SKIP_MENU:
    MOV AH, 0x0E        ; BIOS teletype output function
    MOV AL, 'S'         ; Print 'S' for no match
    INT 0x10
    ; Select boot option.
    ; 1 = Starts system GUI.
    ; 0 = Starts the Boot Manager CLI.
    mov byte [finish_saved_boot_option], 1  ; default option.
    jmp after_menu
    ;JMP $

MATCH_FOUND:
    MOV AH, 0x0E
    MOV AL, 'M'         ; Print 'M' for match found
    INT 0x10
    jmp menu_loop
    ;JMP $

; Allocate 512 bytes for sector storage
DebugBuffer01: db "CONFIG_BUFFER"
CONFIG_BUFFER: 
    TIMES 512 DB 0

; Allocate 512 bytes for sector storage
DebugBuffer02: db "CONFIG_BUFFER2"
CONFIG_BUFFER2: 
    TIMES 512 DB 0

; ++
; ===========================================
menu_loop:

; Draw the background.
    mov ax, msg_topbar       ; Set up the welcome screen
    mov bx, msg_bottombar
    mov cx, 10011111b         ; Colour: white text on light blue
    call os_draw_background

; Draw the dialog box.
; See: dialog.inc
    mov ax, dialog_string_1  ; Ask if user wants app selector or command-line
    mov bx, dialog_string_2
    mov cx, dialog_string_3
    mov dx, 1                ; We want a two-option dialog box (OK or Cancel)
    call os_dialog_box

; Select boot option.
; 1 = Starts system GUI.
; 0 = Starts the Boot Manager CLI.
    mov byte [finish_saved_boot_option], 1  ; default option.

; If OK (option 0) chosen, start app selector
; O right foi selecionado?
; Se não foi o right então carregue a imagem.
; usaremos a opçao de boot default.
; Load the BLGRAM.BIN image.
    cmp ax, 1 
; >> GUI::
    jne near after_menu

; Caso contrario usaremos a opção CLI.
; 1 = Starts system GUI.
; 0 = Starts the Boot Manager CLI.
    mov byte [finish_saved_boot_option], 0
; >> CLI::
    jmp after_menu

    jmp menu_loop
    jmp $
; ===========================================
; --

; Right after the memu
after_menu:

; Clear the screen

    call Window.ClearScreen

;
; Load the BLGRAM.BIN image at 2000H:0000H
;

; Load the BLGRAM.BIN image at 2000H:0000H.
; see: dos16/disk.inc
; This routine starts the system based on a flag,
; that will tell us if we start the system using the graphics mode
; or we start the 32bit embedded shell here in the bm.
; IN:
; ax = pointer to the image name.

load_bootloader_image:

; #todo
; Maybe we can load some 16bit command line routine, 
; capable of launching an application at a given standard address.
; Probably in ORG 100H.
;

; Load image1
; Load the bootloader image

    mov ax, word ImageName_GramadoOSBootloader
    call diskLoadBL

; Load image2
    ;mov ax, word ImageName_GramadoOSBootloader
    ;call diskLoadBL


; Trampoline:
; see: dos16/finish.inc
Trampoline:
    push WORD 0
    push WORD AFTER_DATA 
    retf

; Got to the start of a 16 bit command line routine
;NewTrampoline:
;    push WORD 0
;    push WORD CMDINIT
;    retf


; ================================================
; DATA
; ================================================
; Data for the above code...

    ; Strings for the bars
    msg_topbar     db 'Gramado Boot Manager - (MIAMI-DOS)', 0
    msg_bottombar  db 'ENTER=Confirm', 0

    ; Strings inside the box window
    dialog_string_1  db 'Please select an option:', 0
    dialog_string_2  db '+ [OK] to initialize the system       ', 0
    dialog_string_3  db '+ [Cancel] for command line           ', 0

; Gramado OS bootloader:
; BLGRAM.BIN is a 32bit boot loader for Gramado OS
ImageName_GramadoOSBootloader:
    db "BLGRAM  BIN", 0x0D, 0x0A, 0x00

; Another OS bootloader.
;ImageName_AnotherOSBootloader:
    ;db "12345678BIN", 0x0D, 0x0A, 0x00

;
; == Includes ========
;

; 16bit includes
    %include "dos16/s2metafile.inc"
    %include "dos16/s2header.inc"
    %include "dos16/s2bpb.inc"
    %include "dos16/s2gdt.inc"
    %include "dos16/s2vesa.inc" 
    %include "dos16/s2config16.inc" 
    ;%include "dos16/s2a20.inc"    ; Suspended
    %include "dos16/a20fast.inc"
    %include "dos16/s2lib.inc"
    %include "dos16/s2fat12.inc"
    %include "dos16/s2fat16.inc"
    %include "dos16/s2menu16.inc"
    %include "dos16/s2modes.inc"
    ;%include "dos16/s2detect.inc" ;dead
    ;%include "dos16/lib16.inc" ; dead
    %include "dos16/disk.inc"
    %include "dos16/screen.inc"
    %include "dos16/dialog.inc"
    %include "dos16/finish.inc"
    %include "dos16/int21h.inc"
    %include "dos16/command.inc"
    %include "dos16/pm.inc"


;-----------------------------------------------------------------------------
; 32-bit Protected Mode Definitions & Includes
;-----------------------------------------------------------------------------
; These includes bring in the 32-bit boot manager logic, drivers,
; file systems, and shell. Execution jumps here after protected mode switch.
;-----------------------------------------------------------------------------

[bits 32]
bootmanager_main:

; #ps:
; It follows the order of priority

; 14 - main header for 32bit
; Global definitions
    %include "dos32/header32.inc"

; 13 - Headers for 32bit
    %include "dos32/system.inc"       ; System configuration.
    %include "dos32/init.inc"         ; Initialization configuration.
    %include "dos32/sysvar32.inc"     ; Variáveis do sistema.
    %include "dos32/x8632/gdt32.inc"  ; Gdt
    %include "dos32/x8632/idt32.inc"  ; Idt
    %include "dos32/x8632/ldt32.inc"  ; Ldt
    %include "dos32/x8632/tss32.inc"  ; Tss
    %include "dos32/stacks32.inc"     ; Stacks
    %include "dos32/x8632/ints32.inc"    ; Handles para as interrupções.
    %include "dos32/fs/fat16header.inc"  ; Headers para o sistema de arquivos fat16.

; 12 - User interaction:
; Screen, input, strings and fonts
    %include "dos32/drivers/screen32.inc"  ; Rotinas de screen em 32 bits.
    %include "dos32/drivers/input32.inc"   ; Rotinas de input 2m 32 bits.
    %include "dos32/string32.inc"  ; Rotinas de strings em 32 bits.
    %include "dos32/font32.inc"    ; Fonte.

; 11 - Hardware
    %include "dos32/x8632/cpuinfo.inc"  ; CPU
    %include "dos32/hardware.inc"       ; Hardware
    ; ...

; 10 - IRQs support
    %include "dos32/drivers/timer.inc"     ; Irq 0, Timer.
    %include "dos32/drivers/keyboard.inc"  ; Irq 1, Keyboard.
    %include "dos32/drivers/fdc32.inc"     ; Irq 6, Fdc. (@todo: Suspender o suporte.)
    %include "dos32/drivers/clock.inc"     ; Irq 8, Clock.
    %include "dos32/drivers/hdd32.inc"     ; Irq 14/15, Hdd.
    ; ...

; 9 - Tasks (#ps: No support for tasks in 32bit)
    %include "dos32/tasks32.inc"   

; 8 - ? Undefined

; 7 - setup  
; Arch initialization
    %include "dos32/setup.inc"

; 6 - Disk and filesystem support
    %include "dos32/fs/fat12pm.inc"   ;FAT12 em 32 bits.
    %include "dos32/fs/fat16lib.inc"  ;FAT16 (rotinas).
    %include "dos32/fs/fat16.inc"     ;FAT16 (funçoes principais).
    %include "dos32/fs/ramfs.inc"     ;RamDisk fs.
    %include "dos32/fs/format.inc"    ;Formata.
    %include "dos32/fs/fs32.inc"      ;fs, (gerencia os sistemas de arquivos).

; 5 - File support
    %include "dos32/installer.inc"   ;Instala metafiles em LBAs específicas.
    %include "dos32/fs/file.inc"     ;Operaçoes com aquivos.
    %include "dos32/bootloader.inc"  ;Carrega o Boot Loader (BLGRAM.BIN).

; 4 - Debug system
    %include "dos32/debug.inc"

; 3 - blconfig
; It manages the initialization
    %include "dos32/blconfig.inc"

; 2 - CLI - 32bit protected mode mini-shell
    %include "dos32/shell32/shell.inc"
    %include "dos32/shell32/shcalls.inc"  ;Chamadas dos comandos.
    %include "dos32/shell32/shlib.inc"    ;Lib de funções do Shell.
    %include "dos32/shell32/shmsg.inc"    ;Mensagens e variáveis do Shell.

; 1 - Start
    %include "dos32/start.inc"

; 0 - lib32
; 32-bit workers
    %include "dos32/lib32.inc" 
; ========================================================

;
; Buffer
;

root_buffer:
fat_buffer:
    ; nop

;
; End
;

