// storage.h 
// Storage support for the boot loader.
// Environment: 32bit.
// Created by Fred Nora.

#ifndef __DD_STORAGE_H
#define __DD_STORAGE_H    1


// --------------------------------------------------
// Controller modes

#define STORAGE_CONTROLLER_MODE_SCSI     0x00
#define STORAGE_CONTROLLER_MODE_ATA      0x01
#define STORAGE_CONTROLLER_MODE_RAID     0x04
// Sub-class 05h = ATA Controller with ADMA
#define STORAGE_CONTROLLER_MODE_DMA      0x05   // (USB ?)
#define STORAGE_CONTROLLER_MODE_AHCI     0x06
// 0x08: NVMe (Non-Volatile Memory Express)
#define STORAGE_CONTROLLER_MODE_NVME     0x08
// 0x09: SAS (Serial Attached SCSI)
#define STORAGE_CONTROLLER_MODE_SAS      0x09
#define STORAGE_CONTROLLER_MODE_UNKNOWN  0xFF

// --------------------------------------------------
// Interface standard
// ...


//
// Signature for interface standard.
//

// ATA controller mode handles PATA and SATA interface standards.
// AHCI controller mode handles only SATA interface standards,

// PATA
#define STORAGE_INTERFACE_STANDARD_PATA_SIG1    0
#define STORAGE_INTERFACE_STANDARD_PATA_SIG2    0
#define STORAGE_INTERFACE_STANDARD_PATAPI_SIG1  0x14
#define STORAGE_INTERFACE_STANDARD_PATAPI_SIG2  0xEB

// SATA
#define STORAGE_INTERFACE_STANDARD_SATA_SIG1    0x3C
#define STORAGE_INTERFACE_STANDARD_SATA_SIG2    0xC3
#define STORAGE_INTERFACE_STANDARD_SATAPI_SIG1  0x69
#define STORAGE_INTERFACE_STANDARD_SATAPI_SIG2  0x96


/*
 * struct storage_controller_d
 * ----------------------------------------------------------------------
 * Main controller-level state for the ATA (or compatible) storage controller.
 * This structure tracks high-level information about the detected controller,
 * including what type of storage controller was found (IDE/ATA, RAID, AHCI/SATA, etc.)
 * and whether it has been properly initialized.
 *
 * - 'initialized': Set to nonzero after the controller and all ports (ata_port[4])
 *    are successfully probed and configured.
 * - 'controller_type': Identifies the controller type, such as IDE, RAID, or AHCI,
 *    using one of the __ATA_CONTROLLER, __RAID_CONTROLLER, or __AHCI_CONTROLLER constants.
 *
 * Note: Per-port and per-device information is tracked in ata_port[4] and other structures;
 * storage_controller_d is only for the general controller overview and global state.
 */

struct storage_controller_d
{
// 0: Not initialized; 1: Controller and ports are ready.
    int initialized;
// See __ATA_CONTROLLER, __RAID_CONTROLLER, __AHCI_CONTROLLER, etc.
    uint8_t controller_type;
};
// #todo
// We got to separate the moment we're probing for 
// the controller type and the moment we're initializating one of them.
// #bugbug: 
// At this moment the probing process is happening inside 
// the ata initialization.
extern struct storage_controller_d  StorageController;


struct boot_disk_d
{
    int initialized;
    int controller_type;

    unsigned char bus;
    unsigned char dev;  
    unsigned char fun;

    unsigned long ahci_bar5;
    int boot_port;
};
extern struct boot_disk_d  BootDisk;


// Read LBA from device
int read_lba( unsigned long address, unsigned long lba );
// White LBA on device
int write_lba( unsigned long address, unsigned long lba );

uint32_t storagePCIScanDevice(int class_id);

int storage_initialize(void);

#endif    

