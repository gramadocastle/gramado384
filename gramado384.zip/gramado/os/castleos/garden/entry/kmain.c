// kmain.c
// Main file when the kernel starts up the BSP processor.
// This is the first C file, called after the assembly routines.
// Created by Fred Nora.

// This file contains the I_kmain function,
// called by START in 
// entrance/warden/unit0/x86_64/head_64.asm.
// This file and their folder will be the control panel
// for the initialization routine.
// Please put here data we need.
// fake main.c
// We need a fake KERNEL.BIN ELF file that will be used my the
// boot loader.
// The boot loader will load the fake kernel image before
// setting up the long mode and the paging.


#include <kernel.h>

// see: kmain.h
struct admin_utsname_d  kernel_utsname;


typedef enum {
    KERNEL_SUBSYSTEM_INVALID,
    KERNEL_SUBSYSTEM_KMAIN,  // Main routine
    KERNEL_SUBSYSTEM_DEV,    // Device drivers
    KERNEL_SUBSYSTEM_FS,     // File systems
    KERNEL_SUBSYSTEM_KE,     // Kernel executive
    KERNEL_SUBSYSTEM_MM,     // Memory manager
    KERNEL_SUBSYSTEM_NET,    // Network
    KERNEL_SUBSYSTEM_USER    // User manager. (um)
}kernel_subsystem_t;

// Local
static kernel_subsystem_t __failing_kernel_subsystem = 
    KERNEL_SUBSYSTEM_INVALID;


// Not so important
int gSystemEdition=0;
int gSystemStatus=0;

// See: system.h
struct version_d  *Version;
struct version_info_d  *VersionInfo;
struct system_d  *System;


//
// Initialization :)
//

// Global
//unsigned long gInitializationPhase=0;

// The initialization structure.
// See: ke/kinit.h
struct initialization_d  Initialization;


// Drivers support
// Internal modules support.
int g_driver_ps2keyboard_initialized=FALSE;   //ps2 keyboard
int g_driver_ps2mouse_initialized=FALSE;      //ps2 mouse
int g_driver_video_initialized=FALSE;
int g_driver_apic_initialized=FALSE;
int g_driver_pci_initialized=FALSE;
int g_driver_rtc_initialized=FALSE;
int g_driver_timer_initialized=FALSE;
//...

// Internal modules support.
int g_module_shell_initialized=FALSE;
int g_module_debug_initialized=FALSE;
int g_module_disk_initialized=FALSE;
int g_module_volume_initialized=FALSE;
int g_module_fs_initialized=FALSE;
int g_module_gui_initialized=FALSE;
int g_module_logoff_initialized=FALSE;
int g_module_logon_initialized=FALSE;
int g_module_mm_initialized=FALSE;
int g_module_objectmanager_initialized=FALSE;
int g_module_runtime_initialized=FALSE;
int g_module_uem_initialized=FALSE;             //user environment manager.
//...


//se ele esta inicializado ou nao
int dead_thread_collector_status=0;
// Se e' para usalo ou nao
int dead_thread_collector_flag=0;

//pid_t current_dead_process;
//int current_dead_thread;

//char InitialUserProcessName[32] = "INIT.BIN"

// --------------------------------------
// head_64.asm is given us these two values.
// See: head_64.asm.
unsigned long magic=0;
// Saving the bootblock address passed by the blgram.
// But we already know it. 
// See: BootBlockVA in bootblk.h
unsigned long saved_bootblock_base=0;


// ================================


//
// == Private functions: Prototypes ========
//


// Internal
static void __enter_debug_mode(void);
static void __print_final_messages(void);
static void __setup_utsname(void);

static int __test_initialize_ap_processor(int target_hw_apic_id);
static void panic_at_init(int error_code, kernel_subsystem_t subsystem_id);


// Early init routines
static int earlyinit_SetupBootblock(void);     // [~1]
static void earlyinit_Globals(int arch_type);  // [~2]
static void earlyinit_Serial(void);            // [~3]
static void earlyinit_OutputSupport(void);     // [~4]
static int earlyinit(void);                    // [1.4]

// [1:4]: Arch init
static int archinit(void);

// [1:5]: Decive init
static int deviceinit(void);

// [1:6]: Late init
static int lateinit(void);

static int I_initialize_kernel(int arch_type, int processor_number);


//
// =======================================================
//

static int ap_startup_counter = 0;


// The AP reads its info here when it arrives.
struct welcome_ap_d 
{
    int my_lapic_info_id;
    int bsp_is_waiting;  // TRUE or FALSE
    // ...
};
struct welcome_ap_d  WelcomeAP;


// Real entry point for the AP
extern void asm_AP_entry_point(void);


static void r0_thread00(void);
static void __kmain_setup_ring0_thread(void);

// ======================

static void r0_thread00(void)
{
    while (1){
        asm ("sti");
        asm ("hlt");
    };
}

// Minimal ring 0 thread example
static void __kmain_setup_ring0_thread(void)
{
    unsigned long stack_base = (unsigned long) kmalloc(4096);
    unsigned long entry_point = (unsigned long) &r0_thread00;

// #ps
// Maybe it's mandatory to use the current PID,
// or we can cause some problem with the address space of the thread.
    //pid_t current_pid = (pid_t) get_current_pid();
    pid_t current_pid = 0;  // Kernel process
    if (current_pid < 0 || current_pid >= PROCESS_COUNT_MAX) {
        panic("Failed to get current PID");
    }

    printk("__kmain_setup_ring0_thread:\n");

    struct thread_d *t = 
        create_thread (
            THREAD_TYPE_SYSTEM,  // type
            NULL,                // cgroup
            entry_point,         // initial RIP
            stack_base + 4096,   // initial RSP (top of stack)
            current_pid,         // owner PID (0 for kernel)
            "r0-thread",         // thread name
            RING0                // CPL = 0 (kernel mode)
        );

    if ((void*)t == NULL) {
        printk("Failed to create ring0 thread\n");
        return;
    }

    // Mark it ready to run
    thread_select_for_execution(t);

    // #debug
    //printk("entry_point:  %x \n",entry_point);
    //printk("RING0_RSP: %x \n",(stack_base + 4096));
    //while(1){}
}

void
qf_post_message(
    int msg,
    unsigned long long1,
    unsigned long long2,
    unsigned long long3,
    unsigned long long4,
    unsigned char char1,
    unsigned char char2,
    unsigned char char3,
    unsigned char char4 )
{

// Invalid index
    if ( lapic_info[0].DPC_QUEUE.tail < 0 || 
         lapic_info[0].DPC_QUEUE.tail >= 32)
    {
        lapic_info[0].DPC_QUEUE.tail = 0;
    }

// No mesage in the tail slot
    if (lapic_info[0].DPC_QUEUE.msg[ lapic_info[0].DPC_QUEUE.tail ] == 0)
    {

        lapic_info[0].DPC_QUEUE.msg[ lapic_info[0].DPC_QUEUE.tail ] = (int) msg; // We have a new message

        lapic_info[0].DPC_QUEUE.long1[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned long) long1;
        lapic_info[0].DPC_QUEUE.long2[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned long) long2;
        lapic_info[0].DPC_QUEUE.long3[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned long) long3;
        lapic_info[0].DPC_QUEUE.long4[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned long) long4;

        lapic_info[0].DPC_QUEUE.char1[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned char) char1;
        lapic_info[0].DPC_QUEUE.char2[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned char) char2;
        lapic_info[0].DPC_QUEUE.char3[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned char) char3;
        lapic_info[0].DPC_QUEUE.char4[ lapic_info[0].DPC_QUEUE.tail ] = 
            (unsigned char) char4;

        lapic_info[0].DPC_QUEUE.tail++;
        if (lapic_info[0].DPC_QUEUE.tail >= 32)
            lapic_info[0].DPC_QUEUE.tail = 0;
    }
}

int qf_get_message(void)
{
    int Slot=0;

// Invalid index
    if ( lapic_info[0].DPC_QUEUE.head < 0 || 
         lapic_info[0].DPC_QUEUE.head >= 32)
    {
        lapic_info[0].DPC_QUEUE.head = 0;
    }

// No mesage in the head slot
    if (lapic_info[0].DPC_QUEUE.msg[ lapic_info[0].DPC_QUEUE.head ] <= 0)
    {
        lapic_info[0].DPC_QUEUE.head++;
        if (lapic_info[0].DPC_QUEUE.head >= 32)
            lapic_info[0].DPC_QUEUE.head = 0;

        return (int) -1;  // No message
    }

// Yes, we have a message in this slot
    Slot = (int) lapic_info[0].DPC_QUEUE.head;

//
// Output buffer for the current message
//

// Put the fetched values into the cache.

    lapic_info[0].DPC_QUEUE.cache_msg[0] = 
        (int) lapic_info[0].DPC_QUEUE.msg[ lapic_info[0].DPC_QUEUE.head ];   // Get the message

    lapic_info[0].DPC_QUEUE.cache_longs[0] = 
        (unsigned long) lapic_info[0].DPC_QUEUE.long1[ lapic_info[0].DPC_QUEUE.head ];
    lapic_info[0].DPC_QUEUE.cache_longs[1] = 
        (unsigned long) lapic_info[0].DPC_QUEUE.long2[ lapic_info[0].DPC_QUEUE.head ];
    lapic_info[0].DPC_QUEUE.cache_longs[2] = 
        (unsigned long) lapic_info[0].DPC_QUEUE.long3[ lapic_info[0].DPC_QUEUE.head ];
    lapic_info[0].DPC_QUEUE.cache_longs[3] = 
        (unsigned long) lapic_info[0].DPC_QUEUE.long4[ lapic_info[0].DPC_QUEUE.head ];

    lapic_info[0].DPC_QUEUE.cache_chars[0] = 
        (unsigned char) lapic_info[0].DPC_QUEUE.char1[ lapic_info[0].DPC_QUEUE.head ];
    lapic_info[0].DPC_QUEUE.cache_chars[1] = 
        (unsigned char) lapic_info[0].DPC_QUEUE.char2[ lapic_info[0].DPC_QUEUE.head ];
    lapic_info[0].DPC_QUEUE.cache_chars[2] = 
        (unsigned char) lapic_info[0].DPC_QUEUE.char3[ lapic_info[0].DPC_QUEUE.head ];
    lapic_info[0].DPC_QUEUE.cache_chars[3] = 
        (unsigned char) lapic_info[0].DPC_QUEUE.char4[ lapic_info[0].DPC_QUEUE.head ];

    lapic_info[0].DPC_QUEUE.msg[ lapic_info[0].DPC_QUEUE.head ] = 0;  // No more message in this slot

// Round
    lapic_info[0].DPC_QUEUE.head++;
    if (lapic_info[0].DPC_QUEUE.head >= 32)
        lapic_info[0].DPC_QUEUE.head = 0;

    return (int) Slot;   // Index for the message
}

//-------------------------------------

void welcome_ap_hlt(void)
{
    // #todo
}
void welcome_ap_pause(void)
{
    // #todo
}


/*
 * panic_at_init()
 *
 * Purpose:
 *   Specialized panic routine for system initialization failures.
 *   It is called when a critical error occurs during one of the
 *   initialization levels (earlyinit, mmInitialize, keInitialize, etc.).
 *
 * Behavior:
 *   - Formats the error code into a short string: "INIT PANIC 0x000000NN".
 *   - Delegates to x_panic(), which draws a red rectangle at the top
 *     of the framebuffer and prints the message.
 *   - Halts the system immediately.
 *
 * Context:
 *   - Used before the kernel virtual console is fully initialized.
 *   - Provides a guaranteed visual panic message during early boot.
 *
 * Example:
 *   if (mmInitialize(0) != TRUE)
 *       panic_at_init(Error20_mmPhase0,0);
 */

// Panic during system initialization.
// Builds one-line message with function+phase and error code.
// Logs to serial if available, then halts via x_panic().
static void panic_at_init(int error_code, kernel_subsystem_t subsystem_id)
{
    char msg[64];
    const char *funcname = "init";

    // Record failing subsystem
    // #todo: It will be used in the future.
    __failing_kernel_subsystem = subsystem_id;

    // Map error codes directly here
    switch (error_code) {

    // ---- Main errors ----

    case Error1_I_initialize_kernel:
        funcname = "I_initialize_kernel";
        break;
    case Error2_I_x64CreateKernelProcess:
        funcname = "I_x64CreateKernelProcess";
        break;
    case Error3_I_x64CreateInitialProcess:
        funcname = "I_x64CreateInitialProcess";
        break;
    case Error4_ke_x64ExecuteInitialProcess:
        funcname = "ke_x64ExecuteInitialProcess";
        break;

    // ---- sub-errors for (1) ----

    case Error11_earlyinit:
        funcname = "earlyinit";
        break;
    case Error120_mmPhase0:
        funcname = "mmInitialize0";
        break;
    case Error121_mmPhase1:
        funcname = "mmInitialize1";
        break;
    case Error130_kePhase0:
        funcname = "keInitialize0";
        break;
    case Error131_kePhase1:
        funcname = "keInitialize1";
        break;
    case Error132_kePhase2:
        funcname = "keInitialize2";
        break;
    case Error14_archinit:
        funcname = "archinit";
        break;
    case Error15_deviceinit:
        funcname = "deviceinit";
        break;
    case Error16_lateinit:
        funcname = "lateinit";
        break;

    case Error90_breakpoint:
        funcname = "Breakpoint";
        break;

    default:
        funcname = "init";
        break;
    }

    memset(msg, 0, 64);

    // Build final message: "PANIC: <func> Error: 0xXX"
    ksprintf(msg, "%s Error: 0x%x", funcname, (error_code & 0xFF));

    // Serial log first (if available)
    if (Initialization.is_serial_log_initialized == TRUE) 
    {
        PROGRESS(msg);
        PROGRESS("\n");
    }

    // #todo
    // If network stack is ready, send packet

    // Last call: framebuffer panic worker (hangs system)
    x_panic(msg);
}


static void __enter_debug_mode(void)
{
    if (Initialization.is_serial_log_initialized == TRUE){
        debug_print("__enter_debug_mode:\n");
    }

    if (Initialization.is_console_log_initialized != TRUE)
    {
        if (Initialization.is_serial_log_initialized == TRUE){
            debug_print("__enter_debug_mode: can't use the cirtual console\n");
        }
    }

    // Fatal
    if (Initialization.is_console_log_initialized == TRUE)
    {
        printk("__enter_debug_mode: [PANIC] console log ok\n");
        die();
    }

    die();  // Die with no final message
}

// ===================
// Final messages
static void __print_final_messages(void)
{
    if (Initialization.is_serial_log_initialized == TRUE){
        debug_print("[final message] FAILURE\n");
    }
    if (Initialization.is_console_log_initialized == TRUE){
        printk("init: [final message] FAILURE\n");
    }
}

// utsname
// #todo
// Create the methods for the applications
// to setup this structure and 
// and read the information from it.
// see: sys_uname() in sys.c

static void __setup_utsname(void)
{
    memset(&kernel_utsname, 0, sizeof(struct utsname));

    // OS name
    ksprintf(kernel_utsname.sysname,    OS_NAME);       // "Gramado"
    // Release type (Hypervisor, Server, Desktop, etc.)
    ksprintf(kernel_utsname.release,    RELEASE_NAME);  // "Hypervisor"
    // Version string (from version.h)
    ksprintf(kernel_utsname.version,    VERSION_NAME);  // "0.8"
    // Machine architecture
    ksprintf(kernel_utsname.machine,    MACHINE_NAME);  // "x86_64"
    // Hostname / node name
    ksprintf(kernel_utsname.nodename,   NODE_NAME);     // e.g. "gramado-host"
    // Domain name
    ksprintf(kernel_utsname.domainname, DOMAIN_NAME);   // "DOMAIN-NAME"
}

//
// $
// EARLY INIT
//

// ==============================
// #limitation: No serial debug yet.
// #todo: #bugbug
// We have another BootBlock structure in info.h
static int earlyinit_SetupBootblock(void)
{
// We don't have any print support for now.
// #bugbug
// In head_64.asm we saved the boot address in _saved_bootblock_base.
// But now we're using the address BootBlockVA.

// -------------------------
// base:
// The boot block address. 0x0000000000090000.
// Each entry has 8 bytes.
// virtual = physical.
// #bugbug
// In head_64.asm we saved the boot address in _saved_bootblock_base.
// But now we're using the address BootBlockVA.

// #warning
// This is a version of the boot block with 64bit entries.
// The 64bit entries version was created in the address 0x00090000
// by the bl.bin in head.s. 

    unsigned long *xxxxBootBlock = (unsigned long*) BootBlockVA; 

// -------------------------
// lfb:
// Esse endereço virtual foi configurado pelo bootloader.
// Ainda não configuramos a paginação no kernel.
    unsigned long *fb = (unsigned long *) FRONTBUFFER_VA; 
    fb[0] = 0x00FFFFFF;

// -------------------------
// magic:
// #bugbug: Explain it better.
// We got this number in head_64.asm givem from the boot loader.
    unsigned long bootMagic = 
        (unsigned long) (magic & 0x00000000FFFFFFFF); 

// Check magic
// Paint a white screen if magic is ok.
// Paint a 'colored' screen if magic is not ok.
    register int i=0;
// WHITE
    if (bootMagic == 1234){
        for (i=0; i<320*32; i++){ fb[i] = 0xFFFFFFFFFFFFFFFF; };
    }
// COLORED
    if (bootMagic != 1234){
        for (i=0; i<320*32; i++){ fb[i] = 0xFF00FFFFFFF00FFF; };
        //#debug
        //while(1){}
    }

    //#debug
    //while(1){}

// -------------------------
// info:
// Save the info into a kernel structure
// defined in mm/globals.c.
// See the structure bootblk_d in bootblk.h.
// #bugbug
// Actually this is swrong, because the boot info
// structure is given not only information about 
// the display device, so need to put this structure
// in another document, not in display.h.
// #warning
// This is a version of the boot block with 64bit entries.
// The 64bit entries version was created in the address 0x00090000
// by the bl.bin in head.s. 

// -------------------------
// Display device info
// Boot display device. (VESA)

    bootblk.lfb_pa        = (unsigned long) xxxxBootBlock[bbOffsetLFB_PA];
    bootblk.deviceWidth   = (unsigned long) xxxxBootBlock[bbOffsetX];
    bootblk.deviceHeight  = (unsigned long) xxxxBootBlock[bbOffsetY];
    bootblk.bpp           = (unsigned long) xxxxBootBlock[bbOffsetBPP];

// Saving the resolution info into another place.
// See: kernel.h
    gSavedLFB = (unsigned long) bootblk.lfb_pa;
    gSavedX   = (unsigned long) bootblk.deviceWidth;
    gSavedY   = (unsigned long) bootblk.deviceHeight;
    gSavedBPP = (unsigned long) bootblk.bpp;

// Set up private variables in screen.c
    screenSetSize(gSavedX,gSavedY);

// -------------------------
// Memory info
    bootblk.last_valid_pa = (unsigned long) xxxxBootBlock[bbLastValidPA];
// Last valid physical address.
// Used to get the available physical memory.
    blSavedLastValidAddress = (unsigned long) bootblk.last_valid_pa; 
// Memory size in KB.
    blSavedPhysicalMemoryInKB = 
        (unsigned long) (blSavedLastValidAddress / 1024);

// -------------------------
// System info
    bootblk.gramado_mode = (unsigned long) xxxxBootBlock[bbGramadoMode];
// Gramado mode. (jail, p1, home ...)
// Save global variable.
    current_mode = (unsigned long) bootblk.gramado_mode;

// 48
    bootblk.ide_port_number = (unsigned long) xxxxBootBlock[bb_idePortNumber];


// ---------------------
// #test
// The signature per se.
// Just saving it for now. We're gnna use it later.
    bootblk.disk_signature = 
        (unsigned long) xxxxBootBlock[bbDiskSignature];

// ---------------------
// #note
// Well, we do not have information about the disk.
// + What is the boot disk number given by the BIOS?
// + ...

// Validation
    bootblk.initialized = TRUE;
    return 0;
}

// ==========================
static void earlyinit_Globals(int arch_type)
{
// We don't have any print support for now

    ap_startup_counter = 0;  // Initialize
    WelcomeAP.my_lapic_info_id = -1;  // fail


    // The kernel owns the device driver
    gKernelOwnsDisplay = TRUE;

//
// Backbuffer
//

// Se current addresses

    display_set_backbuffer_pa(NEW_BACKBUFFER_PA);
    display_set_backbuffer_va(NEW_BACKBUFFER_VA);


// Scheduler policies
// Early initialization.
// See: 
// sched.h, sched.c.

    //SchedulerInfo.policy = SCHED_POLICY_RR;
    //SchedulerInfo.flags  = (unsigned long) 0;

    InitThread = NULL;   // thread
    TEInitProcess = NULL;  // thread environment

    // Invalidate
    // IN: pid, core id
    set_current_process(-1, 0);

// IN: tid, lapic id
    SetCurrentTID(-1,0);

// Initializing the global spinlock.
    __spinlock_ipc = TRUE;

// IO Control
    IOControl.useTTY = FALSE;        // Model not implemented yet.
    IOControl.useEventQueue = TRUE;  // The current model.
    IOControl.initialized = TRUE;    // IO system initialized.
    // ...

//
// Presence level
//

// See:
// sched.h, sched.c

    // (timer ticks / fps) = level

    //presence_level = (1000/1000);  //level 1;    // 1000   fps
    //presence_level = (1000/500);   //level 2;    // 500    fps
    //presence_level = (1000/250);   //level 4;    // 250    fps
    //presence_level = (1000/125);   //level 8;    // 125    fps
    //presence_level = (1000/62);    //level 16;   // 62,20  fps
    //presence_level = (1000/25);    //level 32;   // 31,25  fps
    //presence_level = (1000/15);    //level 64;   // 15,625 fps 
    //presence_level = (1000/10);    //level 100;   // 10 fps
    //presence_level = (1000/5);     //level 200;   // 5  fps
    // presence_level = (1000/4);     //level 250;  // 4  fps
    //presence_level = (1000/2);     //level 500;   // 2  fps
    //presence_level = (1000/1);     //level 1000;  // 1  fps

    //set_update_screen_frequency(30);
    set_update_screen_frequency(60);
    //set_update_screen_frequency(120);


//
// #test: 
// Moving some initialization to here in the early stages
//

// smp
    g_smp_initialized = FALSE;
    g_processor_count = 0;

// Profiler
// See: pints.h
// Intel/AMD
// Legacy hardware interrupts (irqs) (legacy pic)
    g_profiler_ints_irq0  = 0;
    g_profiler_ints_irq1  = 0;
    g_profiler_ints_irq2  = 0;
    g_profiler_ints_irq3  = 0;
    g_profiler_ints_irq4  = 0;
    g_profiler_ints_irq5  = 0;
    g_profiler_ints_irq6  = 0;
    g_profiler_ints_irq7  = 0;
    g_profiler_ints_irq8  = 0;
    g_profiler_ints_irq9  = 0;
    g_profiler_ints_irq10 = 0;
    g_profiler_ints_irq11 = 0;
    g_profiler_ints_irq12 = 0;
    g_profiler_ints_irq13 = 0;
    g_profiler_ints_irq14 = 0;
    g_profiler_ints_irq15 = 0;
    // ...

// Global counter for syscalls
    g_profiler_ints_syscall_counter = 0;

// User and group.
    current_user  = 0;
    current_group = 0;

// Security layers.
    current_usersession = (int) 0;

// Process
    foreground_process = (pid_t) 0;
// Global foreground thread
    foreground_thread = (tid_t) 0;

// File system support
// Type=1 | FAT16.
    g_currentvolume_filesystem_type = FS_TYPE_FAT16;
    g_currentvolume_fatbits = (int) 16;

// Redirect printk to serial port during syscalls.
// See: config.h and fslib.c
    if ( CONFIG_PRINTK_TO_SERIAL_DURING_SYSCALLS == 1 ){
        g_redirect_printk_to_serial_during_syscalls = TRUE;
    } else {
        g_redirect_printk_to_serial_during_syscalls = FALSE;
    };

    // ...
}

// =========================
// see: serial.c
static void earlyinit_Serial(void)
{
// We still don't have any print support yet.
// But at the end of this routine we can use the serial debug.

// Driver initialization
// see: serial.c

    int Status=FALSE;
    Status = DDINIT_serial();
    if (Status != TRUE){
        //#bugbug
        //Oh boy!, We can't use the serial debug.
    }
    PROGRESS("Welcome!\n");
    PROGRESS("earlyinit_Serial: Serial debug initialized\n");
}

// ======================
static void earlyinit_OutputSupport(void)
{
// #important: 
// We do not have all the runtime support yet.
// We can't use printk yet.
// We only initialized some console structures,
// not the full support for printk functions.

    //PROGRESS("earlyinit_OutputSupport:\n");

// O refresh ainda não funciona, 
// precisamos calcular se a quantidade mapeada é suficiente.
    refresh_screen_enabled = FALSE;

    //PROGRESS("earlyinit_OutputSupport: wink_initialize_virtual_consoles\n");
    wink_initialize_virtual_consoles();

    //debug_print("earlyinit_OutputSupport: earlyinit_OutputSupport\n");

// #important: 
// We do not have all the runtime support yet.
// We can't use printk yet.
}

// :: Level 1 
// We don't have any print support for now.
// But here is the moment when we initialize the
// serial debug support.
// [1:1]
static int earlyinit(void)
{
// Starting the counter.
    Initialization.current_phase = 0;

// ==================

// Checkpoints
    Initialization.phase1_checkpoint = FALSE;
    Initialization.phase2_checkpoint = FALSE;
    Initialization.phase3_checkpoint = FALSE;

// mm
    Initialization.mm_phase0 = FALSE;
    Initialization.mm_phase1 = FALSE;
    
// ke
    Initialization.ke_phase0 = FALSE;
    Initialization.ke_phase1 = FALSE;
    Initialization.ke_phase2 = FALSE;

// Flags
// We still dont have any log/verbose support.
    Initialization.is_serial_log_initialized = FALSE;
    Initialization.is_console_log_initialized = FALSE;
// The display dirver is not initialized yet,
// but the kernel owns it.
    Initialization.kernel_owns_display_device = TRUE;

// Hack Hack
    VideoBlock.useGui = TRUE;

// first of all
// Getting critical boot information.
    earlyinit_SetupBootblock();

// We do not have serial debug yet
    earlyinit_Globals(0);  // IN: arch_type

// Serial debug support.
// After that routine we can use the serial debug functions.
    earlyinit_Serial();

// Initialize the virtual console structures.
// We do not have all the runtime support yet.
// We can't use printk yet.
// #important: 
// We do not have all the runtime support yet.
// We can't use printk yet.
// We only initialized some console structures,
// not the full support for printk functions.
    earlyinit_OutputSupport();

    return 0;
}

// Initializing the AP processor
static int __test_initialize_ap_processor(int target_hw_apic_id)
{

    // #important:
    // Let the hw id indicates us what is the slot we need to use
    // in lapic info. #ps: 0 is not valid one, because its the bsp.
    unsigned int target_lapic_info_id = target_hw_apic_id;

    // AP base address
    //unsigned char *ap_base = (unsigned char *) 0x00020000; 0x8000;  // AP trampoline base address.
    // AP signature pointer.
    // The AP will change the memory value at this address to
    // 0xA0 when it starts.
    unsigned char *ap_signature_pointer = 
        (unsigned char *) ____DANGER_TRAMPOLINE_CODE_SIGNATURE_AREA;

    // ex: SIPI vector: 0x20000 >> 12 = 0x20, 
    // so you’d send SIPI with vector 0x20.
    unsigned int vector = 
        (unsigned int) (____DANGER_TRAMPOLINE_CODE_BASE >> 12);  // 0x20

    unsigned long BufferSizeInBytes = (2*4096);  // 8KB


    unsigned long *ap_shmm = (unsigned long *) ____DANGER_TRAMPOLINE_SHARED_AREA;


//
// #debug
//

    printk("__test_initialize_ap_processor: hw id=%d | lapicid=%d\n",
        target_hw_apic_id, target_lapic_info_id );


    if (target_hw_apic_id <= 0)
        panic("__test_initialize_ap_processor: Invalid hw id");


// -------------------------------------------------
// Reset shared state (important for 2nd, 3rd... AP)
// -------------------------------------------------
    WelcomeAP.my_lapic_info_id = -1;
    WelcomeAP.bsp_is_waiting   = FALSE;

    ap_signature_pointer[0] = 0;
    ap_signature_pointer[1] = 0;
    ap_shmm[0] = 0;

//
// How many processors?
//

    // No APs processors yet
    // smp_info.nr_ap_running = 0;
    if (CONFIG_INITIALIZE_SECOND_PROCESSOR == 1)
    {
        // (Step 1) Load AP image into memory.
        // Address 0x8000, vector 0x08
        printk("Loading AP image ...\n");

        // #todo: Check return value.
        fsLoadFile ( 
            VOLUME1_FAT_ADDRESS,
            VOLUME1_ROOTDIR_ADDRESS, //sdDE.address,
            FAT16_ROOT_ENTRIES, //512,           // Number of dir entries?
            "APX86   BIN", // AP image file name 
            (unsigned long) ____DANGER_TRAMPOLINE_CODE_BASE, // Address
            BufferSizeInBytes );

        // #important
        // Updating information inside the shared area.
        // See: head_64.asm
        printk("Updating shared area ...\n");
        //ap_shmm[0] = (unsigned long) &AP_kmain; 
        ap_shmm[0] = (unsigned long) &asm_AP_entry_point;  // In Assembly
        ap_shmm[1] = (unsigned long) target_lapic_info_id;   // ← the slot this AP should use
        ap_shmm[2] = 1;   // “BSP is waiting” flag for this launch

        //int target_index = 1;  // array slot for the first AP
        //unsigned int apic_id = lapic_info[target_index].local_id;

        WelcomeAP.bsp_is_waiting = TRUE;  // Waiting for the AP
        //WelcomeAP.my_lapic_info_id = 1;   // AP's slot in lapic_info[] table.
        WelcomeAP.my_lapic_info_id = target_lapic_info_id;


        // #ps: This is correct. The sequence is INIT, STARTUP, STARTUP.


        printk("=== Launching AP %d ===\n", target_hw_apic_id);
        Send_INIT_IPI_Once(target_hw_apic_id, target_lapic_info_id);
        printk("INIT done\n");

        Send_STARTUP_IPI_TwiceEx(target_hw_apic_id, target_lapic_info_id, vector);
        printk("SIPIs done, waiting for signature...\n");


        return 0;   // #test



        // Check if we have at least one AP running.
        // #todo
        // Well, we don't need to stay in this loop waiting for signature.
        // We can check it later after the kernel full initialization.
        while (1){

            if (ap_signature_pointer[0] == 0x64 && 
                ap_signature_pointer[1] == 0x64 )
            {

                printk("kernel: [Sig found] AP is running in 64bit\n");

                // Our first AP processor is running
                //smp_info.nr_ap_running = 1;
                smp_info.nr_ap_running++;

                while (1)
                {
                    asm (" pause \n ");
                    //if (WelcomeAP.bsp_is_waiting != TRUE)
                    if (ap_shmm[2] != 1)
                    {
                        printk("kernel: BSP is not waiting anymore\n");
                        break;
                    }
                };

                //apic_mark_cpu_as_running(1);  // The Core 1 is running now.
                break;
            }
            /*
            if (ap_signature_pointer[0] == 0xA0 && 
                ap_signature_pointer[1] == 0xA0 )
            {
                printk("AP is running in 32bit!\n");
                // Our first AP processor is running
                smp_info.nr_ap_running = 1;
                break;
            }
            */

            if (ap_signature_pointer[0] == 0x63 && 
                ap_signature_pointer[1] == 0x63 )
            {
                panic("kernel: AP Coudn't enter in long mode\n");
            }
        };

        // #debug
        //printk(">>>> breakpoint\n");
        //while(1){asm ("cli"); asm ("hlt");}


        // -------------------------------------------------
        // Clean up shared state so the next AP can use it
        // -------------------------------------------------
        WelcomeAP.my_lapic_info_id = -1;
        WelcomeAP.bsp_is_waiting   = FALSE;

        // Clear signature so the next wait loop works
        ap_signature_pointer[0] = 0;
        ap_signature_pointer[1] = 0;

        // Clear shared parameter area (entry point, etc.)
        ap_shmm[0] = 0;
        // if you later store stack pointer / other params:
        // ap_shmm[1] = 0;
        // ap_shmm[2] = 0;
        // ...

        return 0;

    } // End of CONFIG_INITIALIZE_SECOND_PROCESSOR

    return 0;
}

// [1:4]: Arch init
static int archinit(void)
{
    int ProcessorType = -1;
    int ValidProcessorType = FALSE;
    int smp_status = FALSE;

    const int lapic_info_id = 0;  // BSP

/*
//++
//----------
// #test
// Do we have the file bus.c?
    char *eisa_p;
    int EISA_bus=0;
    eisa_p = 0x000FFFD9;
	if (gramado_strncmp(eisa_p, "EISA", 4) == 0)
		EISA_bus = 1;
    printk("EISA_bus %d\n",EISA_bus);
    while(1){}
//----------
//--
*/

    // 1) - Probe processor type
    ProcessorType = (int) hal_probe_processor_type();

    // #test
    // Testing the function serial_printk(),
    // it sends a formated string to the serial port.
    // #ok, it is working at this part, not in the
    // beginning of the routine.
    serial_printk("archinit: ProcessorType {%d}\n", ProcessorType );

    if ( ProcessorType == Processor_AMD || ProcessorType == Processor_INTEL )
        ValidProcessorType = TRUE;

    if (ValidProcessorType != TRUE)
        goto fail;

    if (CONFIG_NO_SMP == 1){

        // UP mode
        // No SMP support at all
        // #todo

    } else {

        // SMP support
        // But, we are still in the development phase and 
        // some routines are not ready to be tested.
        // For this case we have some extra flags.

        // 2) - SMP initialization
        // Probe for smp support and initialize lapic.
        // see: halls/dev/exec/ke/hal/x86_64/smp/x64smp.c
        smp_status = (int) x64smp_initialization();
        //if (smp_status != TRUE)
            //panic("smp\n");

        // #warning: See the flags in config.h

        // 3) - Enable APIC
        // Lets enable the apic, only if smp is supported.
        // #warning
        // This routine is gonna disable the legacy PIC.
        // see: apic.c
        if (CONFIG_INITIALIZE_APIC == 1)
        {
            // Enable apic and timer
            // Target: BSP cpu
            if (lapic_info[ lapic_info_id ].initialized == TRUE)
                apic_setup_registers( lapic_info_id );  // #todo: id in parameter.
            //printk("kmain: breakpoint on apic_setup_registers()\n");
            //while(1){}
        }

        // 4) - Enable IOAPIC
        // #todo
        // Setup ioapic.
        // see: ioapic.c
        if (CONFIG_INITIALIZE_IOAPIC == 1)
        {
            // #todo
            // Isso configura o timer ...
            // e o timer precisa mudar o vetor 
            // pois 32 ja esta sendo usado pela redirection table.
                
            // This setup a redirection table ...
            // But we need to unmask the devices we wanna use.
            ioapic_initialize();
        }

        // #debug
        // Show cpu info.
        // see: x64info.c
        //x64_info();

        /*
        // 5) - AP startup
        if (CONFIG_INITIALIZE_SECOND_PROCESSOR == 1)
        {
            // Initialize AP processor.
            // #bugbug: g_processor_count if faling
            //if (g_processor_count >= 2)
            if (smp_info.mptable_number_of_processors >= 2)
            {
                smp_info.nr_ap_running = 0;
                __test_initialize_ap_processor(1);  
                //__test_initialize_ap_processor(2); 
                // ...
            }

            // #debug
            //printk(">>>> breakpoint\n");
            //while(1){asm ("cli"); asm ("hlt");}

        } // End of CONFIG_INITIALIZE_SECOND_PROCESSOR
        */
    };

    return TRUE;

fail:
    return FALSE;
}

// [1:5]: Decive init
static int deviceinit(void)
{

// Finalize the initialization creating a device structure
    DDINIT_bldisp();

// IN: phase number = 1.
// Chose the keyboad maps
    ibroker_initialize(1);

    // ================================
        // Early ps/2 initialization.
        // Initializing ps/2 controller.
        // #todo: 
        // Essa inicialização deve ser adiada.
        // deixando para o processo init fazer isso.
        // Chamaremos essa inicialização básica nesse momento.
        // A inicialização completa será chamada pelo processo init.
        // See: i8042.c
        // ================
        // Early initialization
        // Only the keyboard.
        // It is working
        // ================
        // This is the full initialization.
        // #bugbug This is a test yet.
        // It fails in the real machine.

    //PROGRESS(":: Early PS2 initialization\n"); 
    DDINIT_ps2_early_initialization();
    //DDINIT_ps2(); // (full initialization)

// --------------------------
// Initialize the input targets.
// Select the default desired input targets
// See: 
// config.h input.h input.c ibroker.h ibroker.c

/*
   //#delete
    if (CONFIG_INPUT_TARGET_TTY == 1){
        input_enable_this_input_target(INPUT_TARGET_TTY);
    }else{
        input_disable_this_input_target(INPUT_TARGET_TTY);
    };
*/

    if (CONFIG_INPUT_TARGET_STDIN == 1){
        input_enable_this_input_target(INPUT_TARGET_STDIN);
    }else{
        input_disable_this_input_target(INPUT_TARGET_STDIN);
    };

    if (CONFIG_INPUT_TARGET_THREAD_QUEUE == 1){
        input_enable_this_input_target(INPUT_TARGET_THREAD_QUEUE);
    }else{
        input_disable_this_input_target(INPUT_TARGET_THREAD_QUEUE);
    };


    // #todo
    // usb_initialize();

// ...

    return TRUE;  // OK
}

// [1:6]: Late init
static int lateinit(void)
{
    int ok = 0;
    //int UseDebugMode=TRUE;  //#bugbug
    int UseDebugMode=FALSE;

// -------------------------------------
// #test
// Creating the legacy pty maste and pty slave.
// see: pty.c
    // #debug
    //printk (":: Creating legacy ptys\n");

    //PROGRESS(":: PTY\n");
    tty_initialize_legacy_pty();

// -------------------------------------

    // see: user.c
    int uStatus =  FALSE;
    uStatus = (int) user_initialize();
    if (uStatus != TRUE)
        panic("lateinit: on user_initialize()\n");

/*
    // ok
    // Wait for some problem with the AP that was initialized.
    printk("Waiting ...\n");
    while(1){}
*/

/*
    // ok
    // Wait for some problem with the AP that was initialized.
    printk("Waiting ...\n");
    while(1){}
*/

    // ==========================
    // Network support.
    // ?? At this moment we already initialized the e1000 driver.
    // See: net.c
    netInitialize();

/*
    // ok
    // Wait for some problem with the AP that was initialized.
    printk("Waiting ...\n");
    while(1){}
*/

// -------------------------------------
// Setup utsname structure
    __setup_utsname();

// -------------------------------------
// Runlevel switch:
// Enter into the debug console instead of jumping 
// into the init thread.
// ::: Initialization on debug mode
// Initialize the default kernel virtual console.
// It depends on the run_level.
// #bugbug: The interrupts are not initialized,
// it's done via init process?
// See: kgwm.c
    if (UseDebugMode == TRUE){
        __enter_debug_mode();
    }

/*
    // ok
    // Wait for some problem with the AP that was initialized.
    printk("Waiting ...\n");
    while(1){}
*/

// -------------------------------------
// Initialize support for loadable kernel modules.
// See: mod.c 
    int mod_status = -1;
    mod_status = (int) mod_initialize();
    if (mod_status != TRUE)
        panic("lateinit: on mod_initialize()\n");



// -------------------------------------

// #test: Using QF (DPC) via zero gravity, not via AP.
    if ( CONFIG_USE_DPC_VIA_ZEROGRAVITY == 1 )
        lapic_info[0].DPC_QUEUE.on = TRUE;


// -------------------------------------
// #test
// Creatting a ring 0 thread at the end of the kernel initialization.

    // #dangerous
    // Kernel threads are a huge source of problems.
    if (CONFIG_ALLOW_RING0_THREAD_SPAWN == 1){
        //__kmain_setup_ring0_thread();
    }

// -------------------------------------
// Execute the first ring3 process.
// ireq to init thread.
// See: ke.c

/*
    PROGRESS(":: INITIAL PROCESS <<<\n");

    //#debug
    refresh_screen();
    while (1){ 
        asm volatile ("cli");
        asm volatile ("hlt"); 
    };
*/

/*
    ok = (int) ke_x64ExecuteInitialProcess();
    if (ok < 0){
        panic ("lateinit: Couldn't launch init process\n");
        // #todo:
        // Maybe we can call the kernel console for debuging purpose.
        goto fail;
    }
*/

    return TRUE;

fail:
    return FALSE;
}

// Initializes the kernel, create the kernel process,
// launches the forst ring 0 loadable module, creates the ini process,
// the first thread for the init process and execute the firs thread.
// Called by I_kmain during the initialization of the BSP.
// APs have a different initialization routine.
// We don't have any print support yet.
// See: kernel.h, kmain.h
// ==================================
// This is the sequence of functions called by this function.
// Levels:
// + [1]   earlyinit()
// + [2:0] mmInitialize(0)
// + [2:1] mmInitialize(1)
// + [3:0] keInitialize(0)
// + [3:1] keInitialize(1)
// + [3:2] keInitialize(2)
// + [4]   archinit()
// + [5]   deviceinit()
// + [6]   lateinit()
// ==================================

// IN:
// + arch type
// + ?
static int I_initialize_kernel(int arch_type, int processor_number)
{
    int Status = FALSE;

    // BSP
    if (processor_number == 0){

        system_state = SYSTEM_PREINIT;

        // Early init
        // We don't have any print support yet.
        // We initialized the serial debug support, and console structures, 
        // but we still can't use the printk functions.
        // [1:1]
        earlyinit();
        //debug_print("Break point\n");
        //while(1){}
        //wink_update_progress_bar(5);

        // BSP is Booting
        PROGRESS("\n");
        PROGRESS(":: BOOTING BSP\n");
        system_state = SYSTEM_BOOTING;
        // Do we have boot info?
        if (bootblk.initialized != TRUE){
            panic("I_initialize_kernel: bootblk.initialized\n");
        }

        // ...

    // AP kernel initialization
    } else {
        // #todo
    };

//
// mm subsystem
//

    // BSP initialization (mm)
    if (processor_number == 0){

        // -------------------------------
        // Initialize mm phase 0.
        // See: mm.c
        // + Initialize video support.
        // + Inittialize heap support.
        // + Inittialize stack support. 
        // + Initialize memory sizes.
        PROGRESS("[1:2:0] MM PHASE 0 (BSP)\n");
        // [1:2:0]
        Status = (int) mmInitialize(0);
        if (Status != TRUE){
            __failing_kernel_subsystem = KERNEL_SUBSYSTEM_MM;
            if (Initialization.is_serial_log_initialized == TRUE){
                debug_print("I_initialize_kernel: mmInitialize phase 0 fail\n");
            }
            goto fail;
        }
        Initialization.mm_phase0 = TRUE;
        // wink_update_progress_bar(20);

        // -------------------------------
        // Initialize mm phase 1.
        // + Initialize framepoll support.
        // + Initializing the paging infrastructure.
        //   Mapping all the static system areas.
        PROGRESS("[1:2:1] MM PHASE 1 (BSP)\n");
        // [1:2:1]
        Status = (int) mmInitialize(1);
        if (Status != TRUE){
            __failing_kernel_subsystem = KERNEL_SUBSYSTEM_MM;
            if (Initialization.is_serial_log_initialized == TRUE){
                debug_print("I_initialize_kernel: mmInitialize phase 1 fail\n");
            }
            goto fail;
        }
        Initialization.mm_phase1 = TRUE;
        // wink_update_progress_bar(40);

        // Why?
        g_module_runtime_initialized = TRUE;

    // AP initialization (mm)
    } else {
        // #todo
    };

//
// ke subsystem
//

    // BSP initialization (ke)
    if (processor_number == 0){

        // -------------------------------
        // Initialize ke phase 0.
        // See: ke.c
        // + kernel font.
        // + background.
        // + refresh support.
        // + show banner and resolution info.
        // + Check gramado mode and grab data from linker.
        // + Initialize bootloader display device.

        PROGRESS("[1:3:0] KE PHASE 0 (BSP)\n");
        // [1:3:0]
        Status = (int) keInitialize(0);
        if (Status != TRUE)
            panic_at_init(Error130_kePhase0, KERNEL_SUBSYSTEM_KE);
        Initialization.ke_phase0 = TRUE;
        wink_update_progress_bar(50);

        // -------------------------------
        // Initialize ke phase 1.
        // + Calling I_x64main to 
        //   initialize a lot of stuff from the 
        //   current architecture.
        // + PS2 early initialization.

        PROGRESS("[1:3:1] KE PHASE 1 (BSP)\n");
        // [1:3:1]
        Status = (int) keInitialize(1);
        if (Status != TRUE)
            panic_at_init(Error131_kePhase1, KERNEL_SUBSYSTEM_KE);
        Initialization.ke_phase1 = TRUE;
        wink_update_progress_bar(60);

        // -------------------------------
        // Initialize ke phase 2
        // + Initialize background

        PROGRESS("[1:3:2] KE PHASE 2 (BSP)\n");
        // [1:3:2]
        Status = (int) keInitialize(2);
        if (Status != TRUE)
            panic_at_init(Error132_kePhase2, KERNEL_SUBSYSTEM_KE);
        Initialization.ke_phase2 = TRUE;
        wink_update_progress_bar(70);

    // AP initialization (ke)
    } else {
        // #todo
    };


    // BSP initialization (archinit)
    if (processor_number == 0){

        PROGRESS("[1:4] archinit\n");
        // [1:4]
        Status = archinit();
        if (Status != TRUE)
            panic_at_init(Error14_archinit, KERNEL_SUBSYSTEM_KE);
        wink_update_progress_bar(75);

    // AP initialization (archinit)
    } else {
        // #todo
    };


    // BSP initialization (deviceinit)
    if (processor_number == 0){

        PROGRESS("[1:5] deviceinit\n");
        // [1:5]
        Status = deviceinit();
        if (Status != TRUE)
            panic_at_init(Error15_deviceinit, KERNEL_SUBSYSTEM_KMAIN);

        wink_update_progress_bar(80);

    // AP initialization (deviceinit)
    } else {
        // #todo
    };

    // BSP initialization (lateinit)
    if (processor_number == 0){

        if (Status != TRUE)
            goto fail;
        
        PROGRESS("[1:6] lateinit\n");
        // It doesn't return?
        // [1:6]
        Status = (int) lateinit();
        if (Status != TRUE)
            panic_at_init(Error16_lateinit, KERNEL_SUBSYSTEM_KMAIN);
            
        wink_update_progress_bar(85);

        return TRUE;  // The kernel was initialized successfully.

    // AP initialization (lateinit)
    } else {
        //#todo
    };

// BSP Initialization failed
fail:
    system_state = SYSTEM_ABORTED;
    return FALSE;
}

//
// #
// Main function (For BSP processor)
//

// --------------------------------
// Called by START in startup/head_64.asm.
// This is the first function in C.
// We don't have any print support yet.
// See: kernel.h, kmain.h
// #todo: Maybe we can change this name to BSP_kmain()
// [x]
void I_kmain(int arch_type)
{
    int Status = -1;
    const int ProcessorNumber = 0;  // BSP

// #test
// Initialize variable that makes sense only for the BSP,
// Because APs do not call I_kmain.


// System state.
// It guides the initialization.
    system_state = SYSTEM_PREINIT;

// #todo: This is a work in progress.
// See: irql.h

    lapic_info[0].irql = IRQL_NULL;  //#todo: We need the cpu id here.

// Runlevel
// Used by init system.
// See: config.h
    wrappers_set_current_runlevel(CONFIG_CURRENT_RUNLEVEL);

// Product type.
// see: config/product.h
    g_product_type = PRODUCT_TYPE;
    // Status Flag and Edition flag.
    gSystemStatus = 1;
    gSystemEdition = 0;
    __failing_kernel_subsystem = KERNEL_SUBSYSTEM_INVALID;

    has_booted = FALSE;

// No APs processors yet
    smp_info.nr_ap_running = 0;

    config_use_progressbar = FALSE;
    if (CONFIG_USE_PROGRESSBAR == 1){
        config_use_progressbar = TRUE;
    }

// Setup debug mode.
// Enable the usage of the serial debug.
// It is not initialized yet.
// #see: debug.c
    disable_serial_debug();
    if (USE_SERIALDEBUG == 1){
        enable_serial_debug();
    }


//
// Config
//

// Config headless mode.
// In headless mode stdout sends data to the serial port.
    Initialization.headless_mode = FALSE;
    // ...


// Headless mode?
    if (CONFIG_HEADLESS_MODE == 1)
    {
        Initialization.headless_mode = TRUE;
        // ...
    }

// =============================================
// Input authority
// Who will be able to setup the current foreground thread.
// Funtamental for the input system.
// First initialization.
// The main change is when the display server is registered.
// The first change is when the initialization 
// launches the init process.
// See: net.c

    InputAuthority.used = TRUE;
    InputAuthority.magic = 1234;
    InputAuthority.current_authority = AUTH_KERNEL;
    InputAuthority.initialized = TRUE;

// =============================================

    // #hack
    current_arch = CURRENT_ARCH_X86_64;
    //current_arch = (int) arch_type;

// Initialize the kernel
// [1]
    Status = (int) I_initialize_kernel(arch_type, ProcessorNumber);


//
// #bugbug
//

// We are creating the structures for the processes AFTER 
// the initialization of the AP core that is done inside
// the I_initialize_kernel routine. But actually the AP initialization
// needs the structures for the processes.
// Probably the creattion of the processes is considering the
// structures for the core/lapic witch gives us a double problem.

// We are creating the structures for the processes AFTER 
// the initialization of the AP core that is done inside
// the I_initialize_kernel routine. But actually the AP initialization
// needs the structures for the processes.
// Probably the creattion of the processes is considering the
// structures for the core/lapic witch gives us a double problem.

// Let's create the kernel process, the init process and 
// execute the init process.
// See: intake/x64init.c

    // Create the kernel process and load the main ring 0 module
    PROGRESS("[2] Create kernel process\n");
    // [2]
    Status = I_x64CreateKernelProcess();
    if (Status != TRUE){
        PROGRESS ("Couldn't create the Kernel process\n");
        goto L_die;
    }
    wink_update_progress_bar(90);

    // Create the init process and its main thread
    PROGRESS("[3] Create init process\n");
    // [3]
    Status = I_x64CreateInitialProcess();
    if (Status != TRUE){
        debug_print ("Couldn't create the Initial process\n");
        goto L_die;
    }
    wink_update_progress_bar(95);

// ======================================================================


//
// #test
//

// AFTER the creation of the first process
// we can launch the APs ... because maybe they can need the
// kernel process structure

    // 5) - AP startup
    if (CONFIG_INITIALIZE_SECOND_PROCESSOR == 1)
    {

        PROGRESS("\n");
        PROGRESS("I_kmain: Initializize second processor\n");

        // Initialize AP processor.
        // #bugbug: g_processor_count if faling
        //if (g_processor_count >= 2)
        if (smp_info.mptable_number_of_processors >= 2)
        {
            smp_info.nr_ap_running = 0;

            // #bugbug
            // We crashed when trying to launch more than one core.
            // But for onw single core we are able to launch any one of them.

            // #suspended (This is working)
            // IN: hw id
            //__test_initialize_ap_processor(1);   // ok
            //mdelay(40);            
            //__test_initialize_ap_processor(2);  // ok
            //mdelay(40);
            //__test_initialize_ap_processor(3);  // ok
            //mdelay(40);
            // ...

            // #test: This is working
            int cpu_id;
            for ( cpu_id=1; 
                  cpu_id <= smp_info.mptable_number_of_processors; 
                  cpu_id++ )
            {
                __test_initialize_ap_processor(cpu_id);   // ok
                mdelay(40);            
            }
        }

        // #debug
        //printk(">>>> breakpoint\n");
        //while(1){asm ("cli"); asm ("hlt");}

    } // End of CONFIG_INITIALIZE_SECOND_PROCESSOR

// ======================================================================

    // Spawn the main thread for the init process
    // see: ke.c

    if (Status == TRUE){

        PROGRESS("[4] Spawn init thread\n");
        wink_update_progress_bar(100);
        // [4]
        int ok = (int) ke_x64ExecuteInitialProcess(ProcessorNumber);
        if (ok < 0){
            debug_print ("on ke_x64ExecuteInitialProcess()\n");
            //printk ("Couldn't launch init process\n");
            // #todo:
            // Maybe we can call the kernel console for debuging purpose.
            system_state = SYSTEM_ABORTED;
            goto L_die;
        }

// The kernel initialization failed
    } else if (Status == FALSE){
        debug_print ("on I_initialize_kernel()\n");
    }

// Die
// Return to assembly
L_die:
    debug_print("Kernel initialization failed\n");
    if (system_state == SYSTEM_ABORTED){
        debug_print("SYSTEM_ABORTED\n");
    }
    x_panic("Error: 0x02");
}

// #test Not in use
void start_kernel(int arch_type)
{
    I_kmain((int) arch_type);
}

// #test Not in use
// BSP's first function in C.
// It's a wrapper. Maybe it's not called by the assembly code.
// This is here for Linux lovers.
void x86_64_start_kernel(int arch_type)
{
    start_kernel((int) arch_type);
}



//
// End
//

