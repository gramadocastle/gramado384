; Peripheral Hall (Pink)
; hw1.asm
; This file handles the traps for the x86_64 processors.
; Only hw interrupts.
; Created by Fred Nora.

;
; Imports
;

; see: serial.c
; Shared with all the ports for now
extern _DUMMY_SERIAL_HANDLER


;;
;; == Context =================
;;

; See:
; x64cont.c

; #bugbug
; ok, These global variables are used for saving the trap frame
; only by the BSP processor.

extern _contextSS        ; User Mode.
extern _contextRSP       ; User Mode.
extern _contextRFLAGS    ; User Mode.
extern _contextCS        ; User Mode.
extern _contextRIP       ; User Mode.

extern _contextDS
extern _contextES
extern _contextFS  ;?
extern _contextGS  ;?

extern _contextRAX
extern _contextRBX
extern _contextRCX
extern _contextRDX

extern _contextRSI
extern _contextRDI

extern _contextRBP

extern _contextR8
extern _contextR9
extern _contextR10
extern _contextR11
extern _contextR12
extern _contextR13
extern _contextR14
extern _contextR15

extern _contextCPL

; Array.
; Defined in x64cont.c
extern _context_fpu_buffer

; ...

; extern _string_panic


align 16
__hw_fpu_buffer:
    times 512 db 0
align 16

;================================
global _DisableSSE
_DisableSSE:
    push rax
    mov rax, cr0
    or ax, 1 << 3    ;Set TS
    mov cr0, rax
    pop rax
    ret

;================================
global _EnableSSE
_EnableSSE:
    push rax
    mov rax, cr0
    and ax, ~(1 << 3)    ; Clear TS
    mov cr0, rax
    pop rax
    ret

;================================
; Advanced Vector Extensions is a SIMD (Single Instruction, Multiple Data) 
; instruction set introduced by Intel in 2011.
; AVX is enabled by setting bit 2 of the XCR0 register. 
; Bit 1 of XCR0 must also be set (indicating SSE support).
; See: 
; https://wiki.osdev.org/SSE
; https://en.wikipedia.org/wiki/AVX-512
global _x64_enable_avx
_x64_enable_avx:

    push rax
    push rcx
    push rdx

    xor rcx, rcx
    xgetbv     ; Load XCR0 register
    or eax, 7  ; Set AVX, SSE, X87 bits
    xsetbv     ; Save back to XCR0

    pop rdx
    pop rcx
    pop rax
    ret


; #todo: Move to unit 2
; ---------------------------------------------------------------------
; reboot -- Reboot the computer
hw_reboot:
	in al, 0x64
	test al, 00000010b		; Wait for an empty Input Buffer
	jne hw_reboot
	mov al, 0xFE
	out 0x64, al			; Send the reboot call to the keyboard controller
	jmp hw_reboot
; ----------------------------------------------------------------------


;================================
; PeripheralHall_irq0:
;   IRQ0 - PIT timer interrupt (vector 32).
;   Captures CPU context (handling R0/R3 stack-frame differences),
;   calls the C-level timer handler, restores state, and releases.
;   EOI is expected in irq0_release (hw2.asm).
;================================

extern _gszLastStackFrame

; _gszLastStackFrame is needed.
; We need to know how many elements was poped in the last
; timer interrupt.
;This dual strategy ensures you never mismatch:
; Ring 0 → Ring 0 resumes: 3 elements.
; Ring 3 → Ring 3 resumes: 5 elements.
; Ring 0 → Ring 3 switch: push 5 from the new thread’s context.
; Ring 3 → Ring 0 switch: push 3 from the new thread’s context.

; Error codes: 
; PIT IRQ has no error code, but remember to handle exceptions 
; that push an error code (GP, PF, DF) with a variant entry stub.
;;=====================================================
;;  ## TIMER ##
;;=====================================================
;; PeripheralHall_irq0: 
;; IRQ 0. 
;; Timer interrupt handler
;; See:
;; pit.c
;; disp/ts.c
;;
;================================
extern _irq0_TIMER
; Capture context
align 4  
global PeripheralHall_irq0
PeripheralHall_irq0:
; Maskable interrupt

; #ps: Actually we dont need this in hw interrupts,
; because all the IDT entries are using 8E00, present, dpl=0, 
; interrupt gate, where the interrupts are disabled by default.

    cli

    ; #todo:
    ; This is because we need to know the
    ; information about the current core.
    ; gs is the segment and the base address contain structured data.

    ; swapgs

; No caso do dispatcher lançar uma nova thread,
; então ele deve acionar enviar um EIO.
    ; mov dword [_irq0PendingEOI], 1

;; == Save context ====================
    
    ; Stack frame. (all double)
    pop qword [_contextRIP]     ; rip
    pop qword [_contextCS]      ; cs  (R3)
    pop qword [_contextRFLAGS]  ; rflags

.TestCPL:

    push rax
    mov rax, qword [_contextCS]  ; Get CPL
    and rax, 3                   ; Select 2 bits

    ; This is a ring 0 thread
    cmp rax, 0
    je .R0Thread

    ; This is a ring 3 thread
    cmp rax, 3
    je .R3Thread 

; Fail: Fatal error
; .InvalidCPL:
    pop rax
    jmp .InvalidThread

; ------------------------------------------------
; Stackframe for ring 0 has only 3 elements
.R0Thread:
    pop rax
    mov qword [_gszLastStackFrame], 3  ; 3 elements
    mov qword [_contextRSP], rsp   ; save current kernel stack pointer
    mov qword [_contextSS], ss     ; save kernel stack segment
    jmp .AfterStackFrame

; ------------------------------------------------
; Stack frame for ring 3 has 5 elements
.R3Thread:
    pop rax
    mov qword [_gszLastStackFrame], 5  ; 5 elements
    pop qword [_contextRSP]     ; rsp
    pop qword [_contextSS]      ; ss
    jmp .AfterStackFrame

; ------------------------------------------------
; Capture the context
.AfterStackFrame:
    mov qword [_contextRDX], rdx 
    mov qword [_contextRCX], rcx 
    mov qword [_contextRBX], rbx 
    mov qword [_contextRAX], rax
     
    mov qword [_contextRBP], rbp
 
    mov qword [_contextRDI], rdi 
    mov qword [_contextRSI], rsi 

    mov qword [_contextR8], r8
    mov qword [_contextR9], r9
    mov qword [_contextR10], r10
    mov qword [_contextR11], r11
    mov qword [_contextR12], r12
    mov qword [_contextR13], r13
    mov qword [_contextR14], r14
    mov qword [_contextR15], r15

; Data segments
    xor rax, rax
; FS/GS bases come from MSRs (IA32_FS_BASE, IA32_GS_BASE), 
; not the selector’s descriptor base. 
; Moving a selector into fs/gs does not set their base; 
; you need wrmsr if you use per-CPU or TLS bases. 
; Saving/restoring just the selectors may not preserve 
; what you expect.
    mov ax, gs
    mov word [_contextGS], ax
    mov ax, fs
    mov word [_contextFS], ax
; DS and ES are largely ignored for data addressing in long mode.
; Loading them is typically redundant.
    mov ax, es
    mov word [_contextES], ax
    mov ax, ds
    mov word [_contextDS], ax

; FPU
; See:
; https://wiki.osdev.org/SSE
    fxsave [_context_fpu_buffer]

; #todo
; Media, float pointers, debug.
; #important:
; We are using the kernel segment registers.
; Kernel data segments and stack.
; #bugbug: sempre a mesma pilha?
; Que pilha as interrupçoes de softwar estao usando?

;
; Calls
;

; cpl
; Get the first 2 bits of cs.
; see: x64cont.c
    mov rax, qword [_contextCS]
    and rax, 3
    mov [_contextCPL], rax

; Timer and taskswitching
; See: pit.c
; #ps: This service was implemented in pit.c, 
; but it doesn't need to be this way. Because the interrupt that 
; calls this interrupt handler can be other than pit, 
; it can be local apic timer or hpet for example.

    mov r10, qword _irq0_TIMER
    call r10

; Check the return value.
; 0x80 is the flag that tells us to skip the cr3 reload.
; bit 7: Skip CR3 reload (same thread continues)

    and rax, 0x80     ; isolate the skip bit
    cmp rax, 0x80
    je .SkipCR3Reload

    mov rax, cr3
    IODELAY
    mov cr3, rax

.SkipCR3Reload:

; FPU
    fxrstor [_context_fpu_buffer]

; Release a bandit.
; see: hw2.asm
    jmp irq0_release

; --------------------------------------
.InvalidThread:
    cli
    hlt
    jmp .InvalidThread
; --------------------------------------

;========================================
; PeripheralHall_irq1:
;     IRQ 1 - Keyboard.
; See:
; keyboard.c
;
extern _xxxxIRQ1_DEBUG_MESSAGE
extern _irq1_KEYBOARD
; Capture context
align 4  
global PeripheralHall_irq1  
PeripheralHall_irq1:
; Maskable interrupt

    ; #bugbug
    ; #todo:
    ; We also need to be careful if the interrupted thread 
    ; is a ring 0 thread or a ring 3 thread, because the stack frame is different.

    ;cli

; No caso do dispatcher lançar uma nova thread,
; então ele deve acionar enviar um EIO.

    ; mov dword [_irq1PendingEOI], 1

;; == Save context ====================
    

; Pop only the common part of the stack frame, 
; which is the same for both ring 0 and ring 3 threads.

    pop qword [_contextRIP]     ; rip
    pop qword [_contextCS]      ; cs (R3)
    pop qword [_contextRFLAGS]  ; rflags

.TestCPL:

    push rax
    mov rax, qword [_contextCS]  ; Get CPL
    and rax, 3                   ; Select 2 bits

    cmp rax, 0
    je .R0Thread
    cmp rax, 3
    je .R3Thread 
    pop rax
    jmp .InvalidThread

; ------------------------------------------------
; Stackframe for ring 0 has only 3 elements.
.R0Thread:
    ; int 3 ;#debug: A ring 0 thread was interrupted by the keyboard interrupt. 
    pop rax
    mov qword [_contextRSP], rsp   ; save current kernel stack pointer
    mov qword [_contextSS], ss     ; save kernel stack segment
    ;mov qword [_gszLastStackFrame], 3  ; 3 elements
    jmp .AfterStackFrame

; ------------------------------------------------
; Stack frame for ring 3 has 5 elements.
.R3Thread:
    pop rax
    pop qword [_contextRSP]     ; rsp
    pop qword [_contextSS]      ; ss
    ;mov qword [_gszLastStackFrame], 5  ; 5 elements
    jmp .AfterStackFrame

; ------------------------------------------------
.AfterStackFrame:

    mov qword [_contextRDX], rdx 
    mov qword [_contextRCX], rcx 
    mov qword [_contextRBX], rbx 
    mov qword [_contextRAX], rax
     
    mov qword [_contextRBP], rbp
 
    mov qword [_contextRDI], rdi 
    mov qword [_contextRSI], rsi 

    mov qword [_contextR8], r8
    mov qword [_contextR9], r9
    mov qword [_contextR10], r10
    mov qword [_contextR11], r11
    mov qword [_contextR12], r12
    mov qword [_contextR13], r13
    mov qword [_contextR14], r14
    mov qword [_contextR15], r15


; Data segments
    xor rax, rax
    mov ax, gs
    mov word [_contextGS], ax
    mov ax, fs
    mov word [_contextFS], ax
    mov ax, es
    mov word [_contextES], ax
    mov ax, ds
    mov word [_contextDS], ax

; FPU
; See:
; https://wiki.osdev.org/SSE
    fxsave [_context_fpu_buffer]

; #todo
; Media, float pointers, debug.
; #important:
; We are using the kernel segment registers.
; Kernel data segments and stack.
; #bugbug: sempre a mesma pilha?
; Que pilha as interrupçoes de softwar estao usando?

;
; Calls
;

; cpl
; Get the first 2 bits of cs.
; see: x64cont.c
    mov rax, qword [_contextCS]  ;(R3)
    and rax, 3
    mov qword [_contextCPL], rax

; See: keyboard.c
    mov r10, qword _irq1_KEYBOARD
    call r10

; FPU
    fxrstor [_context_fpu_buffer]

; Release a bandit.

; 64bit
; This is a 64bit pointer to the pml4 table.

; #bugbug
; Não precisamos fazer refresh em todo tick,
; somente quando houver troca de tarefa.

    mov RAX, CR3  
    IODELAY 
    mov CR3, RAX  

; Wait TLB.
    ;IODELAY 
;
; == Restore context ====================
;

    ; Segments
    xor rax, rax
    mov ax, word [_contextDS]
    mov ds, ax
    mov ax, word [_contextES]
    mov es, ax
    mov ax, word [_contextFS]
    mov fs, ax
    mov ax, word [_contextGS]
    mov gs, ax

    mov r15, qword [_contextR15]
    mov r14, qword [_contextR14]
    mov r13, qword [_contextR13]
    mov r12, qword [_contextR12]
    mov r11, qword [_contextR11]
    mov r10, qword [_contextR10]
    mov r9,  qword [_contextR9]
    mov r8,  qword [_contextR8]

    mov rsi, qword [_contextRSI] 
    mov rdi, qword [_contextRDI] 
    
    mov rbp, qword [_contextRBP] 
    
    mov rax, qword [_contextRAX] 
    mov rbx, qword [_contextRBX] 
    mov rcx, qword [_contextRCX] 
    mov rdx, qword [_contextRDX] 


; --------------------------------------------
; Stack frame saga

    ;----------------------------------------
    ; Now rebuild the hardware-saved stack frame.
    ; The appropriate frame is chosen based on _contextCPL.
    ;----------------------------------------

    mov rax, qword [_contextCS]   ; Get CPL
    and rax, 3                    ; Select 2 bits

    ; Compare
    cmp rax, 0
    je .restore_kernel_mode    ; It is a ring 0 thread
    cmp rax, 3
    je .restore_user_mode      ; It is a ring 3 thread

    ; #bugbug
    ; We need a panic here.
    jmp .InvalidThread

; ------------------------------------------------
; Stack frame. (all double)
; Stackframe for ring 0 has only 3 elements.
.restore_kernel_mode:
    ; Stack frame for ring 0 with 3 elements, 
    ; because the last thread was ring 0.
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip
    jmp .stackframe_done

; ------------------------------------------------
; Stack frame. (all double)
; Stack frame for ring 3 has 5 elements.
.restore_user_mode:
    ; Stack frame for ring 3 has 5 elements.
    push qword [_contextSS]      ; ss
    push qword [_contextRSP]     ; rsp
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip


; ------------------------------------------------
.stackframe_done:

    ; send EOI to XT keyboard
    ;in      al, 061h
    ;mov     ah, al
    ;or      al, 080h
    ;out     061h, al
    ;mov     al, ah
    ;out     061h, al

; EOI - Only the first PIC.
; #remember: In the case os SMP. It was already done in C.

    xor rax, rax 
    MOV AL, 020h
    OUT 020h, AL
    ;IODELAY  

    ;; variável usada pelo dispatcher.
    ;mov dword [_irq1PendingEOI], 0

    ; Acumulator
    mov rax, qword [_contextRAX]

; #bugbug
; We do NOT need the 'sti'. 
; The flags in the 'eflags' will reenable it.

    ;sti
    iretq
;;===========================
; --------------------------------------
.InvalidThread:
    cli
    hlt
    jmp .InvalidThread
; --------------------------------------



;=======================================================
; IRQ 3 - serial port controller for serial port 2 
; (shared with serial port 4, if present)
; See: serial.c
;extern _serial2_handler
;extern _serial4_handler
; Capture context
align 4  
global _irq3
_irq3:
; Maskable interrupt

    ; #todo
    ; Work on this routine to make it kinda like the irq0.

    ;cli
    
    ;pushad
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs

    ;call _serial2_handler
    ;call _serial4_handler
    ; Using this for now because we need the EOI in MP mode.
    call _DUMMY_SERIAL_HANDLER

; EOI - Only the first PIC.
    mov al, 0x20
    out 0x20, al
    ;IODELAY  
    
    ;popad
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq
    
;; ==========================================


;====================================================
; IRQ 4 - serial port controller for serial port 1 
;(shared with serial port 3, if present)
; See: serial.c
;extern _serial1_handler
;extern _serial3_handler
; Capture context
align 4  
global _irq4
_irq4:
; Maskable interrupt

    ; #todo
    ; Work on this routine to make it kinda like the irq0.

    ;cli
    ;pushad
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs

    ;call _serial1_handler
    ;call _serial3_handler
    ; Using this for now because we need the EOI in MP mode.
    call _DUMMY_SERIAL_HANDLER

; EOI - Only the first PIC.
    mov al, 0x20
    out 0x20, al
    ;IODELAY  
    
    ;popad
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq
;================================

;--------------
; IRQ 5 - parallel port 2 and 3  or  sound card
;_irq5:
;    iretd

;--------------
; IRQ 6  floppy disk controller
;_irq6:
;    iretd

;===================================================
;IRQ 7 parallel port 1. 
; It is used for printers 
; or for any parallel port 
; if a printer is not present. It can also be potentially 
; be shared with a secondary sound card with careful 
; management of the port.
;; The correct way to handle an IRQ 7 is to first check the master PIC 
;; chip's ISR to see if the IRQ is a spurious IRQ or a real IRQ. 
;; If it is a real IRQ then it is treated the same as any other real 
;; IRQ. If it is a spurious IRQ then you ignore it 
;; (and do not send the EOI). 
; Capture context
align 4  
global _irq7
_irq7:
; Maskable interrupt

    ; #todo
    ; Work on this routine to make it kinda like the irq0.

    ;cli
    ;pushad
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs

; ++
; ================================================
; #test
; Testing the spurious interrupt management.

    xor rax, rax
    mov  al, 03h                ; PIC.OCW3 set function to read ISR (In Service Register)
    out  23h, al                ; write to PIC.OCW3 master
    in   al, 20h                ; read ISR master.
    test al, 80h                ; if the in-service register does not have IR7 bit set
    jz short ExitParallelPort_WithoutEOI   ; this would be a spurious interrupt.

; ================================================
; --

;; Not spurious
;; So this is a norma parallel por interrupt.

    ;call _first_parallel_port_Handler

; EOI. Master. for parallel port
ExitParallelPort_WithEOI:

    ;xor rax, rax
    mov al, 0x20
    out 0x20, al   
    ;IODELAY  

; No eoi for irq 7 spurious
ExitParallelPort_WithoutEOI:
  
    ;popad
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq

;================================================
; PeripheralHall_irq8:
;     System CMOS, Realtime clock.
;     IRQ 8 - real-time clock (RTC)
;
; Capture context
align 4  
global PeripheralHall_irq8
PeripheralHall_irq8:
; Maskable interrupt

    ; #todo
    ; Work on this routine to make it kinda like the irq0.

    ;cli
    ;pushad
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs

    ;call _irq8_RTC

; EOI
; Order: Second, first.
    mov al, 0x20
    out 0xA0, al  
    IODELAY  
    IODELAY
    out 0x20, al
    ;IODELAY  

    ;popad
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax
    
    ;sti
    iretq
;;============================

;=========================================================
; IRQ 9
;extern _xxxe1000handler
; Capture context
align 4  
global _irq9
_irq9:
; Maskable interrupt

    ;; #test
    jmp unhandled_irq
    jmp $

    ;cli
    ;pushad
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs



    ;jmp _asm_reboot
    ;call _xxxe1000handler

    ;call _acpiHandler

    ;; EOI.
    ;; Order: Second, first.
    mov al, 0x20
    out 0xA0, al  
    IODELAY  
    out 0x20, al
    IODELAY  
    
    ;popad
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq


;;==========================================
; PeripheralHall_irq9_nic_handler:
; e1000 Intel nic handler.
; This is a work in progress!
; interrupção ?. irq ?;
; Temporary: interrupção 41. irq 9
; #bugbug: Remember, each nic can have a different interrupt 
; number, this handler was hardcoded just for irq9 in header3.asm 
; valid just for virtualbox. Maybe qemu uses another number.
; See _asm_nic_create_new_idt_entry() in header3.asm
; see: e1000.c
extern _irq_E1000
align 4  
global PeripheralHall_irq9_nic_handler
PeripheralHall_irq9_nic_handler:
; Maskable interrupt

    ;cli

; No caso do dispatcher lançar uma nova thread,
; então ele deve acionar enviar um EIO.

    ; mov dword [_irq0PendingEOI], 1

;; == Save context ====================
    
    ; Stack frame. (all double)
    pop qword [_contextRIP]     ; rip
    pop qword [_contextCS]      ; cs  (R3)
    pop qword [_contextRFLAGS]  ; rflags
    pop qword [_contextRSP]     ; rsp
    pop qword [_contextSS]      ; ss

    mov qword [_contextRDX], rdx 
    mov qword [_contextRCX], rcx 
    mov qword [_contextRBX], rbx 
    mov qword [_contextRAX], rax
     
    mov qword [_contextRBP], rbp
 
    mov qword [_contextRDI], rdi 
    mov qword [_contextRSI], rsi 

    mov qword [_contextR8], r8
    mov qword [_contextR9], r9
    mov qword [_contextR10], r10
    mov qword [_contextR11], r11
    mov qword [_contextR12], r12
    mov qword [_contextR13], r13
    mov qword [_contextR14], r14
    mov qword [_contextR15], r15

; Data segments
; gs,fs,es,ds
    xor rax, rax
    mov ax, gs
    mov word [_contextGS], ax
    mov ax, fs
    mov word [_contextFS], ax
    mov ax, es
    mov word [_contextES], ax
    mov ax, ds
    mov word [_contextDS], ax

; FPU
; See:
; https://wiki.osdev.org/SSE
    fxsave [_context_fpu_buffer]

; #todo
; Media, float pointers, debug.
; #important:
; We are using the kernel segment registers.
; Kernel data segments and stack.
; #bugbug: sempre a mesma pilha?
; Que pilha as interrupçoes de softwar estao usando?

;
; Calls
;

; cpl
; Get the first 2 bits of cs.
; see: x64cont.c
    mov rax, qword [_contextCS]  ;(R3)
    and rax, 3
    mov [_contextCPL], rax

; e1000 NIC device.
; See: e1000hw.c

    call _irq_E1000

; FPU
    fxrstor [_context_fpu_buffer]

; Release a bandit.

; 64bit
; This is a 64bit pointer to the pml4 table.

; #bugbug
; Não precisamos fazer refresh em todo tick,
; somente quando houver troca de tarefa.

    mov RAX, CR3  
    IODELAY 
    mov CR3, RAX  

; Wait TLB.
    ;IODELAY 
;
; == Restore context ====================
;

    ; Segments
    xor rax, rax
    mov ax, word [_contextDS]
    mov ds, ax
    mov ax, word [_contextES]
    mov es, ax
    mov ax, word [_contextFS]
    mov fs, ax
    mov ax, word [_contextGS]
    mov gs, ax

    mov r15, qword [_contextR15]
    mov r14, qword [_contextR14]
    mov r13, qword [_contextR13]
    mov r12, qword [_contextR12]
    mov r11, qword [_contextR11]
    mov r10, qword [_contextR10]
    mov r9,  qword [_contextR9]
    mov r8,  qword [_contextR8]

    mov rsi, qword [_contextRSI] 
    mov rdi, qword [_contextRDI] 
    
    mov rbp, qword [_contextRBP] 
    
    mov rax, qword [_contextRAX] 
    mov rbx, qword [_contextRBX] 
    mov rcx, qword [_contextRCX] 
    mov rdx, qword [_contextRDX] 

; Stack frame. (all double)
    push qword [_contextSS]      ; ss
    push qword [_contextRSP]     ; rsp
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip

; EOI: Order: Second, first.
    mov al, 0x20
    out 0xA0, al
    IODELAY
    IODELAY
    out 0x20, al
    ;IODELAY

    ;; variável usada pelo dispatcher.
    ;mov dword [_irq0PendingEOI], 0

    ; Acumulator.
    mov rax, qword [_contextRAX]

; #bugbug
; We do NOT need the 'sti'. 
; The flags in the 'eflags' will reenable it.

    ;sti
    iretq
;===========================

;========================================================
; IRQ 10  The Interrupt is left open for the use 
; of peripherals (open interrupt/available, SCSI or NIC)
; nvidia
; Capture context
align 4  
global _irq10
_irq10:
; Maskable interrupt

    ;; #test
    jmp unhandled_irq
    jmp $

    ;cli
    ;pushad
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs


    ;call _PciHandler1

    ;; EOI.
    ;; Order: Second, first.
    mov al, 0x20
    out 0xA0, al  
    IODELAY  
    out 0x20, al
    IODELAY  
    
    ;popad
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq

;;==========================================


;=======================================
; IRQ 11 - The Interrupt is left open for 
; the use of peripherals (open interrupt/available, SCSI or NIC)
; audio.
; Capture context
align 4  
global _irq11
_irq11:
; Maskable interrupt

    ;; #test
    jmp unhandled_irq
    jmp $

    ;cli
    ;pushad
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs


    ;call _PciHandler2

    ;; EOI.
    ;; Order: Second, first.
    mov al, 0x20
    out 0xA0, al  
    IODELAY  
    out 0x20, al
    IODELAY  
    
    ;popad
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq
;===================

;=======================================
; IRQ 12 - mouse on PS/2 connector
; See: /i8042/mouse.c
extern _irq12_MOUSE
; Capture context
align 4  
global PeripheralHall_irq12
PeripheralHall_irq12:
; Maskable interrupt

    ; #bugbug
    ; #todo:
    ; We also need to be careful if the interrupted thread 
    ; is a ring 0 thread or a ring 3 thread, because the stack frame is different.

    ;cli

; No caso do dispatcher lançar uma nova thread,
; então ele deve acionar enviar um EIO.

    ; mov dword [_irq0PendingEOI], 1

;; == Save context ====================

; Pop only the common part of the stack frame, 
; which is the same for both ring 0 and ring 3 threads.

    pop qword [_contextRIP]     ; rip
    pop qword [_contextCS]      ; cs (R3)
    pop qword [_contextRFLAGS]  ; rflags

.TestCPL:

    push rax
    mov rax, qword [_contextCS]  ; Get CPL
    and rax, 3                   ; Select 2 bits

    cmp rax, 0
    je .R0Thread
    cmp rax, 3
    je .R3Thread 
    pop rax
    jmp .InvalidThread

; ------------------------------------------------
; Stackframe for ring 0 has only 3 elements.
.R0Thread:
    pop rax
    mov qword [_contextRSP], rsp   ; save current kernel stack pointer
    mov qword [_contextSS], ss     ; save kernel stack segment
    ;mov qword [_gszLastStackFrame], 3  ; 3 elements
    jmp .AfterStackFrame

; ------------------------------------------------
; Stack frame for ring 3 has 5 elements.
.R3Thread:
    pop rax
    pop qword [_contextRSP]     ; rsp
    pop qword [_contextSS]      ; ss
    ;mov qword [_gszLastStackFrame], 5  ; 5 elements
    jmp .AfterStackFrame

; ------------------------------------------------
.AfterStackFrame:

    mov qword [_contextRDX], rdx 
    mov qword [_contextRCX], rcx 
    mov qword [_contextRBX], rbx 
    mov qword [_contextRAX], rax
     
    mov qword [_contextRBP], rbp
 
    mov qword [_contextRDI], rdi 
    mov qword [_contextRSI], rsi 

    mov qword [_contextR8], r8
    mov qword [_contextR9], r9
    mov qword [_contextR10], r10
    mov qword [_contextR11], r11
    mov qword [_contextR12], r12
    mov qword [_contextR13], r13
    mov qword [_contextR14], r14
    mov qword [_contextR15], r15

; Data segments
; gs,fs,es,ds
    xor rax, rax
    mov ax, gs
    mov word [_contextGS], ax
    mov ax, fs
    mov word [_contextFS], ax
    mov ax, es
    mov word [_contextES], ax
    mov ax, ds
    mov word [_contextDS], ax

; FPU
; See:
; https://wiki.osdev.org/SSE
    fxsave [_context_fpu_buffer]

; #todo
; Media, float pointers, debug.
; #important:
; We are using the kernel segment registers.
; Kernel data segments and stack.
; #bugbug: sempre a mesma pilha?
; Que pilha as interrupçoes de softwar estao usando?

;
; Calls
;

; cpl
; Get the first 2 bits of cs.
; see: x64cont.c
    mov rax, qword [_contextCS]  ;(R3)
    and rax, 3
    mov [_contextCPL], rax

; See: mouse.c
    mov r10, qword _irq12_MOUSE
    call r10

; FPU
    fxrstor [_context_fpu_buffer]

; Release a bandit.

; 64bit
; This is a 64bit pointer to the pml4 table.

; #bugbug
; Não precisamos fazer refresh em todo tick,
; somente quando houver troca de tarefa.

    mov RAX, CR3  
    IODELAY 
    mov CR3, RAX  

; Wait TLB.
    ;IODELAY 
;
; == Restore context ====================
;

    ; Segments
    xor rax, rax
    mov ax, word [_contextDS]
    mov ds, ax
    mov ax, word [_contextES]
    mov es, ax
    mov ax, word [_contextFS]
    mov fs, ax
    mov ax, word [_contextGS]
    mov gs, ax

    mov r15, qword [_contextR15]
    mov r14, qword [_contextR14]
    mov r13, qword [_contextR13]
    mov r12, qword [_contextR12]
    mov r11, qword [_contextR11]
    mov r10, qword [_contextR10]
    mov r9,  qword [_contextR9]
    mov r8,  qword [_contextR8]

    mov rsi, qword [_contextRSI] 
    mov rdi, qword [_contextRDI] 
    
    mov rbp, qword [_contextRBP] 
    
    mov rax, qword [_contextRAX] 
    mov rbx, qword [_contextRBX] 
    mov rcx, qword [_contextRCX] 
    mov rdx, qword [_contextRDX] 


; --------------------------------------------
; Stack frame saga

    ;----------------------------------------
    ; Now rebuild the hardware-saved stack frame.
    ; The appropriate frame is chosen based on _contextCPL.
    ;----------------------------------------

    mov rax, qword [_contextCS]   ; Get CPL
    and rax, 3                    ; Select 2 bits

    ; Compare
    cmp rax, 0
    je .restore_kernel_mode    ; It is a ring 0 thread
    cmp rax, 3
    je .restore_user_mode      ; It is a ring 3 thread

    ; #bugbug
    ; We need a panic here.
    jmp .InvalidThread

; ------------------------------------------------
; Stack frame. (all double)
; Stackframe for ring 0 has only 3 elements.
.restore_kernel_mode:
    ; Stack frame for ring 0 with 3 elements, 
    ; because the last thread was ring 0.
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip
    jmp .stackframe_done

; ------------------------------------------------
; Stack frame. (all double)
; Stack frame for ring 3 has 5 elements.
.restore_user_mode:

    ; Stack frame. (all double)
    push qword [_contextSS]      ; ss
    push qword [_contextRSP]     ; rsp
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip

; ------------------------------------------------
.stackframe_done:

    ; send EOI to XT keyboard
    ;in      al, 061h
    ;mov     ah, al
    ;or      al, 080h
    ;out     061h, al
    ;mov     al, ah
    ;out     061h, al

;EOI order: Second, first.
    mov al, 0x20
    out 0xA0, al 
    IODELAY 
    IODELAY 
    out 0x20, al
    ;IODELAY 

    ;; variável usada pelo dispatcher.
    ;mov dword [_irq0PendingEOI], 0

    ; Acumulator
    mov rax, qword [_contextRAX]

; #bugbug
; We do NOT need the 'sti'. 
; The flags in the 'eflags' will reenable it.

    ;sti
    iretq
;;=================

; --------------------------------------
.InvalidThread:
    ; #todo: Call a fancy worker
    cli
    hlt
    jmp .InvalidThread
; --------------------------------------
;.debugBreakpoint:
    ;int 3

;;============================================================	
; IRQ 13 
; CPU co-processor  or  integrated floating point unit  
; or  inter-processor interrupt (use depends on OS)
; Capture context
align 4  
global _irq13
_irq13:
; Maskable interrupt

    ;; #test
    jmp unhandled_irq
    jmp $

    ;cli

    ;push ax 
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs

    ;call _coprocessorHandler

    ;; EOI.
    ;; Order: Second, first.
    mov al, 0x20
    out 0xA0, al  
    IODELAY  
    out 0x20, al
    IODELAY  
    
    ;pop ax
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq

;==========================================

;============================================
; PeripheralHall_irq14:
;     Tratador de interrupções para unidade master.
;     IRQ 14 - primary ATA channel 
;     ( ATA interface usually serves hard disk drives and CD drives ) 
;     O timer precisa ser desbilitado. ??
extern _irq14_PRIMARY_IDE
; Capture context
align 4  
global PeripheralHall_irq14
PeripheralHall_irq14:
; Maskable interrupt

    ; #todo
    ; Work on this routine to make it kinda like the irq0.

    ;cli 
    
    ;push eax
    ;PUSHAD
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs
    pushfq    


    fxsave [__hw_fpu_buffer]

; See: atairq.c
    call _irq14_PRIMARY_IDE

    fxrstor [__hw_fpu_buffer]

; EOI
; Order: Second, first.
    MOV AL,020h
    OUT 0A0h,AL
    IODELAY
    IODELAY  
    OUT 020h,AL
    ;IODELAY
    ;IODELAY  
    
    ;POPAD
    ;pop eax
    popfq
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq 

;=================================================	
; PeripheralHall_irq15:
;     Tratador de interrupções para unidade slave.
;     IRQ 15 - secondary ATA channel
;     O timer precisa ser desbilitado. ??
;; The correct way to handle an IRQ 15 is similar, but a little trickier 
;; due to the interaction between the slave PIC and the master PIC. 
;; First check the slave PIC chip's ISR to see if the IRQ is a spurious 
;; IRQ or a real IRQ. If it is a real IRQ then it is treated the same 
;; as any other real IRQ. If it's a spurious IRQ then don't send the 
;; EOI to the slave PIC; however you will still need to send the EOI 
;; to the master PIC because the master PIC itself won't know that it 
;; was a spurious IRQ from the slave. 
extern _irq15_SECONDARY_IDE
; Capture context
align 4  
global PeripheralHall_irq15
PeripheralHall_irq15:
; Maskable interrupt

    ; #todo
    ; Work on this routine to make it kinda like the irq0.

    ;cli
    
    ;push eax
    ;PUSHAD
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15
    
    ;push ds
    ;push es
    push fs
    push gs
    pushfq

    fxsave [__hw_fpu_buffer]

; See: atairq.c
    call _irq15_SECONDARY_IDE

    fxrstor [__hw_fpu_buffer]

; #bugbug
; #todo
; Spurious int for irq15.
; It's different from irq7

; EOI
; Order: Second, first.
    MOV AL, 020h
    OUT 0A0h, AL
    IODELAY
    IODELAY  
    OUT 020h, AL
    ;IODELAY
    ;IODELAY  

    ;POPAD
    ;pop eax
    popfq
    pop gs
    pop fs
    ;pop es
    ;pop ds
    
    ;#bugbug
    ;#todo: Pop the registers.
    ;popad
    
    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    ;sti
    iretq 
; =======================

align 8


