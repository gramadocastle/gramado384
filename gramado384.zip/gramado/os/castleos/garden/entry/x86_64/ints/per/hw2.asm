; Peripheral Hall (Pink)
; hw2.asm
; This file handles the traps for the x86_64 processors.
; Only hw interrupts.
; Created by Fred Nora.

;
; Imports
;

;
; Callback support.
; See: callback.c, callback.h
;

; Flag
extern _asmflagDoCallbackAfterCR3

; Context for the function
extern _ring3_callback_address
extern _ring3_callback_parm1
extern _ring3_callback_parm2
extern _ring3_callback_parm3
extern _ring3_callback_parm4

; ts
extern _task_switch_status

; extern _string_panic

;;
;; == Context =============================================
;;

; See:
; x64cont.c

extern _contextSS        ; User Mode.
extern _contextRSP       ; User Mode.
extern _contextRFLAGS    ; User Mode.
extern _contextCS        ; User Mode.
extern _contextRIP       ; User Mode.

extern _contextDS
extern _contextES
extern _contextFS  ;?
extern _contextGS  ;?

extern _contextRAX
extern _contextRBX
extern _contextRCX
extern _contextRDX

extern _contextRSI
extern _contextRDI

extern _contextRBP

extern _contextR8
extern _contextR9
extern _contextR10
extern _contextR11
extern _contextR12
extern _contextR13
extern _contextR14
extern _contextR15

; ...

; Flag for the state of callback restorer
extern _callback_restorer_done

;------------------------------------------------
; Start a routine in ring3.
; + Essa rotina foi chamada somente quando o kernel estava usando
;   a paginação do aplicativo window server.
; + Interrupçoes desabilitadas
; + eoi não acionado.
; Nessa hora vamos para ring3 executar um código no aplicativo,
; uma interrupção gerada pelo aplicativo nos trará de volta
; par ao kernel na rotina callback_restorer, e por fim
; devemos definitivamente voltarmos para o aplicativo em ring 3,
; através da rotina irq0_release.
;
; IN:
; ss     - Reusado do contexto salvo do aplicativo.
; rsp    - Reusado do contexto salvo do aplicativo.
; rflags - ring3, interrupções desabilitadas.
; cs     - Reusado do contexto salvo do aplicativo.
; rbx    - rip
;

__doRing3Callback:

    ;int 3
; Restorer is not done
    mov qword [_callback_restorer_done], 0

    ; Valid only for ring 3.
    mov rax, qword [_contextCS]   ; Get CPL
    and rax, 3                    ; Select 2 bits
    ; Compare
    cmp rax, 3
    jne .R3Callbackfailed

; Build iretq frame: SS, RSP, RFLAGS, CS, RIP
    push qword [_contextSS]   ; ss
    push qword [_contextRSP]  ; rsp
    push qword 0x3000         ; rflags interrupçoes desabilitadas.
    push qword [_contextCS]   ; cs

; Get the RIP address
; Use the published address: 
; Read from the exported ring3_callback_address; 
; do not rely on CallbackEventInfo in assembly.
    mov rbx, qword [_ring3_callback_address]
    push rbx                  ; rip

; Clear the pivot flag before iretq: Enforce one-shot delivery.
    mov qword [_asmflagDoCallbackAfterCR3], 0


; At this moment we already have the stack frame.
; let's setup the paramaters.
; Respecting the calling convention.

    mov rax, qword [_ring3_callback_parm1]
    ;mov rax, qword 1000 ; fake parameter
    mov rdi, rax 

    mov rax, qword [_ring3_callback_parm2]
    ;mov rax, qword 2000 ; fake parameter
    mov rsi, rax 

    mov rax, qword [_ring3_callback_parm3]
    ;mov rax, qword 3000 ; fake parameter
    mov rdx, rax 

    mov rax, qword [_ring3_callback_parm4]
    ;mov rax, qword 4000 ; fake parameter
    mov rcx, rax 

    ; Clear DF to avoid string op surprises
    cld

; Go to the ring3 procedure.
    iretq
; ------------------------------
.R3Callbackfailed:
    ; #todo Create a fancy routine for this failure.
    cli
    hlt
    jmp .R3Callbackfailed




; #test
; Here we're gonna call the ring3handler for the 
; a target signal
;__doCallRing3Signalhandler:
; Get the RIP address.
    ;mov rbx, qword [_ring3_callback_address]
; Setup the stack frame.
    ;push qword [_contextSS]   ; ss
    ;push qword [_contextRSP]  ; rsp
    ;push qword 0x3000         ; rflags interrupçoes desabilitadas.
    ;push qword [_contextCS]   ; cs
    ;push rbx                  ; rip
; Go to the ring3 procedure.
    ;iretq

; -------------------------------------
; irq0_release:
;   Common release path for IRQ0 (PIT timer).
;   Optionally performs a ring3 callback handoff,
;   refreshes CR3 (if necessary), restores CPU context,
;   sends EOI, and returns via iretq.
; See: _irq0 in hw1.asm, ts.c, pit.c, sci.c.
; -------------------------------------


extern _gszLastStackFrame

; _gszLastStackFrame is needed.
; We need to know how many elements was poped in the last
; timer interrupt.
;This dual strategy ensures you never mismatch:
; Ring 0 → Ring 0 resumes: 3 elements.
; Ring 3 → Ring 3 resumes: 5 elements.
; Ring 0 → Ring 3 switch: push 5 from the new thread’s context.
; Ring 3 → Ring 0 switch: push 3 from the new thread’s context.

; -------------------------------------
; Irq0 release.
; Timer interrupt.
; See: _irq0 in hw1.asm.
; See: ts.c, pit.c, sci.c.
align 4  
irq0_release:

; ring3 callback
; Se a flag indicar que sim,
; então iremos efetuar um iretq para dentro
; do processo window server.
; Quem aciona essa flag é tsThreadSwitch() em ts.c.
; Depois que o contexto esta salve e se certificou
; que estamos rodando a thread de controle do window server.
; #importante: Antes da troca de tarefa, 
; então cr3 permanece sendo o do processo window server.
; #bugbug: 
; Precisa realmente ser antes de ts.c trocar de tarefa e 
; o contexto precisa estar salvo.
; Se fosse depois, então saltaríamos para outra tarefa
; diferente do window server e usaríamos endereços errados.
    mov rax, qword [_asmflagDoCallbackAfterCR3]
    and  rax, 0xFFFF
; Callback ring3 procedure.
    cmp rax, 0x1234
    je __doRing3Callback

; 64bit
; This is a 64bit pointer to the pml4 table.

; #bugbug
; CR3 refresh: 
; We flush TLB each tick; only do it when switching address spaces. 
; Otherwise it’s needless overhead.

    ;mov RAX, CR3  
    ;IODELAY 
    ;mov CR3, RAX  

; Wait TLB.
    ;IODELAY 
;
; == Restore context ====================
;

    ; Segments
    xor rax, rax
; DS and ES are largely ignored for data addressing in long mode; 
; loading them is typically redundant.
    mov ax, word [_contextDS]
    mov ds, ax
    mov ax, word [_contextES]
    mov es, ax
; FS/GS bases come from MSRs (IA32_FS_BASE, IA32_GS_BASE), 
; not the selector’s descriptor base. 
; Moving a selector into fs/gs does not set their base; 
; you need wrmsr if you use per-CPU or TLS bases. 
; Saving/restoring just the selectors may not preserve 
; what you expect.
    mov ax, word [_contextFS]
    mov fs, ax
    mov ax, word [_contextGS]
    mov gs, ax

    mov r15, qword [_contextR15]
    mov r14, qword [_contextR14]
    mov r13, qword [_contextR13]
    mov r12, qword [_contextR12]
    mov r11, qword [_contextR11]
    mov r10, qword [_contextR10]
    mov r9,  qword [_contextR9]
    mov r8,  qword [_contextR8]

    mov rsi, qword [_contextRSI] 
    mov rdi, qword [_contextRDI] 
    
    mov rbp, qword [_contextRBP] 
    
    mov rax, qword [_contextRAX] 
    mov rbx, qword [_contextRBX] 
    mov rcx, qword [_contextRCX] 
    mov rdx, qword [_contextRDX] 

; --------------------------------------------
; Stack frame saga

    ;----------------------------------------
    ; Now rebuild the hardware-saved stack frame.
    ; The appropriate frame is chosen based on _contextCPL.
    ;----------------------------------------

    mov rax, qword [_contextCS]   ; Get CPL
    and rax, 3                    ; Select 2 bits

    ; Compare
    cmp rax, 0
    je .restore_kernel_mode    ; It is a ring 0 thread
    cmp rax, 3
    je .restore_user_mode      ; It is a ring 3 thread

    ; #bugbug
    ; We need a panic here.
    jmp .InvalidThread

; ------------------------------------------------
; Stack frame. (all double)
; Stackframe for ring 0 has only 3 elements.
.restore_kernel_mode:

; rule: If the last thread had 5 elements ... 
; we resume the next thread using 5 elements ... 
; even if the next thread is in ring 0.

    ; #test (caution)
    ; The last was 3 but now its 5
    mov eax, dword [_gszLastStackFrame]
    cmp eax, 5
    je .ajust5
    ;je .debugBreakpoint

    ; Stack frame for ring 0 with 3 elements, 
    ; because the last thread was ring 0.
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip
    jmp .stackframe_done

.ajust5:
    ; We need to push the extra elements for ring 0.
    ; It's because the last thread was ring 3 and 
    ; we need to restore the stack frame.
    
    ; Stack frame for ring 0, ajusted to 5 elements 
    ; because the last thread was ring 3.
    push qword [_contextSS]  ;r0
    push qword [_contextRSP] ;r0
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip
    jmp .stackframe_done


; ------------------------------------------------
; Stack frame. (all double)
; Stack frame for ring 3 has 5 elements.
.restore_user_mode:

    ; #test  (caution)
    ; If the last thread had 3 elements ... 
    ; And we are trying to resume a ring 3 thread with 5 elements ...
    ; #ps: ring 3 always has 5 elements.
    ; It's not a problem because the timer interrupt 
    ; is the moment where the stack come back to the normal state.
    ; Remember. The stack was initiated with the spawn 
    ; or with the iretq.
    ; #important: It means that at this moment we are 
    ; initializing the stack.
    ; mov eax, dword [_gszLastStackFrame]
    ; cmp eax, 3
    ; je .debugBreakpoint

    ; Stack frame for ring 3 has 5 elements.
    push qword [_contextSS]      ; ss
    push qword [_contextRSP]     ; rsp
    push qword [_contextRFLAGS]  ; rflags
    push qword [_contextCS]      ; cs
    push qword [_contextRIP]     ; rip

; ------------------------------------------------
.stackframe_done:

; EOI - Only the first PIC.
    mov al, 20h
    out 20h, al  

    ;; variável usada pelo dispatcher.
    ;mov dword [_irq0PendingEOI], 0

; Acumulator
    mov rax, qword [_contextRAX]

; #bugbug
; We do NOT need the 'sti'.
; The flags in the 'rflags' will reenable it.
; IRETQ will re‑enable them safely.

    ; #test: We are testing it with nout the sti.
    ; Avoiding extra timer interrupt.
    ;sti

    ; At this point we need to update the gs segment 
    ; for the one that belongs to the current thread in user mode.
    ; #ps: How to handle this situation if we had a thread switching?

    ; swapgs

    iretq

; --------------------------------------
.InvalidThread:
    ; #todo: Call a fancy worker
    cli
    hlt
    jmp .InvalidThread
; --------------------------------------
.debugBreakpoint:
    int 3

;----------------------------------------------
; _turn_task_switch_on:
;     + Cria um vetor para o timer, IRQ0.
;     + Habilita o funcionamento do mecanismo de taskswitch.
; Called by I_x64ExecuteInitialProcess in x64init.c
;

global _turn_task_switch_on
_turn_task_switch_on:

    cli 
    mov rax, qword PeripheralHall_irq0        ;definitivo
    mov rbx, qword 32
    ;call _setup_system_interrupt
    call _setup_system_interrupt_hw  ;#testing 0x8E00

    ;recarrega a nova idt (talvez seja necessario)
    ;lidt [IDT_register]

    ;status do mecanismo de taskswitch.
    mov qword [_task_switch_status], qword 1    ;UNLOCKED.
    ret


;-------------------------------------------------------------
; _turn_task_switch_off:
;     Desabilita a IRQ0 responsável por fazer o task switch.
;
global _turn_task_switch_off
_turn_task_switch_off:

    cli
    mov rax, qword unhandled_irq
    mov rbx, qword 32
    ;call _setup_system_interrupt
    call _setup_system_interrupt_hw  ;#testing 0x8E00

    ;status do mecanismo de taskswitch.
    mov qword [_task_switch_status], qword 0    ;LOCKED.
    ret

