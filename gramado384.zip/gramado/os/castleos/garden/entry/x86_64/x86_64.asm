; x86_64.asm
; Created by Fred Nora.

; Gate type:
; + Interrupt gate → clears IF, preventing nesting.
; + Trap gate → leaves IF unchanged, allowing nesting if you want.

; Syscall/sysret mechanism: 
; In x86‑64, the syscall instruction doesn’t even go through the IDT 
; in the same way — it jumps directly to the kernel entry point 
; with IF cleared. So you’re guaranteed not to be interrupted 
; mid‑syscall unless you re‑enable interrupts yourself.

;extern _Module0EntryPoint

; Type/flags word:
; 0xEE00 → Present=1, DPL=3, Type=0xE (interrupt gate).
;  + Means: user mode (ring 3) can call this gate (e.g. syscalls).
;  + Interrupt gate → IF cleared on entry.
;0x8E00 → Present=1, DPL=0, Type=0xE (interrupt gate).
;  + Means: only ring 0 can trigger it (hardware IRQs, faults).
;  + Interrupt gate → IF cleared on entry.

; What this means in practice
; Syscalls (0xEE00):
; + Ring 3 can invoke them (INT 0x80, etc.).
; + IF is cleared when entering, so interrupts are disabled until you return with IRETQ.
; + This is safe, but it means syscalls run with interrupts off unless you re‑enable inside the kernel.
; Hardware IRQs (0x8E00):
; + Only ring 0 can trigger them (as expected).
; + IF cleared on entry, so no nested IRQs.
; + Standard choice for hardware interrupts.

; In simple terms
; + 0x8E00 → hardware IRQs, kernel‑only, interrupts disabled on entry.
; + 0xEE00 → syscalls, user‑callable, interrupts disabled on entry.
; + 0xEF00 (if you ever use it) → syscalls, user‑callable, interrupts stay enabled.


align 16
__sw_local_fpu_buffer_apic_timer:
    times 512 db 0
align 16


; See: apic.c
extern _local_apic_eoi
extern _apic_TimerHandler0000
; ============================================
; 0x48 - LAPIC Timer
global PeripheralHall_lapic_timer_handler
PeripheralHall_lapic_timer_handler:

    cli
    jmp PeripheralHall_irq0


    cli
    push rax
    push rbx
    push rcx
    push rdx
    push rsi
    push rdi
    push rbp
    push r8
    push r9
    push r10
    push r11
    push r12
    push r13
    push r14
    push r15

    ;push ds
    ;push es
    push fs
    push gs
    push rsp
    pushfq

    fxsave [__sw_local_fpu_buffer_apic_timer]

    ; Debug notification (optional)
    ;mov al, 'T'
    ;mov dx, 0x3F8
    ;out dx, al

    ; #ps: This routine calls the EIO.
    mov r10, qword _apic_TimerHandler0000
    call r10

    push rdi
    ; Call the C routine to write EOI
    mov rdi, 0 ; BSP
    call _local_apic_eoi
    pop rdi

    fxrstor [__sw_local_fpu_buffer_apic_timer]

    popfq
    pop rsp
    pop gs
    pop fs
    ;pop es
    ;pop ds

    pop r15
    pop r14
    pop r13
    pop r12
    pop r11
    pop r10
    pop r9
    pop r8
    pop rbp
    pop rdi
    pop rsi
    pop rdx
    pop rcx
    pop rbx
    pop rax

    sti
    iretq

; ============================================
; 0x49 - Performance Counter
global PeripheralHall_lapic_perf_handler
PeripheralHall_lapic_perf_handler:
    push rax
    push rcx
    push rdx

    ; ... optional profiling bump/counter ...

    push rdi
    ; Call the C routine to write EOI
    mov rdi, 0 ; BSP
    call _local_apic_eoi
    pop rdi


    pop rdx
    pop rcx
    pop rax
    iretq

; ============================================
; 0x4A - LINT0 (ExtINT / legacy PIC handoff) — often masked
global PeripheralHall_lapic_lint0_handler
PeripheralHall_lapic_lint0_handler:
    push rax
    push rcx
    push rdx

    ; If you actually route ExtINT, you’d cascade to 8259 handler.
    ; In modern IOAPIC setups, LINT0 stays masked.

    push rdi
    ; Call the C routine to write EOI
    mov rdi, 0 ; BSP
    call _local_apic_eoi
    pop rdi

    pop rdx
    pop rcx
    pop rax
    iretq

; ============================================
; 0x4B - LINT1 (NMI)
; NMIs are non-maskable. LAPIC may mark in-service; issue EOI to be safe.
global PeripheralHall_lapic_nmi_handler
PeripheralHall_lapic_nmi_handler:
    push rax
    push rcx
    push rdx

    ; Minimal, fast handling. Avoid heavy work here.
    ; Log or signal, then return.

    push rdi
    ; EOI (safe, even for NMI)
    ; Call the C routine to write EOI
    ; Call the C routine to write EOI
    mov rdi, 0 ; BSP
    call _local_apic_eoi
    pop rdi


    pop rdx
    pop rcx
    pop rax
    iretq

; ============================================
; 0x4C - LAPIC Error
global PeripheralHall_lapic_error_handler
PeripheralHall_lapic_error_handler:
    push rax
    push rcx
    push rdx

    ; Optionally read LAPIC ESR (Error Status Register) to clear latched errors.
    ; Write to ESR (read-after-write) sequence if you implement it.

    push rdi
    ; EOI required
    ; Call the C routine to write EOI
    ; Call the C routine to write EOI
    mov rdi, 0 ; BSP
    call _local_apic_eoi
    pop rdi

    pop rdx
    pop rcx
    pop rax
    iretq

; ============================================
; 0x4D - Thermal sensor
global PeripheralHall_lapic_thermal_handler
PeripheralHall_lapic_thermal_handler:
    push rax
    push rcx
    push rdx

    ; Handle/record thermal event, throttle, etc.

    push rdi
    ; EOI required
    ; Call the C routine to write EOI
    ; Call the C routine to write EOI
    mov rdi, 0 ; BSP
    call _local_apic_eoi
    pop rdi

    pop rdx
    pop rcx
    pop rax
    iretq

; ============================================
; Spurious interrupt handler (vector 0xFF)
; - Delivered via LAPIC SVR when a spurious condition occurs.
; - No EOI is required for spurious interrupts.
; - Keep it minimal: preserve a few registers, optionally log, then iretq.
; ============================================

; Spurious interrupts (SVR vector, e.g. 0xFF): 
; These are special. The LAPIC does not set the “in‑service” bit 
; for spurious interrupts. 
; → That means no EOI is required. 
; → If you try to write EOI, it won’t hurt, but it’s unnecessary.

global PeripheralHall_spurious_handler
PeripheralHall_spurious_handler:
    ; Preserve scratch registers (optional, keep minimal)
    push rax
    push rcx
    push rdx

    ; Optionally: increment a counter or emit a debug message here.
    ; (left empty for safety/minimalism)

    ; That means no EOI is required.

    pop rdx
    pop rcx
    pop rax
    iretq



; ==================================
; Clear Nested Task bit in RFLAGS.
; bit 14 - NT, Nested task flag.
; Limpar a flag nt em rflags
; e dar refresh na pipeline. #todo
; Isso evita taskswitching via hardware quando em 32bit.
; This prevents hardware task switching in 32‑bit compatibility mode.
global _x64_clear_nt_flag
_x64_clear_nt_flag:
    push rax
    push rbx

    pushfq
    pop rax
    mov rbx, 0x0000000000004000
    not rbx
    and rax, rbx
    push rax
    popfq

    pop rbx
    pop rax
    ret

; Called by x64_init_gdt() in x64.c
; Loads a new GDT with lgdt.
; Then reloads all segment registers (ds, es, fs, gs, ss) 
; with selector 0x10 (your data segment).
; This ensures the CPU is using your fresh descriptors.

global _asm_load_gdt
_asm_load_gdt:

    mov rax, rdi
    lgdt [rax]

    mov rax, 0x10  ; #bugbug: Hardcoded
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov ss, ax

    ret

;=================================================
; setup_idt:
; Configura a IDT.
; Dado o endereço da IDT, preenche todos os vetores, 
; apontando para um só endereço. 'unhandled_int'.
; See: sw.asm
; called by xxxhead.asm
; See: sw.asm
;
; 0xEE00 - (present, dpl=3, interrupt gate) (disable interrupts)
;
; 0x8E00 - (present, dpl=0, interrupt gate) (disable interrupts)
; In the case of trap gates the interrupt are not disable,
; allowing nesting interrupts. 
;
; Every interrupt will use
; 0xEE00 - (present, dpl=3, interrupt gate) (disable interrupts)
; It means that it cam be called from ring3 and the interrupts
; will be disabled.
;
; Builds 256 entries pointing to a single handler (unhandled_int).
; Splits the 64‑bit handler address into low/mid/high parts and 
; writes them into the descriptor fields.
; Uses type 0xEE00 (present, DPL=3, interrupt gate, interrupts disabled).
; This means even ring 3 can trigger these gates, but interrupts will be 
; masked during handling.
setup_idt:
; Using 0xEE00

    ;pushad
    push rax
    push rcx
    push rdx
    
    ; #todo: x86_64: 64bit address
    mov rdx, qword unhandled_int  

    ; low 16 
    mov rax, rdx 
    mov word  [d_offset_15_0],  ax
 
    ; high 16
    mov rax, rdx
    shr rax, 16
    mov word  [d_offset_31_16], ax

    ; high 32
    mov rax, rdx
    shr rax, 32
    mov dword [d_offset_63_32], eax

    ;; The pointer. 64bit address
    mov rdi, qword _idt

    ;; The counter
    mov rcx, qword 256

; loop
rp_sidt:

    ;; #bugbug
    ;; Nao sei se essa operação eh possivel,
    ;; mas queremos mover de double em double

    ;==========================
    ; Primeiros 32 bits. 
    ; (offset low and selector)
    xor rax, rax
    mov eax, dword 0x00080000     ; Step1: selector = 0x0008 = cs  na parte alta.
    mov ax, word  [d_offset_15_0] ; Step2: uma parte do endereço na parte baixa (16 bits)
    mov dword [rdi+0], eax   

    ;=========================================
    ; segundos 32 bit.
    xor rax, rax
    mov ax, word [d_offset_31_16]
    shl rax, 16
    ;0xEE00 - (present, dpl=3, interrupt gate) (disable interrupts)
    mov ax, word 0xEE00
    mov dword [rdi+4], eax   

    ;=========================================
    ; terceiros 32 bit.
    xor rax, rax
    mov eax, dword [d_offset_63_32]
    mov dword [rdi+8], eax

    ;=========================================
    ; quartos 32 bit.
    xor rax, rax
    mov dword [rdi+12], eax

    ;; done: go to next

    add  rdi, qword 16    ;;  vai pra proxima entrada.
    dec rcx               ;;  decrementa o contador.

    jne rp_sidt  ; loop

    ; #bugbug
    ; No. We will do this later.
    ; lidt [IDT_register]

    pop rdx
    pop rcx
    pop rax
    ;popad

    ret

;Offset address used in the function above.
d_offset_15_0:  dw 0
d_offset_31_16: dw 0
d_offset_63_32: dd 0
;;====================================


; =============================================================
; _setup_system_interrupt: 
; Configura um vetor da IDT para a interrupção do sistema. 
; O endereço do ISR e o número do vetor são passados via argumento.
; IN:
;    rax = endereço. (callback)(endereço do handler)
;    rbx = número do vetor (0x80).(número da interrupção.)
;
; 0xEE00 - (present, dpl=3, interrupt gate) (disable interrupts)
;
; 0x8E00 - (present, dpl=0, interrupt gate) (disable interrupts)
;
; In the case of 'trap gates' the interrupt are not disable,
; allowing nesting interupts.
;
; Every interrupt will use
; >>> 0xEE00 - (present, dpl=3, interrupt gate) (disable interrupts)
; It means that it cam be called from ring3 and the interrupts
; will be disabled.
;
; Takes a handler address in rax and a vector number in rbx.
; Computes the offset into the IDT (vector * 16).
; Writes the handler address and attributes into the chosen entry.
; Uses 0xEE00 (ring 3 callable) for syscalls.

global _setup_system_interrupt
_setup_system_interrupt:
; Using 0xEE00

    push rax
    push rbx
    push rcx
    push rdx

; Endereço e índice na tabela.
    mov qword [d__address], rax  ; Endereço. 64bit
    mov qword  [d__number], rbx  ; Número do vetor.

; Calcula o deslocamento.
    xor rax, rax
    mov rax, qword  16
    mov rbx, qword [d__number]
    mul rbx
    ; O resuldado está em rax.
; Adiciona o deslocamento à base rdi.
; A base é o início da idt.
; lembra? O resultado estava em rax.
    mov rdi, qword _idt
    add rdi, rax

; Agora rdi contém o endereço de memória
; dentro da idt, onde desejamos contruir a entrada.

; Lidando com o endereço.
; Salva o endereço de 64bit em rdx.
    mov rdx, qword [d__address] 
; low 16 
    mov rax, rdx 
    mov word  [address_offset_15_0],  ax
; high 16
    mov rax, rdx
    shr rax, 16
    mov word  [address_offset_31_16], ax
; high 32
    mov rax, rdx
    shr rax, 32
    mov dword [address_offset_63_32], eax

;------------------
; Lembre-se: 
; rdi contém o endereço de memória
; dentro da idt, onde desejamos contruir a entrada.
; #bugbug
; Nao sei se essa operação eh possivel,
; mas queremos mover de double em double
; #bugbug
; Checar o que representa esse seletor.

;==========================
; Primeiros 32 bits. 
; (offset low and selector)
    xor rax, rax
    mov eax, dword 0x00080000            ; Step1: selector = 0x0008 = cs  na parte alta.
    mov ax, word  [address_offset_15_0]  ; Step2: uma parte do endereço na parte baixa (16 bits)
    mov dword [rdi+0], eax
;=========================================
; segundos 32 bit.
    xor rax, rax
    mov ax, word [address_offset_31_16]
    shl rax, 16
    ;0xEE00 - (present, dpl=3, interrupt gate) (disable interrupts)
    mov ax, word 0xEE00
    mov dword [rdi+4], eax
;=========================================
; terceiros 32 bit.
    xor rax, rax
    mov eax, dword [address_offset_63_32]
    mov dword [rdi+8], eax
;=========================================
; quartos 32 bit.
    xor rax, rax
    mov dword [rdi+12], eax
;-----------------

; Do not load.
; recarrega a nova idt
    ;lidt [IDT_register]

    pop rdx
    pop rcx
    pop rbx
    pop rax

    ret

d__address:  dq 0
d__number:   dq 0
;Offset address used in the function above.
address_offset_15_0:  dw 0
address_offset_31_16: dw 0
address_offset_63_32: dd 0
;;--
;=============================================

; =============================================================
; _setup_system_interrupt: 
; Configura um vetor da IDT para a interrupção do sistema. 
; O endereço do ISR e o número do vetor são passados via argumento.
; IN:
;    rax = endereço. (callback)(endereço do handler)
;    rbx = número do vetor (0x80).(número da interrupção.)
;
; 0xEE00 - (present, dpl=3, interrupt gate) (disable interrupts)
; Type = 0xE → Interrupt gate (64‑bit).
; DPL = 3 → User mode (ring 3) is allowed to invoke this gate.
; P = 1 → Entry is present.
; Other bits → Reserved or set according to long mode requirements.
;
; 0x8E00 - (present, dpl=0, interrupt gate) (disable interrupts)
;
; In the case of 'trap gates' the interrupt are not disable,
; allowing nesting interupts.
;
; Every interrupt will use
; >>> 0x8E00 - (present, dpl=0, interrupt gate) (disable interrupts)
; In the case of trap gates the interrupt are not disable,
; allowing nesting interrupts. 
;

; Same as above, but uses 0x8E00 (ring 0 only).
; This is correct for IRQs, since userland shouldn’t trigger them.

; Testing this for hw interrupts.
global _setup_system_interrupt_hw
_setup_system_interrupt_hw:
; Using 0x8E00

    push rax
    push rbx
    push rcx
    push rdx

; Endereço e índice na tabela.
    mov qword [__d__address], rax  ; Endereço. 64bit
    mov qword  [__d__number], rbx  ; Número do vetor.

; Calcula o deslocamento.
    xor rax, rax
    mov rax, qword  16
    mov rbx, qword [__d__number]
    mul rbx
    ; O resuldado está em rax.
; Adiciona o deslocamento à base rdi.
; A base é o início da idt.
; lembra? O resultado estava em rax.
    mov rdi, qword _idt
    add rdi, rax

; Agora rdi contém o endereço de memória
; dentro da idt, onde desejamos contruir a entrada.

; Lidando com o endereço.
; Salva o endereço de 64bit em rdx.
    mov rdx, qword [__d__address] 
; low 16 
    mov rax, rdx 
    mov word  [__address_offset_15_0],  ax
; high 16
    mov rax, rdx
    shr rax, 16
    mov word  [__address_offset_31_16], ax
; high 32
    mov rax, rdx
    shr rax, 32
    mov dword [__address_offset_63_32], eax

;------------------
; Lembre-se: 
; rdi contém o endereço de memória
; dentro da idt, onde desejamos contruir a entrada.
; #bugbug
; Nao sei se essa operação eh possivel,
; mas queremos mover de double em double
; #bugbug
; Checar o que representa esse seletor.

;==========================
; Primeiros 32 bits. 
; (offset low and selector)
    xor rax, rax
    mov eax, dword 0x00080000            ; Step1: selector = 0x0008 = cs  na parte alta.
    mov ax, word  [__address_offset_15_0]  ; Step2: uma parte do endereço na parte baixa (16 bits)
    mov dword [rdi+0], eax
;=========================================
; segundos 32 bit.
    xor rax, rax
    mov ax, word [__address_offset_31_16]
    shl rax, 16
    ; 0x8E00 - (present, dpl=0, interrupt gate) (disable interrupts)
    ; These don’t clear IF, so interrupts can nest.
    mov ax, word 0x8E00
    mov dword [rdi+4], eax
;=========================================
; terceiros 32 bit.
    xor rax, rax
    mov eax, dword [__address_offset_63_32]
    mov dword [rdi+8], eax
;=========================================
; quartos 32 bit.
    xor rax, rax
    mov dword [rdi+12], eax
;-----------------

; Do not load.
; recarrega a nova idt
    ;lidt [IDT_register]

    pop rdx
    pop rcx
    pop rbx
    pop rax

    ret

__d__address:  dq 0
__d__number:   dq 0
;Offset address used in the function above.
__address_offset_15_0:  dw 0
__address_offset_31_16: dw 0
__address_offset_63_32: dd 0
;;--
;=============================================


;=============================================
; setup_faults:
;    Configura vetores da idt para faults.
; hw interrupts:
; see: hw1.asm

; using 0xEE00
; present, dpl=3, interrupt gate
; Interrupts desabled.

;  What 0xEE00 means
; + Type = 0xE → 64‑bit interrupt gate
; + DPL = 3 → Descriptor Privilege Level = 3 → user mode (ring 3) can invoke this gate
; + P = 1 → Entry is present
; + Behavior: 
;   Interrupt gates clear IF (disable maskable interrupts) on entry

; If you use 0xEE00 for faults
; + You’re saying: 
;   “user mode is allowed to call these exception vectors directly.”
; + That means a ring 3 program could execute INT 0x0 (divide error) 
;   or INT 0xD (GP fault) and jump straight into 
;   your kernel’s fault handler.
; + That’s usually not desirable, because it bypasses 
;   your syscall interface and lets user code trigger 
;   kernel exception handlers arbitrarily.
; + The CPU will still deliver real exceptions correctly, 
;   but you’ve opened up a way for user code to fake them.
;   >>> Good to build the handlers and test them <<<

; ============================================
; Execution Hall (Red)
; Fault/Exception IDT Setup
; Maps CPU faults (0–31) to handlers
; ============================================

setup_faults:
; We're using 0xEE00: (Permissive)
; Standard way: 0x8E00 (Restrict to ring 0)

    push rax
    push rbx

;#0
    mov rax, qword ExecutionHall_fault_N0
    mov rbx, qword 0
    call _setup_system_interrupt ; 0xEE00
;#1  
    mov rax, qword ExecutionHall_fault_N1
    mov rbx, qword 1
    call _setup_system_interrupt ; 0xEE00
;#2  
    mov rax, qword ExecutionHall_fault_N2
    mov rbx, qword 2
    call _setup_system_interrupt ; 0xEE00
;#3  debug
    mov rax, qword ExecutionHall_fault_N3
    mov rbx, qword 3
    call _setup_system_interrupt ; 0xEE00
;#4  
    mov rax, qword ExecutionHall_fault_N4
    mov rbx, qword 4
    call _setup_system_interrupt ; 0xEE00
;#5  
    mov rax, qword ExecutionHall_fault_N5
    mov rbx, qword 5
    call _setup_system_interrupt ; 0xEE00
;#6 - Invalid opcode
    mov rax, qword ExecutionHall_fault_INVALID_OPCODE
    mov rbx, qword 6
    call _setup_system_interrupt ; 0xEE00
;#7  
    mov rax, qword ExecutionHall_fault_N7
    mov rbx, qword 7
    call _setup_system_interrupt ; 0xEE00
;#8 - double fault
    mov rax, qword ExecutionHall_fault_DOUBLE
    mov rbx, qword 8
    call _setup_system_interrupt ; 0xEE00
;#9  
    mov rax, qword ExecutionHall_fault_N9
    mov rbx, qword 9
    call _setup_system_interrupt ; 0xEE00
;#10  
    mov rax, qword ExecutionHall_fault_N10
    mov rbx, qword 10
    call _setup_system_interrupt ; 0xEE00
;#11  
    mov rax, qword ExecutionHall_fault_N11
    mov rbx, qword 11
    call _setup_system_interrupt ; 0xEE00
;#12 - stack
    mov rax, qword ExecutionHall_fault_STACK
    mov rbx, qword 12
    call _setup_system_interrupt ; 0xEE00
;#13 - general protection
    mov rax, qword ExecutionHall_fault_GP
    mov rbx, qword 13
    call _setup_system_interrupt ; 0xEE00
;#14  
    mov rax, qword ExecutionHall_fault_N14
    mov rbx, qword 14
    call _setup_system_interrupt ; 0xEE00
;#15 
    mov rax, qword ExecutionHall_fault_N15
    mov rbx, qword 15
    call _setup_system_interrupt ; 0xEE00
;#16 
    mov rax, qword ExecutionHall_fault_N16
    mov rbx, qword 16
    call _setup_system_interrupt ; 0xEE00
;#17  
    mov rax, qword ExecutionHall_fault_N17
    mov rbx, qword 17
    call _setup_system_interrupt ; 0xEE00
;#18  
    mov rax, qword ExecutionHall_fault_N18
    mov rbx, qword 18
    call _setup_system_interrupt ; 0xEE00
;#19 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N19
    mov rbx, qword 19
    call _setup_system_interrupt ; 0xEE00
;#20 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N20
    mov rbx, qword 20
    call _setup_system_interrupt ; 0xEE00
;#21 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N21
    mov rbx, qword 21
    call _setup_system_interrupt ; 0xEE00
;#22 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N22
    mov rbx, qword 22
    call _setup_system_interrupt ; 0xEE00
;#23 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N23
    mov rbx, qword 23
    call _setup_system_interrupt ; 0xEE00
;#24 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N24
    mov rbx, qword 24
    call _setup_system_interrupt ; 0xEE00
;#25 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N25
    mov rbx, qword 25
    call _setup_system_interrupt ; 0xEE00
;#26 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N26
    mov rbx, qword 26
    call _setup_system_interrupt ; 0xEE00
;#27 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N27
    mov rbx, qword 27
    call _setup_system_interrupt ; 0xEE00
;#28 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N28
    mov rbx, qword 28
    call _setup_system_interrupt ; 0xEE00
;#29 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N29
    mov rbx, qword 29
    call _setup_system_interrupt ; 0xEE00
;#30 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N30
    mov rbx, qword 30
    call _setup_system_interrupt ; 0xEE00
;#31 - Intel reserved.
    mov rax, qword ExecutionHall_fault_N31
    mov rbx, qword 31
    call _setup_system_interrupt ; 0xEE00

    pop rbx
    pop rax
    ret  

;=====================================
; setup_vectors:
; Setup some hw and sw IDT vectors.
; see: hw1.asm

; Exceptions (0–31): untouched, reserved by the CPU.
; IOAPIC legacy IRQs (32–47): your timer, keyboard, RTC, mouse, IDE.
; Syscalls (128–199): your INT 0x80–0x83, plus 198/199 for callbacks and enabling interrupts.
; LAPIC LVT block (220–225): Timer, Perf, LINT0, LINT1, Error, Thermal.
; Spurious (255): safe handler with no EOI.

setup_vectors:

    push rax
    push rbx 

; using 0x8E00
; present, dpl=0, interrupt gate

; 32 - Timer
; This is a provisory handler.
; We're gonna recreate the handler at the end of the kernel initialization 
; by calling the worker _turn_task_switch_on in hw2.asm

    mov rax,  qword unhandled_irq
    mov rbx,  qword 32
    call _setup_system_interrupt_hw  ; 0x8E00


; 33 - PS2 Keyboard
    mov rax,  qword PeripheralHall_irq1
    mov rbx,  qword 33
    call _setup_system_interrupt_hw  ; 0x8E00

; 40 - Clock, RTC
    mov rax,  qword unhandled_irq
    mov rbx,  qword 40
    call _setup_system_interrupt_hw  ; 0x8E00

; fake nic
    ;mov rax,  qword unhandled_irq
    ;mov rbx,  qword 41
    ;call _setup_system_interrupt
    ;call _setup_system_interrupt_hw  ; 0x8E00

; 44 - PS2 Mouse
    mov rax,  qword PeripheralHall_irq12
    mov rbx,  qword 44
    call _setup_system_interrupt_hw  ; 0x8E00

; 46 - IDE
; irq 14
    ;mov rax,  qword unhandled_irq
    mov rax,  qword PeripheralHall_irq14
    mov rbx,  qword 46
    call _setup_system_interrupt_hw  ; 0x8E00

; 47 - IDE
; irq 15
    ;mov rax,  qword unhandled_irq
    mov rax,  qword PeripheralHall_irq15
    mov rbx,  qword 47
    call _setup_system_interrupt_hw  ; 0x8E00

;
; == System calls ===========================
;

; using EE00
; present, dpl=3, interrupt gate

; System interrupts
; see: sw1.asm
; 128 - 0x80
; 129 - 0x81
; 130 - 0x82
; 131 - 0x83

; 0x80
    mov rax,  qword RequestHall_int128
    mov rbx,  qword 128
    call _setup_system_interrupt ; 0xEE00
; 0x81
    mov rax,  qword RequestHall_int129
    mov rbx,  qword 129
    call _setup_system_interrupt  ; 0xEE00 
; 0x82
    mov rax,  qword RequestHall_int130
    mov rbx,  qword 130
    call _setup_system_interrupt  ; 0xEE00
; 0x83
    mov rax, qword RequestHall_int131
    mov rbx, qword 131
    call _setup_system_interrupt  ; 0xEE00
; ...

;========================
; The callback restorer.
; It is called by the ring 3 application
; after the callback routine ends. Delivering the control back
; to the kernel.
; #
; Temos que terminar a rotina do timer e
; retornarmos para ring 3 com o contexto o último contexto salvo.
; #todo
; Explain it better.
; See: sw2.asm and hw2.asm

    mov rax,  qword RequestHall_int198
    mov rbx,  qword 198
    call _setup_system_interrupt  ; 0xEE00 

; =====================
; Called by the ring3 process at the initialization
; to enable the maskable interrupts.
; It drops the iopl to ring 0.
; 32~255.
; The init process is the first ring3 process
; to call this interrupt, enabling the PIT itnerrupt
; for the first time and then we have the multithead working.
; Uma interrupção para habilitar as interrupções mascaráveis.
; quem usará isso será a thread primária 
; dos processos em ring3, apenas uma vez.
; See: sw.asm

    mov rax,  qword RequestHall_int199
    mov rbx,  qword 199
    call _setup_system_interrupt   ; 0xEE00


; === LAPIC local sources (LVT block starting at 220) ===


; 220–225
; (0xDC–0xE1) 

; 220 - LAPIC Timer (0xDC)
    mov rax, qword PeripheralHall_lapic_timer_handler
    mov rbx, qword 220
    call _setup_system_interrupt_hw  ; 0x8E00

; 221 - Performance Counter  (0xDD)
    mov rax, qword PeripheralHall_lapic_perf_handler
    mov rbx, qword 221
    call _setup_system_interrupt_hw  ; 0x8E00

; 222 - LINT0 (ExtINT) (0xDE)
    mov rax, qword PeripheralHall_lapic_lint0_handler
    mov rbx, qword 222
    call _setup_system_interrupt_hw  ; 0x8E00

; 223 - LINT1 (NMI) (0xDF)
    mov rax, qword PeripheralHall_lapic_nmi_handler
    mov rbx, qword 223
    call _setup_system_interrupt_hw  ; 0x8E00

; 224 - LAPIC Error (0xE0)
    mov rax, qword PeripheralHall_lapic_error_handler
    mov rbx, qword 224
    call _setup_system_interrupt_hw  ; 0x8E00

; 225 - Thermal sensor 225 (0xE1)
    mov rax, qword PeripheralHall_lapic_thermal_handler
    mov rbx, qword 225
    call _setup_system_interrupt_hw  ; 0x8E00

; CMCI (optional) 226 (0xE2)

; 255 - Spurious interrupt vector (SVR)
; Handler should just acknowledge and return.
    mov rax, qword PeripheralHall_spurious_handler
    mov rbx, qword 255
    call _setup_system_interrupt_hw  ; 0x8E00

    ;; ...

    pop rbx
    pop rax

    ret

;;=================================================
;; # NIC #
;; O kernel chma isso provisoriamente para criar uma entrada
;; na idt para o nic Intel.
;; #bugbug: isso está em nicintel.c, 
;; mas precisa ser global para que todos possam usar.
;; talvez em kernel.h
;; isso funcionou, tentar configurar outras interupções com isso.

;; Isso foi declarado em nicintel.c
;;pegaremos o valor 41 e o endereço do handler.
extern _nic_idt_entry_new_number
;extern _nic_idt_entry_new_address
extern _IDT_register

global _asm_nic_create_new_idt_entry
_asm_nic_create_new_idt_entry:

    push rax
    push rbx

    xor rax, rax
    xor rbx, rbx

;; Isso é o endereço da rotina de handler, em assembly;
;; está em hw.asm
;; #bugbug: não usaremos o endereço enviado pois temos que configurar 
;; o EOI e a pilha da rotina de handler.

    mov rax, qword PeripheralHall_irq9_nic_handler
    ;mov rax, qword [_nic_idt_entry_new_address]

; (41) ?
; Isso é o número da interrupção. 
; #bugbug: 
; Na virtualbox é 9 mas no qemu é 11?
; #todo
; We gotta get this number during the initialization
; and setup a valid number here not this hardcoded 41.

    ;mov rbx, qword [_nic_idt_entry_new_number]
    mov rbx, qword 41  ;32+9
    call _setup_system_interrupt_hw  ; 0x8E00

;; #test: 
;; Não sei se precisa carregar novamente.
;; ok, sem problemas.
    lidt [_IDT_register] 
    pop rbx
    pop rax
    ret 


; dirty: The registers are dirty.
global _asm_initialize_module0
_asm_initialize_module0:

    mov rdi, qword 1000   ; Reason = Initialize module.
    ;call _Module0EntryPoint
    ;call 0x30A00000
    ret

;=====================================
; _asm_reboot:
;     Reboot the system via ps2 keyboard.
; Steps:
; Wait for an empty Input Buffer with timeout, 
; but still send reboot command even if buffer stays busy.
;

PS2KEYBOARD_PORT        EQU  0x64
PS2KEYBOARD_CMD_REBOOT  EQU  0xFE

global _asm_reboot
_asm_reboot:

    xor rax, rax

; Timeout counter (arbitrary large value)
    mov rcx, 100000

; Get value and test status
; Testing for empty buffer with timeout.
.LNotEmpty:
    in al, PS2KEYBOARD_PORT
    test al, 00000010b
    je .LContinue ; Proceed if buffer becomes empty
    loop .LNotEmpty

; Continue sending the reboot command even if timeout occurs
.LContinue:

; (Write-Back and Invalidate Cache)
; Copy cache back to the main memory and invalidate cache.
; Forcing cache/RAM synchronization.
    wbinvd

; Send command
    mov al, PS2KEYBOARD_CMD_REBOOT
    out PS2KEYBOARD_PORT, al

    ret 

; Infinite loop to halt
;.Lloop:
;    cli
;    hlt
;    jmp .Lloop



;=====================================
; Wrapper for reboot function.
unit4_reboot:
    jmp _asm_reboot

; #test:
;Other atomic hardware primitives:
;    test and set (x86)
;    atomic increment (x86)
;    bus lock prefix (x86)
;global _atomic_increment_spinlock
;_atomic_increment_spinlock:
;    lock inc qword [__spinlock_test]
;    ret
;global _get_spinlock
;_get_spinlock:
;    mov rax, qword [__spinlock_test]
;    ret
;__spinlock_test: dq 0
;


; --------------------------------------------
; Go to user mode.
; It's used by the kernel when initializing the init process.
; See: x64init.c
; Parameters (System V ABI):
; IN
; 1) rsi → user stack pointer
; 2) rdi → entry point (RIP)

global _arch_enter_user_mode
_arch_enter_user_mode:

    xor rax, rax 
    mov ds, ax
    mov es, ax
    mov fs, ax
    mov gs, ax
    mov rbp, rax

; Get parameters:

    ; 1) Prepare the user stack
    mov rbx, rsi
    mov rsp, rbx

    ; 2) Prepare the entry point
    mov rax, rdi

    ; Prepare the stack frame
    push 0x23    ; Stack frame: SS
    push rsp     ; Stack frame: RSP
    push 0x3002  ; Stack frame: RFLAGS
    push 0x1B    ; Stack frame: CS
    push rax     ; Stack frame: RIP
    iretq 

