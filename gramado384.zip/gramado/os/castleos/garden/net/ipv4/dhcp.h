// dhcp.h
// DHCP protocol support.
// Created by Fred Nora.

// see:
// https://pt.m.wikipedia.org/wiki/Dynamic_Host_Configuration_Protocol

/*
discovery (descoberta)
offer (oferta)
request (pedido)
acknowledge (confirmação)
*/

#ifndef __PROT_DHCP_H
#define __PROT_DHCP_H    1


/*
What a DHCP client should store?
A minimal DHCP client state usually includes:
 + Your IP address (yiaddr) — the one the server gave you.
 + Server IP address (siaddr or option 54) — so you know who to talk to for renewals.
 + Lease time (option 51) — how long the IP is valid.
 + Renewal (T1) and Rebinding (T2) timers — when to send REQUESTs again.
 + Subnet mask, gateway, DNS servers — parsed from options.
 + Transaction ID (xid) — to match replies with requests.
 + MAC address — already in your struct, but useful for validation.
*/

// Save information about the dhcp initialization.
struct dhcp_info_d
{

// We have the info given to us by the server.
// This is set TRUE only after the ACK.
    int initialized;

// 1,2,3,4 (DORA)
    unsigned int Step;

// Client info: (US) 
    uint8_t your_ipv4[4];  // Your IP. We got it from the server.
    uint8_t your_mac[6];   // Our NIC MAC

// Server info: (SERVER)
    uint8_t server_ipv4[4];  // The server IP.
    uint8_t server_mac[6];   // The server MAC.


// Integer. Host byte order
    unsigned int your_ipv4_int;

    // Lease management
    uint32_t lease_time;    // Option 51: seconds
    uint32_t renew_time;    // T1 (usually 50% of lease)
    uint32_t rebind_time;   // T2 (usually 87.5% of lease)


    unsigned int subnet_mask_int;
    unsigned int gateway_ipv4_int;

    // Network configuration
    uint8_t subnet_mask[4];   // Option 1
    uint8_t gateway_ipv4[4];  // Option 3 (router)
    uint8_t dns_ipv4[4];      // Option 6 (first DNS)

// Transaction tracking
// Think of it as the “conversation tag” between the client and the server.
    uint32_t xid;           // Last transaction ID
};
// see: dhcp.c
extern struct dhcp_info_d  dhcp_info;


// Message Types

#define DHCP_DISCOVER  1  // D
#define DORA_D  DHCP_DISCOVER

#define DHCP_OFFER  2  // O
#define DORA_O  DHCP_OFFER

#define DHCP_REQUEST  3  // R
#define DORA_R  DHCP_REQUEST

#define DHCP_DECLINE  4

#define DHCP_ACK  5  // A
#define DORA_A  DHCP_ACK

#define DHCP_NAK  6
#define DHCP_RELEASE  7
#define DHCP_INFORM  8


/*
Client-Sent Messages:
DHCP Discover (D) – Client broadcasts to find a DHCP server.
DHCP Request (R)  – Client requests an offered IP or renews a lease.
DHCP Decline (4)  – Client rejects an IP due to conflict.
DHCP Release (7)  – Client gives up its leased IP.

Server-Sent Messages:
DHCP Offer (O)             – Server offers an available IP.
DHCP Acknowledge (A / ACK) – Server confirms lease.
DHCP Nak (6)               – Server rejects the request.
DHCP Inform (8)            – Server provides extra configuration details.
*/

//
// Options codes.
//

#define OPT_PAD          0
#define OPT_SUBNET_MASK  1
#define OPT_ROUTER       3
#define OPT_DNS          6

#define OPT_REQUESTED_IP_ADDR  50
#define OPT_LEASE_TIME         51
#define OPT_DHCP_MESSAGE_TYPE  53
#define OPT_SERVER_ID          54
#define OPT_PARAMETER_REQUEST  55

#define OPT_END    255

#define OPTIONS_SIZE    (312 - 4)

// dhcp header
struct dhcp_d
{
    unsigned char op;
    unsigned char htype;  // Ethernet
    unsigned char hlen;   // 6
    unsigned char hops;

    unsigned int xid;

    unsigned short secs;   //timing
    unsigned short flags; 

    unsigned int ciaddr;  // Client IP Address
    unsigned int yiaddr;  // Your IP Address
    unsigned int siaddr;  // Server IP Address
    unsigned int giaddr;  // Gateway IP Address switched by relay

// chaddr: Client hardware address.
    unsigned char chaddr[16];

// sname: 
// Server host name, from which the client obtained configuration parameters.
    unsigned char sname[64];

// file: Bootfile name and path information, defined by the server to the client.
    unsigned char file[128];

// This field identifies the mode in which 
// the succeeding data is to be interpreted.
    unsigned int magic_cookie;
    unsigned char options[OPTIONS_SIZE];

} __attribute__ ((packed));

// ------------------------------

void network_show_dhcp_info(void);

void network_save_dhcp_server_id( uint8_t ip[4] );

void 
network_dhcp_send(
    struct dhcp_d *dhcp,
    int message_type, 
    uint8_t source_ip[4], 
    uint8_t target_ip[4], 
    unsigned short sport, 
    unsigned short dport );


//
// $
// INITIALIZATION
//

int network_initialize_dhcp(void);

//
// $
// HANDLER
//

void 
network_handle_dhcp( 
    const unsigned char *buffer, 
    ssize_t size );


#endif    


