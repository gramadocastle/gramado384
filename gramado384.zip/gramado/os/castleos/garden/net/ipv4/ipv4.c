// ipv4.c
// Created by Fred Nora.

#include <kernel.h>


static unsigned int ipv4_counter = 0;


// ======================================================

// Buffers: [ethernet, ipv4, data]
int 
ipv4_send (
    unsigned char protocol, 
    uint8_t source_ip[4], 
    uint8_t target_ip[4], 
    uint8_t target_mac[6],
    const char *data_buffer,  // IPV4 payload
    size_t data_lenght )      // IPV4 payload size
{
    int Status = -1;

    // Local headers
    struct ethernet_d  Leh;
    struct ip_d  Lipv4;

//
// The frame
//

    // Getting the Options size!
    // uint8_t header_length = (ip->v_hl & 0x0F) * 4;  // in bytes
    // size_t OptionsSize = header_length - IP_HEADER_LENGHT;


// #todo
// The header can actually vary between 20 and 60 bytes 
// depending on the presence of options.

    size_t OptionsSize = 0;
    size_t SizeOfIPHeader = IP_HEADER_LENGHT + OptionsSize;

    // Th whole frame, needed by ethernet_send()
    size_t FRAME_SIZE = 
               ( ETHERNET_HEADER_LENGHT +\
                 SizeOfIPHeader +\
                 data_lenght );

    // Ethernet MTU is usually 1500 bytes.
    // Add Ethernet + IPv4 headers for safety.
    size_t MAX_FRAME_SIZE = 
        (ETHERNET_HEADER_LENGHT + SizeOfIPHeader + 1500);

    // Local buffer for the whole frame
    uint8_t frame[MAX_FRAME_SIZE];

    register int i=0;

// The frame can't be bigger than the buffer we created.
    if (FRAME_SIZE > MAX_FRAME_SIZE)
    {
        printk("ipv4_send: Frame too large (%d)\n", FRAME_SIZE);
        goto fail;
    }

    // The current Intel NIC device
    if ((void*) currentNIC == NULL){
        panic ("ipv4_send: currentNIC");
    }
    if (currentNIC->magic != 1234){
        panic ("ipv4_send: currentNIC magic");
    }


// ==============================================

//
// ETHERNET header
//

// Ethernet base
// Destination MAC, Our MAC and Type of protocol.

    for (i=0; i<6; i++){
        Leh.mac_src[i] = (uint8_t) currentNIC->mac_address[i];  // source 
        Leh.mac_dst[i] = (uint8_t) target_mac[i];               // dest
    };
    Leh.type = (uint16_t) ToNetByteOrder16(ETHERTYPE_IPV4);
    // Push
    memcpy (  
        frame,   // At the base of the buffer
        &Leh, 
        ETHERNET_HEADER_LENGHT 
    );

// ==============================================

//
// IPV4 header
//

    // The Ipv4 header
    //hdr->ihl = 5;
    //hdr->ver = 4;
    //hdr->tos = 0;


// - Version (8bits)
// - IHL (4bits). Lenght of the header in chuncks of 4 bytes. 
//  The lower 4 bits (IHL) must reflect the header length in 32‑bit words.
    //Lipv4.v_hl = 0x45;    // 8 bit
    // #test
    //uint8_t ihl_words = (IP_HEADER_LENGHT + OptionsSize) / 4;
    uint8_t ihl_words = (SizeOfIPHeader / 4);
    Lipv4.v_hl = (4 << 4) | (ihl_words & 0x0F);


// Type of service (8bits)
// - Differentiated Services Code Point (6bits)
// - Explicit Congestion Notification (2bits)
    Lipv4.ip_tos = 0x00;  // 8 bit (0=Normal)

// Lenght
// IPV4 Length
// ip + (ip payload)
// 16 bit
// This 16-bit field defines the entire packet size in bytes, 
// including header and data. 
// The minimum size is 20 bytes (header without data) and the maximum is 65,535 bytes. 
// ip header + (udp header + data).
// #todo: Check if it is right?
// No payload do ip temos o (udp+data)
// O lenght do protocolo precisa conter o seu proprio header e o seu proprio payload.

    // Total length = IPv4 header + data_length
    // (data_length already includes protocol header + payload)
    uint16_t __ip_len = SizeOfIPHeader + (uint16_t) data_lenght;
    Lipv4.ip_len = ToNetByteOrder16(__ip_len);


// Identification
// ... identifying the group of fragments of a single IP datagram. 
// 16 bit

    Lipv4.ip_id = ToNetByteOrder16(ipv4_counter);
    ipv4_counter++;

    Lipv4.ip_off = ToNetByteOrder16(0x4000);  //htons(0x4000);
    Lipv4.ip_ttl = 64;
    // This is the protocol identifier inside the IPv4 header. 
    // It tells the receiver what the payload actually is (TCP, UDP, ICMP, etc.). 
    Lipv4.ip_p = protocol;
    Lipv4.ip_sum = 0;   // Checksum


//
// addresses
//

    //network_fill_ipv4(hdr->src, source_ip);
    //network_fill_ipv4(hdr->dst, target_ip);

    unsigned char *spa = (unsigned char *) &Lipv4.ip_src.s_addr;
    unsigned char *tpa = (unsigned char *) &Lipv4.ip_dst.s_addr;
    for (i=0; i<4; i++){
        spa[i] = (uint8_t) source_ip[i]; 
        tpa[i] = (uint8_t) target_ip[i]; 
    };


//
// Checksum
//

    Lipv4.ip_sum = 0;
    Lipv4.ip_sum =
         (uint16_t)  net_checksum(
              0, 
              0,
              (const unsigned char *) &Lipv4, 
              (const unsigned char *) &Lipv4 + sizeof(struct ip_d) );
    Lipv4.ip_sum =
         (uint16_t) ToNetByteOrder16(Lipv4.ip_sum);


    // Push
    memcpy (
        frame + ETHERNET_HEADER_LENGHT,  // Right after the ethernet header
        &Lipv4, 
        SizeOfIPHeader 
    );

    // #debug
    // printk("ip_sum={%x} \n",Lipv4.ip_sum);
    // printk ("size %d\n", sizeof (struct ip_d) );
    // refresh_screen();
    // while(1){}

    // -------------------------------
    // Payload

    memcpy (
        frame + ETHERNET_HEADER_LENGHT + SizeOfIPHeader,  // Right after the ip header
        data_buffer, 
        data_lenght
    );


//
// SEND
//

// Send frame via hardware
// #bugbug: That is not the right pointer

// We are building the ethernet header, the ipv4 header and 
// we received the ipv4 payload pointer and size. 
// We need put these blocks together at the end of the routine.

    Status = (int) ethernet_send(FRAME_SIZE, (const char*) frame);
    if (Status < 0){
        goto fail;
    }

    return 0;  // OK

fail:
    return (int) -1;
}

//
// $
// HANDLER
//

// When receving IPV4 packet from NIC device.
// handle ipv4 package
// IN:
// buffer = ip header base address.
// size = ip packet size. (ip header + ip payload).
// Network layer.
// Called by network_on_receiving() in network.c.
// 0x0800

void 
network_handle_ipv4( 
    const unsigned char *buffer, 
    ssize_t size )
{
    struct ip_d *ip;     // The buffer
    uint8_t Protocol=0;  // The protocol for the payload
    // Payload
    unsigned char *payload_base;
    ssize_t PayloadSize;

    int UseFirewall = FALSE;
    int FirewallStatus = FALSE;

    //printk ("IP: received\n");

// #warning
// It's ok to use pointer here.
// We're not allocating memory, we're using 
// a pre-allocated buffer.

    // ip
    ip = (struct ip_d *) buffer;
    if ((void*) ip == NULL){
        printk("network_handle_ipv4: ip\n");
        goto fail;
    }
    // size
    if (size <= 0){
        printk("network_handle_ipv4: size 0\n");
        goto fail;
    }
    if ( size < sizeof(struct ip_d) ){
        printk("network_handle_ipv4: size\n");
        goto fail;
    }
    // The minimum size.
    // Only the ip header.
    //if (size < IP_HEADER_LENGHT){
    //    printk("network_handle_ipv4: size\n");
    //    goto fail;
    //}

// IP
// #todo
// Let's save it for future use.
// We're gonna need to send responses.

    unsigned char *src_ipv4 = (unsigned char *) &ip->ip_src.s_addr;
    unsigned char *dst_ipv4 = (unsigned char *) &ip->ip_dst.s_addr;

    // Array
    // Save the IP of the caller.
    // For fast response.
    network_fill_ipv4( NetworkSaved.caller_ipv4, src_ipv4 );

    // Integer
    // Grab client IP directly
    NetworkSaved.caller_ip_int = FromNetByteOrder32(ip->ip_src.s_addr);
    NetworkSaved.target_ip_int = FromNetByteOrder32(ip->ip_dst.s_addr);

//If source IP = 0 → 
//You don’t know who the peer is. 
//You cannot establish a connection. Drop the packet or log an error.
//If destination IP = 0 → 
//You don’t know which local endpoint this packet is for. Drop it.
//If both are 0 → 
//Treat as invalid input. Do not attempt handshake.


// #debug: 
// Catching broadcast

/*
    if ( dst_ipv4[0]==255 && 
         dst_ipv4[1]==255 &&
         dst_ipv4[2]==255 && 
         dst_ipv4[3]==255) 
    {
        printk("IPv4: Global broadcast IP received\n");
    }
*/

/*
    if ( dst_ipv4[0]==192 && 
         dst_ipv4[1]==168 &&
         dst_ipv4[2]==1 && 
         dst_ipv4[3]==255) 
    {
        printk("IPv4: Subnet broadcast IP received\n");
    }
*/


// Show data.
// Bytes: Net-style.
// Header lenght: 5 = 20 bytes
// header length in 32-bit words

    uint8_t v_hl = (uint8_t) ip->v_hl;
    uint8_t Lenght  = (uint8_t) ((v_hl)      & 0x0F);  // IHL
    uint8_t Version = (uint8_t) ((v_hl >> 4) & 0x0F);

    // Convert IHL to bytes
    // #important: It includes the Options size
    uint8_t header_length = (Lenght * 4);

    // For now, OptionsSize = 0
    // size_t OptionsSize = 0;
    size_t OptionsSize = header_length - IP_HEADER_LENGHT;
    if (OptionsSize > 0) {
        printk("IPv4: Options present, size=%d bytes\n", OptionsSize);
    }

    //printk("IP Version: {%d}\n", Version);
    //printk("Header lenght: {%d}\n", Lenght);

    if (Version != 4){
        printk("IP: Not version 4\n");  goto fail;
    }

// Total lenght (16bits)
// ip header + ip payload.
// (IP + (TCP + data)) given in bytes.
// 20~65535
// #bugbug
// What is the style of this information?
// little endian?

    uint16_t ip_lenght = (uint16_t) FromNetByteOrder16(ip->ip_len);
    //printk("Total lenght: {%d}\n", ip_lenght);
    if (ip_lenght < 20 || ip_lenght > 65535)
    {
        //#debug
        printk("IP: size={%d}\n",size);
        printk("IP: ip_lenght={%d}\n",ip_lenght);
        // #todo:
        // Maybe simply drop it for now.
        panic("IP: Bad total lenght #debug\n");
    }

// Payload

    // payload_base = (buffer + IP_HEADER_LENGHT);
    // PayloadSize = (ip_lenght - IP_HEADER_LENGHT);

    payload_base = buffer + header_length;
    PayloadSize  = ip_lenght - header_length;


    //printk ("target: %d.%d.%d.%d \n",
    //    dst_ipv4[0],dst_ipv4[1],dst_ipv4[2],dst_ipv4[3]);
    //printk("ip_sum={%x} \n",ip->ip_sum);

//
// Protocol
//

// List of IP protocol numbers
// See:
// https://en.wikipedia.org/wiki/List_of_IP_protocol_numbers

// 0x01 -  1 - ICMP - Internet Control Message Protocol
// 0x06 -  6 - TCP  - Transmission Control Protocol
// 0x11 - 17 - UDP  - User Datagram Protocol

    Protocol = (uint8_t) ip->ip_p;
    //printk("Protocol: {%xH}\n",Protocol);

    switch (Protocol){
    case PROTOCOL_IP_TCP:
        if (UseFirewall == TRUE)
        {
            FirewallStatus = 
                firewall_apply_tcp_filters(
                    payload_base, 
                    PayloadSize,
                    NetworkSaved.caller_ip_int,  // s_ipv4_int
                    NetworkSaved.target_ip_int   // d_ipv4_int
            );
            if (FirewallStatus < 0)
            {
                // Do something ... drop, log etc ...
            }
        }
        // Call the handler
        network_handle_tcp( 
            payload_base, 
            PayloadSize,
            NetworkSaved.caller_ip_int,  // s_ipv4_int
            NetworkSaved.target_ip_int   // d_ipv4_int
        );
        return;
        break;
    case PROTOCOL_IP_UDP:
        network_handle_udp(payload_base, PayloadSize);
        return;
        break;
    // Not supported ipv4 protocol.
    //case PROTOCOL_IP_ICMP:
    // ...
    default:
        goto drop;
        break;
    };

// Something went wrong!
    goto fail;

drop:
    return;

// debug:
// ---------------
// Not to me.
    /*
    if ( dst_ipv4[3] != 12 ||
         dst_ipv4[2] != 1 ||
         dst_ipv4[1] != 168 ||
         dst_ipv4[0] != 192 )
    {
        printk ("IP: NOT TO ME. Drop it\n");
        return;
    }
    */

// ---------------
// To me.

    //printk ("IP: TO ME!\n");
    //printk("Src IPV4: {%x}\n", ip->ip_src.s_addr);
    //printk("Dst IPV4: {%x}\n", ip->ip_dst.s_addr);
    // destination

    /*
    printk ("Src: %d.%d.%d.%d\n",
        src_ipv4[0], src_ipv4[1], src_ipv4[2], src_ipv4[3]);
    printk ("Dst:  %d.%d.%d.%d\n",
        dst_ipv4[0], dst_ipv4[1], dst_ipv4[2], dst_ipv4[3]);

    // hang
    printk("network_handle_ipv4: #breakpoint :)\n");
    while (1){
    };
    */

fail:
    printk("network_handle_ipv4: Fail\n");
    return;
}



