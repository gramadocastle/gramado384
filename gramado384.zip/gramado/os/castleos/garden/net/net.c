// net.c
// Network layer. (IP)
// Transport layer. (TCP/UDP/...)
// Created by Fred Nora.

#include <kernel.h>

struct network_initialization_d  NetworkInitialization;

static unsigned long on_receiving_counter=0;
static unsigned long on_sending_counter=0;

// See: net.h
unsigned long connectionList[MAX_CONNECTIONS];


// Status para notificações.
// Podemos ou não notificar os processo sobre os eventos de rede.
// O shell vai habilitar essa notificação no momento em que
// envia um stream para mensagens de texto.
int notification_status=FALSE;

// Usado por esse módulo.
file *____network_file;

// Network buffer 11888 (system port)
// This is a static queue of buffers for 
// the system port 11888 using UDP
// See: net.h
struct network_buffer_d  nb_rx_11888;

struct host_info_d *HostInfo;
struct network_info_d *NetworkInfo;

// #todo: Use 'const char*'
char *default_network_name_string = "default-network-name";
char *default_network_version_string = "0.0.0";


// Used for fast responses
struct network_saved_d  NetworkSaved;


// ====================================================


static void __maximize_ds_priority(pid_t pid);
static struct connection_d *__create_connection_object(void);
static int __connection_get_free_slot(void);

// ====================================================






// ep
// Allocates and initializes a single endpoint (endpoint_d).
struct endpoint_d *create_endpoint_object(void)
{
    struct endpoint_d *new_ep;

    new_ep = (void *) kmalloc( sizeof(struct endpoint_d) );
    if ((void *) new_ep ==  NULL){
        printk("create_endpoint_object: new_ep\n");
        goto fail;
    }
    memset( new_ep, 0, sizeof(struct endpoint_d) );
    // Validation
    new_ep->used = TRUE;
    new_ep->magic = 1234;
    new_ep->is_remote = FALSE;
    new_ep->socket = NULL;  // socket
    return (struct endpoint_d *) new_ep;

fail:
    return NULL;
};

// ep pair
// Couples endpoints into a pair (endpoint_pair_d).
struct endpoint_pair_d *create_endpoint_pair_object(void)
{
    struct endpoint_pair_d *new_epp;

    new_epp = (void *) kmalloc( sizeof(struct endpoint_pair_d) );
    if ((void *) new_epp ==  NULL){
        printk("create_endpoint_pair_object: new_epp\n");
        goto fail;
    }
    memset( new_epp, 0, sizeof(struct endpoint_pair_d) );
    // Validation
    new_epp->used = TRUE;
    new_epp->magic = 1234;
    new_epp->case_id = 0;
    new_epp->s_ep = NULL;
    new_epp->c_ep = NULL;
    return (struct endpoint_pair_d *) new_epp;

fail:
    return NULL;
};

// Internal helper to allocate a generic connection_d.
// Create the connection structure, a typeless structure.
static struct connection_d *__create_connection_object(void)
{
    struct connection_d *new_conn;

    new_conn = (void *) kmalloc(sizeof(struct connection_d));
    if (!new_conn) {
        printk("__create_connection_object: new_conn\n");
        goto fail;
    }
    memset(new_conn, 0, sizeof(struct connection_d));

    // Validation
    new_conn->used   = TRUE;
    new_conn->magic  = 1234;
    new_conn->id     = -1;  // not registered yet
    new_conn->type   = CONN_TYPE_NONE;  // default to NONE for now
    new_conn->status = CONN_STATUS_NONE;
    new_conn->ep_pair = NULL;
    new_conn->tcp_conn = NULL;  // will be allocated later if needed

    return new_conn;

fail:
    return NULL;
}

// Public function to create a connection of a given type 
// (currently only TCP fully supported).
// Create connection given a type (TCP, UDP, etc). 
// Returns NULL on failure.
struct connection_d *create_connection(int type)
{
    struct connection_d *new_conn;

// #todo: 
// For now we are only supporting TCP connections. 
// We can add support for UDP and others later.
    if (type != CONN_TYPE_TCP) {
        printk("create_connection: unsupported type %d\n", type);
        return NULL;
    }

    // Create a typeless connection object first
    new_conn = (void *) __create_connection_object();
    if (!new_conn) {
        printk("create_connection: new_conn\n");
        goto fail;
    }

    new_conn->id = -1;  // not registered yet
    new_conn->type = type;  //CONN_TYPE_TCP;   // default to TCP for now
    new_conn->status = CONN_STATUS_NONE;

// ep pair will be set later when endpoints are created and linked
    new_conn->ep_pair = NULL;


    // :: TCP
    if (type == CONN_TYPE_TCP){
        // Allocate TCP state machine
        new_conn->tcp_conn = (struct tcp_connection_d *) kmalloc(sizeof(struct tcp_connection_d));
        if (!new_conn->tcp_conn) {
            printk("__create_connection_object: tcp_conn\n");
            //kfree(new_conn);
            goto fail;
        }
        memset(new_conn->tcp_conn, 0, sizeof(struct tcp_connection_d));

        // Initialize TCP state
        new_conn->tcp_conn->state = TCP_CLOSED;
        new_conn->tcp_conn->snd_wnd = 0;
        new_conn->tcp_conn->rcv_wnd = 0;
        // other fields will be set during handshake

    // :: LOCAL
    } else if (type == CONN_TYPE_LOCAL){
        // For other types, we can add support later
        new_conn->tcp_conn = NULL;
        printk("create_connection: type %d not fully supported yet\n", type);

    // :: INVALID
    } else {
        // For other types, we can add support later
        new_conn->tcp_conn = NULL;
        printk("create_connection: type %d not fully supported yet\n", type);
    };

    new_conn->packets_sent = 0;
    new_conn->packets_received = 0;

    // Validation
    new_conn->used = TRUE;
    new_conn->magic = 1234;

    return (struct connection_d *) new_conn;

fail:
    return NULL;
}



// Find a free spot in connectionList[]
// Returns index or -1 if full
static int __connection_get_free_slot(void)
{
    int i;
    for (i = 0; i < MAX_CONNECTIONS; i++) {
        if (connectionList[i] == 0) {
            return i;  // free slot found
        }
    }
    return -1; // no free slot
}

// Places the connection into the global connectionList[].
int connection_register(struct connection_d *conn)
{
    if (!conn) 
        return -1;

    int slot = __connection_get_free_slot();
    if (slot < 0) {
        printk("connection_register: no free slot\n");
        return -1;
    }

    conn->id = slot;
    connectionList[slot] = (unsigned long) conn;

    return (int) slot;
}

// Retrieves a connection by ID.
struct connection_d *get_connection(int id)
{
    if (id < 0 || id >= MAX_CONNECTIONS) {
        printk("get_connection: invalid id %d\n", id);
        return NULL;
    }

    struct connection_d *conn = (struct connection_d *) connectionList[id];
    if (!conn) {
        printk("get_connection: no connection at id %d\n", id);
        return NULL;
    }
    if (conn->used != TRUE || conn->magic != 1234) {
        printk("get_connection: corrupted entry at id %d\n", id);
        return NULL;
    }

    return conn;
}

// Debug utility to print all active connections.
// Walk the connection list and print valid ones (magic == 1234).
void network_show_connections(void)
{
    printk("\n--- Connection List ---\n");

    int i;
    int count = 0;
    for (i=0; i < MAX_CONNECTIONS; i++) 
    {
        struct connection_d *conn = (struct connection_d *) connectionList[i];
        if (!conn) 
            continue;
        if ( conn->used == TRUE && conn->magic == 1234) 
        {
            printk("%d: type=%d | status=%d sent=%d received=%d\n",
                conn->id, conn->type, conn->status, 
                conn->packets_sent, conn->packets_received );

            count++;
        }
    }

    printk("Total valid connections: %d\n", count);
    //printk("--- End of List ---\n");
}

// Return client socket from connection
struct socket_d *get_client_socket_from_connection(struct connection_d *conn)
{
    struct socket_d *sk;

    if (!conn)
        return NULL;
    if (!conn->ep_pair)
        return NULL;
    if (!conn->ep_pair->c_ep){
        return NULL;
    }
    sk = conn->ep_pair->c_ep->socket;

    return sk;
}

// Return server socket from connection
struct socket_d *get_server_socket_from_connection(struct connection_d *conn)
{
    struct socket_d *sk;

    if (!conn)
        return NULL;
    if (!conn->ep_pair) 
        return NULL;
    if (!conn->ep_pair->s_ep){ 
        return NULL;
    }
    sk = conn->ep_pair->s_ep->socket;

    return sk;
}




// Network interface for keyboard input.
int 
network_keyboard_event( 
    int event_id,
    long long1, 
    long long2 )
{
    if (event_id < 0)
        goto fail;
// Send it to the event broker.
// See: wink/evi/ibroker.c
    wmKeyboardEvent( event_id, (long) long1, (long) long2 );
    return 0;
fail:
    return (int) -1;
}

// Network interface for mouse input.
int 
network_mouse_event( 
    int event_id, 
    long data1, 
    long data2 )
{
    //int __event_id = (int) event_id;
    //long __data1 = data1;
    //long __data2 = data2;

// Event validation
    if (event_id < 0)
        goto fail;
    switch (event_id){
    // Valid events
    case MSG_MOUSEPRESSED:   break;
    case MSG_MOUSERELEASED:  break;
    case MSG_MOUSEMOVE:      break;
    // Invalid events
    default:
        goto fail;
        break;
    };

// Send it to the event broker.
// See: wink/evi/ibroker.c
// #todo: the parameters long3 and long4

    wmMouseEvent( event_id, data1, data2, 0, 0 );

    return 0;
fail:
    return (int) -1;
}

// #test
// Changing the window server's quantum. 
// The purpose here is boosting it when it is trying to register itself.
// class 1: Normal threads.
static void __maximize_ds_priority(pid_t pid)
{
    struct te_d *p;
    struct thread_d *t;

    unsigned long ProcessType         = PROCESS_TYPE_SYSTEM;
    unsigned long ProcessBasePriority = PRIORITY_SYSTEM_THRESHOLD;
    unsigned long ProcessPriority     = PRIORITY_MAX;

    unsigned long ThreadType         = ProcessType;
    unsigned long ThreadBasePriority = ProcessBasePriority;
    unsigned long ThreadPriority     = ProcessPriority;

// PID

    // Get PID for the current process for a given core.
    // IN: core id

    pid_t current_process = (pid_t) get_current_process(0);

    if (pid<=0 || pid >= PROCESS_COUNT_MAX){
        return;
    }
    if (pid != current_process){
        debug_print ("__maximize_ds_priority: pid\n");
        panic       ("__maximize_ds_priority: pid\n");
    }

// -------------------------
// process
    p = (struct te_d *) teList[pid];
    if ((void*)p == NULL)
        return;
    if (p->used!=TRUE)
        return;
    if (p->magic!=1234)
        return;

    p->type = ProcessType;
    p->base_priority = ProcessBasePriority;
    p->priority      = ProcessPriority;

// -------------------------
// thread
    t = (struct thread_d *) p->flower;
    if ((void*) t == NULL){ return; }
    if (t->magic != 1234) { return; }

    t->type = ThreadType;
    t->base_priority = ThreadBasePriority;
    t->priority      = ThreadPriority;
// see: sched.h
    t->quantum = QUANTUM_MAX;

}


//
// Register main system components
//

// + Display server
// + Network server
// + OS Shell (explorer/taskbar)
// + Default browser
// ...


// -------------------------------------------
// Display server: (Service: sci0 513)
// 513 - SYS_SET_DS_PID
// Register display server into a given valid cgroup.
// Register display server into a given valid cgroup.
// Called by sci.c
// See: dispsrv.h
int 
network_register_ring3_display_server(
    struct cgroup_d *cg,
    pid_t caller_pid )
{

    // #todo:
    // Maybe we can move the workers for this job from here to dispsrv.c.
    // Keeping here only the wrapper.

    // Process
    struct te_d *p;
    pid_t current_process = (pid_t) -1;

    // Thread
    struct thread_d *t;

// Parameters: 

    // cgroup
    if ((void*) cg == NULL)
        goto fail;
    if (cg->magic != 1234)
        goto fail;
    
    // caller pid
    if (caller_pid < 0 || caller_pid >= PROCESS_COUNT_MAX)
        goto fail;

//
// Current process
// 

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        panic("network_register_ring3_display_server: current_process\n");
    }
    p = (struct te_d *) teList[current_process];
    if ((void*) p == NULL)
        panic("network_register_ring3_display_server: p\n");
    if (p->magic != 1234)
        panic("network_register_ring3_display_server: p magic\n");

// Parameter: Caller PID.
// Invalid caller PID.
    if (caller_pid != current_process){
        panic("network_register_ring3_display_server: caller_pid\n");
    }

//
// Save
//

// Savint the pointer to the display server process into a global variable

    TEDisplayServerProcess = (struct te_d *) p;

// Let's setup who own the primary display device.
// 'System display device'
// The owner pid.

    if ((void*) primary_display_device != NULL)
    {
        if (primary_display_device->magic == 1234)
        {
            primary_display_device->owner_pid = (pid_t) current_process;
        }
    }


// Saving the display server PID into the cgroup structure.
// Register_ws_process(current_process);
    cg->service_display_server.pid = (pid_t) current_process;

// #todo: Maybe this method belongs to the sys_bind() routine.
// #ps: This is the Display Server.
    socket_set_gramado_server_pid( 
        GRAMADO_PORT_DS, 
        (pid_t) current_process 
    );

// Initialize DisplayServerInfo structure.
// See: dispsrv.h and dispsrv.c.
    int ds_status = -1;
    ds_status = (int) dispsrv_setup_ds_info(current_process);
    if (ds_status < 0){
        printk("on dispsrv_setup_ds_info()\n");
        goto fail;
    }

// Setup the process priority
    __maximize_ds_priority(current_process);


// #test:
// Change the session type for this console.
// #ps: With this new session type, printf will not be allowed
// to access the display device.

    console_set_session_type(CONSOLE0, TTY_SESSION_TYPE_GUI);

// #test:
// Change the foreground console.

    console_set_current_virtual_console(CONSOLE0);

// #todo
// Maybe we can associate a console to the display server process.
// In this case no other process will be able to access the display device.
// Only if the process invokes a syscall that stops the display server/compositor,
// and allow the process to take the control of the display device.
// ex: applications like games, video players, etc. 
// will be able to take the control of the display device.

// #test:
// Is the flower thread valid?
    t = p->flower;
    if ((void*) t == NULL)
        goto fail;
    if (t->magic != 1234)
        goto fail;


// flags
    t->flags |= TF_SYSTEM_THREAD;
    // ...

// #test
    t->pe_mode = PE_MODE_PERFORMANCE;

// Change the input authority
// Who will be able to setup the current foreground thread.
// Funtamental for the input system.
    InputAuthority.current_authority = AUTH_DISPLAY_SERVER;

// No more input to the stdin. Terminal reads from another place.
    ///InputTargets.target_stdin = FALSE;

    return TRUE;

fail:
    return (int) -1;
}
//---


// -------------------------------------------
// Network server:
// (Server)
int 
network_register_ring3_network_server(
    struct cgroup_d *cg,
    pid_t caller_pid )
{
    return -1;
}

// -------------------------------------------
// OS Shell (explorer/taskbar)

int 
network_register_ring3_osshell(
    struct cgroup_d *cg,
    pid_t caller_pid )
{
    return -1;
}

// -------------------------------------------
// Default browser: (service: sc0 518)
// Register browser into a given valid cgroup.
int 
network_register_ring3_browser(
    struct cgroup_d *cg,
    pid_t caller_pid )
{
// 513 - SYS_SET_DS_PID
// Syscall implementation.

    struct te_d *p;
    pid_t current_process = (pid_t) -1;
    struct thread_d *t;

// Parameter: cgroup
    if ((void*) cg == NULL)
        goto fail;
    if (cg->magic != 1234)
        goto fail;

//
// Current process
// 

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if ( current_process < 0 || current_process >= PROCESS_COUNT_MAX )
    {
        panic("network_register_ring3_display_server: current_process\n");
    }
    p = (struct te_d *) teList[current_process];
    if ((void*) p == NULL)
        panic("network_register_ring3_display_server: p\n");
    if (p->magic != 1234)
        panic("network_register_ring3_display_server: p magic\n");

// Parameter: Caller PID.
// Invalid caller PID.
    if (caller_pid != current_process){
        panic("network_register_ring3_display_server: caller_pid\n");
    }

// Saving the browser PID into the cgroup structure.
// Register_ws_process(current_process);
    cg->service_default_browser.pid = (pid_t) current_process;

// #todo
// Maybe this method belongs to the sys_bind() routine.
    socket_set_gramado_server_pid( 
        GRAMADO_PORT_BR, 
        (pid_t) current_process 
    );

    // This is for display servers, not browsers
    //__initialize_ds_info(current_process);
    //__maximize_ds_priority(current_process);

// Setup c1/
// Change the foreground console.
    //console_set_current_virtual_console(CONSOLE1);

// #test
    t = p->flower;
    if ((void*) t == NULL)
        goto fail;
    if (t->magic != 1234)
        goto fail;

// #test
    t->pe_mode = PE_MODE_PERFORMANCE;

    return TRUE;

fail:
    return (int) -1;
}


// Get the MAC address for a given Intel NIC. (only Intel for now)
// Return pointer to NIC's MAC address
unsigned char *net_get_mac_address(void)
{
    struct intel_nic_info_d *target_intel_nic;

    target_intel_nic = currentNIC;

    return (unsigned char *) e1000hw_get_mac_address(target_intel_nic);
}


void 
network_fill_mac(
    unsigned char *to, 
    unsigned char *from )
{
    register long i=0;

// Parameters:
    if ((void*) to == NULL)
        return;
    if ((void*) from == NULL)
        return;

// Copy
    for (i=0; i<6; i++)
    {
        to[i] = from[i];
    };
}

void 
network_fill_ipv4(
    unsigned char *to,
    unsigned char *from )
{
    register long i=0;

// Parameters
    if ((void*) to == NULL)
        return;
    if ((void*) from == NULL)
        return;

// Copy
    for (i=0; i < 4; i++)
    {
        to[i] = from[i];
    };
}

void 
network_fill_ipv6(
    unsigned char *to,
    unsigned char *from )
{
    register long i=0;

// Parameters
    if ((void*) to == NULL)
        return;
    if ((void*) from == NULL)
        return;

// Copy
    for (i=0; i < 6; i++)
    {
        to[i] = from[i];
    };
}

// Credits: Sirius OS.
unsigned short 
net_checksum(
    const unsigned char *phdr, 
    int phdr_len, 
    const unsigned char *start, 
    const unsigned char *end)
{
    unsigned int checksum = 0;
    unsigned int len = phdr_len;
    unsigned short *p = (unsigned short *) phdr;

// Parameter
    if (!phdr) 
        goto no;

// acc
// Pseudo Head
    while (len > 1) {
        checksum += *p++;
        len -= 2;
    };

no:
    len = end - start;
    p = (unsigned short *) start;
    while (len > 1) {
        checksum += *p++;
        len -= 2;
    };

    if (len != 0) {
        checksum += *(unsigned char *) p;
    }

    checksum = (checksum & 0xffff) + (checksum >> 16);
    checksum += (checksum >> 16);

    unsigned short final = ~checksum;

// #todo:
// Type
    return ToNetByteOrder16(final);
}

// Test, called by the kernel console.
void network_test_NIC(void)
{
    // #debug
    //printk("testNIC:\n");

    //network_send_arp_request();
    //network_test_udp();
    // ...

    // Show NIC hw info
    e1000hw_show_info();

    // #debug
    //printk("testNIC: done\n");
}

// Sends raw Ethernet frames (currently via Intel NIC / ethernet_send).
void 
network_send_raw_packet (
    size_t frame_len, 
    const char *frame_address ) 
{

// frame_len
    if (frame_len<0)
        return;
    if (frame_len > NETWORK_DEFAULT_BUFFER_SIZE)
        return;
// frame_address
    if ((void*) frame_address == NULL)
        return;
//
// Send
//

// #bugbug
// For now we only support the structure for intel devices.
    //e1000_send( nic_intel, frame_len, frame_address );
    // #test
    // Creating a sender for ethernet packet.
    ethernet_send( frame_len, frame_address );
}

// Entry point when NIC delivers a frame. 
// + Handle ethernet header.
// + Call the handler for the given protocol.
// IN:
// + frame base address
// + frame total size
// Called by __e1000_on_receive() in e1000.c.
int 
network_on_receiving ( 
    const unsigned char *frame, 
    ssize_t frame_size )
{
    int UseFirewall = FALSE;
    int FirewallStatus = FALSE;

    // If the kernel is not initialized yet.
    // No NIC device can call us yet.
    if (system_state != SYSTEM_RUNNING)
        return (int) -1;

    if ((void*) frame == NULL)
        return (int) -1;

    //if (frame_size<0)
        //return (int) -1;

    if (UseFirewall == TRUE)
    {
        FirewallStatus = firewall_apply_ethernet_filters(frame, frame_size);
        if (FirewallStatus < 0)
        {
            // Do something ... drop, log etc ...
        }
    }

    return (int) network_handle_ethernet(frame, frame_size);

//-----------------

/*
    struct ethernet_d *eth = (struct ethernet_d *) frame;
    uint16_t Type=0;

// Drop it!
// Set this flag using the command "net-on" on terminal.bin.
    if (NetworkInitialization.initialized != TRUE)
    {
        //#debug
        //printk("Packet: Network is OFF\n");
        goto fail;
    }

// If the network is locked
    if (NetworkInitialization.locked == TRUE)
        goto fail;

// Parameters:
// Frame validation
    if ((void*) frame == NULL){
        //printk("network_on_receiving: frame\n");
        goto fail;
    }
    // 1~8192
    if ( frame_size <= 0 || frame_size > E1000_DEFAULT_BUFFER_SIZE ){
        //printk("network_on_receiving: frame_size\n");
        goto fail;
    }

//
// Option
//

// Push packet.
// Maybe we can simply pash the packet into the circular queue.
// Mayme we can change this queue and use a lined list.
// Or create a queue support. We still don't have this.
// Coloca em um dos buffers, 
// de onde os aplicativos podem pegar depois.
// see: network.c

    // #todo
    // We need a configuration flag here.
    // Telling that we need to push the packets into the queue
    // instead of processing them.

    //network_buffer_in ( (void *) buffer, (int) size );
    //return;
    
    // #debug
    //printk("\n");
    //printk("Ethernet Header\n");

// Ethernet header
    if ((void*) eth == NULL){
        goto fail;
    }

// #debug
// Destination MAC
// Source MAC
// Protocol type.

// #todo
// Let's save it for future use.
// We're gonna need to send responses.

    //printk ("   |-Destination Address : %x-%x-%x-%x-%x-%x \n", 
        //eth->dst[0], eth->dst[1], eth->dst[2], 
        //eth->dst[3], eth->dst[4], eth->dst[5] );

    //printk ("   |-Source Address      : %x-%x-%x-%x-%x-%x \n", 
        //eth->src[0], eth->src[1], eth->src[2], 
        //eth->src[3], eth->src[4], eth->src[5] );

    //printk ("   |-Ethertype           : %x \n",
        //(unsigned short) eth->type);

// Save the MAC of the caller.
    network_fill_mac(
        NetworkSaved.caller_mac, 
        eth->mac_src );
// #todo
// Here we can check if the destination is us,
// if the packet is not for us, we simply drop it.

// Get ethernet type
// Handle the rthernet type
// See: ipv6.c, ipv4.c, arp.c.

    Type = (uint16_t) FromNetByteOrder16(eth->type);
    switch (Type){

    // #todo
    case ETHERTYPE_IPV6:
        // Drop it
        goto fail;
        // #todo
        //network_handle_ipv6( 
            //(frame + ETHERNET_HEADER_LENGHT), 
            //(frame_size - ETHERNET_HEADER_LENGHT) );
        break;

    case ETHERTYPE_IPV4:
        network_handle_ipv4( 
            (frame + ETHERNET_HEADER_LENGHT), 
            (frame_size - ETHERNET_HEADER_LENGHT) );
        break;

    case ETHERTYPE_ARP:
        network_handle_arp( 
            (frame + ETHERNET_HEADER_LENGHT), 
            (frame_size - ETHERNET_HEADER_LENGHT) );
        break;

    // ...

    // Unsupported type.
    default:
        // Drop it
        goto fail;
        break;
    };
*/


// done:
    //return 0;
//fail:
    //return (int) -1;
}

// Called when sending routines push data out.
// Called when sending some raw packet.
// #ps: We do NOT send, we're called by the sending routines.
int network_on_sending (void)
{
// Called by ethernet_send() in core/ethernet.c.

    on_sending_counter++;

    // ...

    return 0;
}

// network_push_packet:
// Saves incoming payloads into the circular buffer (nb_rx_11888).
// in: (Do buffer indicado para o buffer tail)
// Isso é usado pelo driver de dispositivo
// pra salvar o conteúdo que veio da rede em
// um buffer que pode ser lido pelos aplicativos.
// Purpose: 
//  + Save incoming payloads into a shared circular buffer (nb_rx_11888).
// Operation:
//  + Copy payload from protocol handler into nb_rx_11888.payload_ptr[tail].
//  + Mark slot as full.
//  + Advance receive_tail (wrap around at 32).
//

int 
network_push_packet( 
    void *src_buffer, 
    int len )
{
// Push packet.
// #bugbug: 
// What kind of data we're pushing into these buffers?
// Is it the raw frame only? Or only UDP?

    void *dst_buffer;
    int tail=0;

    printk ("    >>>>    PUSH\n");

// Check args
    if ((void*) src_buffer == NULL){
        panic("network_push_packet: src_buffer\n");
    }

// #todo
// Veja na configuração do dispositivo, que o buffer 
// configurado para o hardware é de 0x3000 bytes.
    if (len > 1500){
        debug_print("network_push_packet: [FIXME] len\n");
        len = 1500;
        //return -1;
    }

    if (nb_rx_11888.initialized != TRUE){
        panic ("network_push_packet: buffers not initialized\n");
    }

    tail = (int) nb_rx_11888.receive_tail;

    // Round
    nb_rx_11888.receive_tail++;
    if (nb_rx_11888.receive_tail >= 32){
        nb_rx_11888.receive_tail=0;
    }

// #todo
// MTU: maximim transmition unit.
// For ethernet is 1500 bytes.
    //printk ("network_buffer_in: buffer_len %d\n",len);
    //refresh_screen();

// Fail
// Limits.
    if (tail < 0 || tail >= 32)
    {
        //#debug
        panic ("network_push_packet: tail\n");
        return -1;
    }

// Check buffer status.
// Se o buffer está cheio é porque ele não foi consumido.
// Vamos sobrepor?
    int buffer_status = nb_rx_11888.is_full[tail];
    if (buffer_status == TRUE)
    {
        // #bugbug
        // #todo: Podemos criar um contador de vezes que isso acontece.
        // Isso acontece frequentemente.
        // panic ("network_buffer_in: [TEST] Not responding ...\n");
        // printk ("network_buffer_in: [FIXME] Can't write. This buffer is full.\n");
        // refresh_screen();
    }

// Get the destination buffer
    dst_buffer = (void*) nb_rx_11888.payload_ptr[tail];
// Copy
    if ((void*)dst_buffer != NULL)
    {
        memcpy( 
            dst_buffer,   // Data goes to the list.
            src_buffer,   // Data comes from the device. 
            len );        // Lenght.
    } 

// Avisamos que esse buffer está cheio.
    nb_rx_11888.is_full[tail] = TRUE;

    //printk("network_buffer_in: ok\n");
    //refresh_screen();
    //return 0;  //ok
    return (int) len;

fail:
    return (int) -1;
}

// network_pop_packet:
// Lets applications retrieve packets from the buffer.
// out: (Do buffer head para o buffer indicado)
// Isso é usado pelos aplicativos
// para pegarem os conteúdos salvos nos buffers.
// Daí os aplicativos interpretam os protocolos.
// Purpose: 
// + Let applications or servers retrieve packets from the queue.
// Operation:
// + Read from nb_rx_11888.receive_head.
// + Copy data into user buffer.
// + Mark slot as empty.
// + Advance receive_head (wrap around at 32).
//

int 
network_pop_packet ( 
    void *u_buffer,   // User buffer to get the data. 
    int len )         // Size.
{
// Pop packet.
// Circular queue. :)
// This is a service called only by the
// network server to get input from the
// queue filled by the NIC devices.
// It doesn't open any device to get data.

    printk ("    >>>>    POP\n");

    int head=0;
    void *src_buffer;

    //debug_print("network_pop_packet:\n");

// check args
    if ((void*) u_buffer == NULL){
        panic ("network_pop_packet: [FAIL] u_buffer\n");
    }

// #bugbug:
// Isso pode ser maior se considerarmos todos os headers.
// #todo
// Veja na configuração do dispositivo, que o buffer 
// configurado para o hardware é de 0x3000 bytes.
    if (len>1500){
        debug_print("network_pop_packet: [FIXME] len\n");
        len=1500;
        //return -1;
    }

    if (nb_rx_11888.initialized != TRUE){
        panic ("network_pop_packet: Shared buffers not initialized\n");
    }

// Vamos pegar um numero de buffer para enviarmos o pacote.
// o kernel vai retirar do head ... 
// o que foi colocado pelo aplicativo em tail.
    head = (int) nb_rx_11888.receive_head;

// circula.
    nb_rx_11888.receive_head++;
    if (nb_rx_11888.receive_head >= 32){
        nb_rx_11888.receive_head=0;
    }

// #todo
// MTU: maximim transmition unit.
// For ethernet is 1500 bytes.
    //printk ("network_buffer_in: buffer_len %d\n",len);
    //refresh_screen();

    if (head<0 || head >= 32)
    {
        //#debug
        panic ("network_push_packet: head\n");
        return -1;
    }

// Is the buffer full?
    if ( nb_rx_11888.is_full[head] != TRUE )
        return 0;

// Get the source buffer.
    src_buffer = (void*) nb_rx_11888.payload_ptr[head];
// Copy
    if ((void*)src_buffer != NULL)
    {
        memcpy( 
            u_buffer,   // User buffer to get the data. 
            src_buffer, // Where the buffer was stored in the list.
            len );      // Lenght.
    
        // Now this buffer is empty.
        nb_rx_11888.is_full[head] = FALSE;
    }

    //printk("network_buffer_in: ok\n");
    //refresh_screen();
    //return 0;  //ok
    return (int) len;
    
fail:
   return (int) -1;
}

// ============================================================
// Service 118: sys_network_push_packet
// ------------------------------------------------------------
// Ring 3 syscall for injecting packets into the kernel buffer (testing).
// Perspective: Ring 3 (user process)
// This syscall allows a user process to *push* data into the
// kernel's network receive buffer. 
// Normally, packets are pushed by the NIC/UDP handler, but this
// syscall is useful for testing and injecting data directly
// into the queue from user space.
// ------------------------------------------------------------
unsigned long sys_network_push_packet(void *u_buffer, int len)
{
    int int_rv = 0;
    if ((void*) u_buffer == NULL)
        return -1;

    // Enqueue user-provided data into the kernel's RX queue
    int_rv = (int) network_push_packet(u_buffer, len);

    return (unsigned long) (int_rv & 0xFFFFFFFF);
}

// ============================================================
// Service 119: sys_network_pop_packet
// ------------------------------------------------------------
// Ring 3 syscall for dequeuing packets.
// Perspective: Ring 3 (user process)
// This syscall allows a user process to *pop* (dequeue) data
// from the kernel's network receive buffer.
// This is the normal consumer path: packets that were enqueued
// by the UDP handler (or by sys_network_push_packet for testing)
// can be fetched by the process here.
// ------------------------------------------------------------
unsigned long sys_network_pop_packet(void *u_buffer, int len)
{
    if ((void*) u_buffer == NULL)
        return -1;

    // Dequeue data from the kernel's RX queue into user buffer
    int int_rv = network_pop_packet(u_buffer, len);

    return (unsigned long) (int_rv & 0xFFFFFFFF);
}


void networkSetStatus (int status)
{
    if ( status < 0 || status > 1 ){
        return;
    }
    NetworkInitialization.initialized = (int) status;
}

int networkGetStatus (void)
{
    return (int) NetworkInitialization.initialized;
}

void networkLock (void)
{
    NetworkInitialization.locked = (int) TRUE;
}
void networkUnlock (void)
{
    NetworkInitialization.locked = (int) FALSE;
}
int networkIsLocked (void)
{
    return (int) NetworkInitialization.locked;
}


void networkSetOnlineStatus(int status)
{
    if (status != TRUE && status != FALSE)
        return;
    NetworkInitialization.is_online = (int) status;
}

int networkGetOnlineStatus(void)
{
    return (int) NetworkInitialization.is_online;
}


void networkUpdateCounter(int the_counter)
{
// Update counter for the current network.
// 1=TX | 2=RX.

    if ((void*) NetworkInfo == NULL)
        return;
    if (NetworkInfo->magic != 1234)
        return;

    if (the_counter == 1){
        NetworkInfo->tx_counter++;
        return;
    }
    if (the_counter == 2){
        NetworkInfo->rx_counter++;
        return;
    }
}

//
// $
// INITIALIZATION
//

// netInitialize:
// Called by lateinit() in ke.c.
// Remember, we already initialized the driver for e1000 nic device.
int netInitialize(void)
{
// + Setup network status.
// + Setup network info structure.
// + Create queue with 32 buffers to receive data from the driver.
// + Setup host info structure.
// + Setup localhost socket structure.
// + Initialize a list of sockets.
// + Create domain structure
// + Initialize the ARP cache.

    register int i=0;
    void *tmp_buffer_address;

    PROGRESS ("netInitialize:\n");

//======================================
// Network initialization structure.


// Not initialized yet.
// The network is disabled
    networkSetStatus(NETWORK_NOT_INITIALIZED);
// We're offline
    networkSetOnlineStatus(NETWORK_OFFLINE);

//======================================
// Network info structure

    struct network_info_d *ni;
    ni = (void*) kmalloc( sizeof(struct network_info_d) );
    if ((void*) ni == NULL){
        printk("on ni\n");
        goto fail;
    }
    // Clear the structure
    memset( ni, 0, sizeof(struct network_info_d) );
    ni->initialized = FALSE;
    // This is the first network interface,
    // it is created when the kernel is booting.
    ni->id = 0;

    // #deprecated
    //ni->version_major = 0x0000;
    //ni->version_minor = 0x0000;
    //ni->version_revision = 0x0000;
    
    // ...

    ni->name_string = (void*) default_network_name_string;
    ni->name_string_size = (size_t) strlen(default_network_name_string);

    ni->version_string = (void*) default_network_version_string;
    ni->version_string_size = (size_t) strlen(default_network_version_string);

// Gateway info.
// Clear the info. (again)
    for (i=0; i<6; i++){
        ni->gateway_mac[i] = 0;
        //ni->gateway_ipv6[i] = 0;
    };
    for (i=0; i<4; i++){
        ni->gateway_ipv4[i] = 0;
    };
    ni->gateway_initialized = FALSE;

// Counters.
    ni->tx_counter=0;
    ni->rx_counter=0;

    //ni->cgroup = NULL;

    ni->next = NULL;
    ni->used = TRUE;
    ni->magic = 1234;
    
    // This structure is initialized.
    ni->initialized = TRUE;
    NetworkInfo = (struct network_info_d *) ni;

//======================================


// ======================================
// Network buffer 11888 (system port)
// 32 buffers:

// buffers:
// #todo:
// We will create 32 buffers to receive data and
// 8 buffers to send data.

// #fixme
// Provavelmente esse alocador ainda nao funciona.

    nb_rx_11888.used = TRUE;
    nb_rx_11888.magic = 1234;
    nb_rx_11888.initialized = FALSE;

    nb_rx_11888.port = (uint16_t) 11888;  // UDP System port
    //nb_rx_11888.protocol = #todo UDP
    // nb_rx_11888.socket = NULL;

// =====================================
// receive buffers
    for (i=0; i<32; i++)
    {
        tmp_buffer_address = (void*) mmAllocPage();
        if ((void *)tmp_buffer_address == NULL){
            printk("on tmp_buffer_address\n");
            goto fail;
        }

        // Clear the page to avoid stale data
        // memset(tmp_buffer_address, 0, PAGE_SIZE);

        nb_rx_11888.payload_ptr[i] = (unsigned long) tmp_buffer_address;
        nb_rx_11888.is_full[i] = FALSE;  //EMPTY
    };
    nb_rx_11888.receive_tail=0;
    nb_rx_11888.receive_head=0;
// ========================================

// flag
    nb_rx_11888.initialized = TRUE;

// =====================================
// Host info struct. 
// See: host.h
    //debug_print ("networkInit: HostInfo\n");

    HostInfo = (struct host_info_d *) kmalloc(sizeof(struct host_info_d));
    if ((void *) HostInfo == NULL){
        printk("on HostInfo\n");
        goto fail;
    }

// #todo
// We need to grab the hostname from another place.
// Maybe from a configuration file.
// UTS_NODENAME ?

    //HostInfo->__hostname[0] = 'h';
    //HostInfo->hostName_len = (size_t) HOST_NAME_MAX;

    ksprintf(HostInfo->__hostname, "gramado");
    HostInfo->hostName_len = (size_t) strlen("gramado");
    if (HostInfo->hostName_len >= HOST_NAME_MAX)
    {
        printk("on hostname\n");
        goto fail;
    }

// Version
    HostInfo->hostVersion = NULL;

// #todo
// Call some helpers to get these values.
// Maybe the init process needs to setup these values.
// It's because these values are found in files.
    HostInfo->hostVersionMajor    = 0;
    HostInfo->hostVersionMinor    = 0;
    HostInfo->hostVersionRevision = 0;

// #todo
// Where is this information?
    HostInfo->hostArchitecture = 0;

    HostInfo->used = TRUE;
    HostInfo->magic = 1234;
    NetworkInfo->host_info = (void*) HostInfo;

// =====================================
// Localhost socket structure.

// Socket
// Criando socket para local host porta 80;
// Localhost (127.0.0.1):80 
// Configurando soquete atual.

    //debug_print ("networkInit: LocalHostHTTPSocket\n");

    LocalHostHTTPSocket = (struct socket_d *) create_socket_object();
    if ((void *) LocalHostHTTPSocket == NULL){
        printk("on LocalHostHTTPSocket\n");
        goto fail;
    }
    CurrentSocket = (struct socket_d *) LocalHostHTTPSocket;


// Initializes the socket list
    socket_init();

// Status
// #todo:
// Some ring3 process will set the status.
// Untill this, the network module will drop
// all the packets and will not send any packet.
// see: 
// network_on_receiving() and network_on_sending();

    networkSetStatus(TRUE);

// Lock:
// Locking. The ring3 application will unlock it
    NetworkInitialization.locked = TRUE;

// =====================================
// domain

//
// Create the domain structure.
//

// It describes the domain this node belongs to.

    struct domain_d  *my_domain;
    my_domain = (void *) domain_create_domain(UTS_DOMAINNAME);
    if ((void*) my_domain == NULL){
        printk("on my_domain\n");
        goto fail;
    }

// ARP cache:
// Initialize the ARP table
    arp_initialize_arp_table();

// =====================================
// #test: (Network Interface)
// Initializing the network interface structure. (first time ever)
// #ps: 
// We also have to call netif_update() to update the structure
// for the current network interface. Probably when initializing 
// the DHCP support.

    netif_initialize();


    firewall_initialize();

    // ...

    return 0;

fail:
    // #debug
    // For now we can't fail on the network initialization.
    panic("netInitialize: Fail\n");
    return (int) -1;
}

