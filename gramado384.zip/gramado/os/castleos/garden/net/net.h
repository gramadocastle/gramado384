// net.h
// Created by Fred Nora.

#ifndef __NET_NET_H
#define __NET_NET_H    1

// For side_id
#define CONN_SIDE_SERVER  0
#define CONN_SIDE_CLIENT  1

// Sides
// CONN_LCLS → LC | LS
// CONN_LCRS → LC | RS
// CONN_LSLC → LS | LC
// CONN_LSRC → LS | RC

// For case_id
#define CONN_LCLS   1   // Local Client -> Local Server
#define CONN_LCRS   2   // Local Client -> Remote Server
#define CONN_LSLC   3   // Local Server -> Local Client
#define CONN_LSRC   4   // Local Server -> Remote Client


// Represents a single socket endpoint (local or remote).
struct endpoint_d
{
    int used;
    int magic;

    struct socket_d *socket;
    int is_remote;   // ENDPOINT_LOCAL or ENDPOINT_REMOTE

    struct sockaddr_in  addr;
};

// Couples client/server endpoints into a case (LC→LS, LC→RS, etc.).
struct endpoint_pair_d 
{
    int used;
    int magic;

// An endpoint pair belongs to a case.
//  One of the 4 corners of a square.
//#define CONN_LCLS   1   // Local Client -> Local Server
//#define CONN_LCRS   2   // Local Client -> Remote Server
//#define CONN_LSLC   3   // Local Server -> Local Client
//#define CONN_LSRC   4   // Local Server -> Remote Client
    int case_id;

    struct endpoint_d *s_ep;  // server endpoint
    struct endpoint_d *c_ep;  // client endpoint
};


/*
What belongs in tcp_connection_d
This structure represents the local TCP state machine 
for a single connection. It contains everything your kernel needs to:
track sequence numbers
manage windows
handle retransmissions
maintain timers
process ACKs
implement congestion control (later)
*/

/*

How the Fields Map to TCP Behavior
snd_una → Oldest unacknowledged sequence number.
Used to know what data is still “in flight” and awaiting ACK.

snd_nxt → Next sequence number to send.
Incremented every time you transmit payload (or SYN/FIN, since they consume sequence space).

iss → Initial send sequence number.
Set during handshake when you send the first SYN.

rcv_nxt → Next expected sequence number from the peer.
Updated when you receive data or SYN/FIN.

irs → Initial receive sequence number.
Set when you accept the peer’s SYN.

snd_wnd / rcv_wnd → Flow control windows.
For now you can keep them fixed, but later they’ll be dynamic.
*/

/*
Example: Handshake Progression
Let’s say you’re the server on port 11888:

Client sends SYN
You set irs = client_seq
You set rcv_nxt = client_seq + 1 (expecting next byte)

Server replies SYN/ACK
You set iss = my_initial_seq
You set snd_nxt = iss + 1 (since SYN consumes one seq)
You set snd_una = iss (oldest unacknowledged is the SYN)

Client sends ACK
You update snd_una = iss + 1 (our SYN acknowledged)
You set rcv_nxt = client_seq + 1 (their ACK confirms receipt)

At this point, state = TCP_ESTABLISHED.
*/

// TCP connection states (RFC 793)
#define TCP_CLOSED        0
#define TCP_LISTEN        1
#define TCP_SYN_SENT      2
#define TCP_SYN_RECEIVED  3
#define TCP_ESTABLISHED   4
#define TCP_FIN_WAIT_1    5
#define TCP_FIN_WAIT_2    6
#define TCP_CLOSE_WAIT    7
#define TCP_CLOSING       8
#define TCP_LAST_ACK      9
#define TCP_TIME_WAIT     10

// The TCP states per STD 7 - RFC 793
/*
typedef enum __tcp_state {
	TCP_STATE_CLOSED,
	TCP_STATE_LISTEN,
	TCP_STATE_SYN_SENT,
	TCP_STATE_SYN_RECV,
	TCP_STATE_ESTAB,
	TCP_STATE_FIN_WAIT_1,
	TCP_STATE_FIN_WAIT_2,
	TCP_STATE_CLOSE_WAIT,
	TCP_STATE_CLOSING,
	TCP_STATE_LAST_ACK,
	TCP_STATE_TIME_WAIT,
}tcp_state_t;
*/



// Holds TCP state machine info 
// (sequence numbers, windows, timers, congestion control).
struct tcp_connection_d 
{
    int used;
    int magic;

// TCP_LISTEN, TCP_SYN_SENT, TCP_ESTABLISHED, etc.
    int state;

// Sequence Numbers

// -- Send --------
    // Oldest unacknowledged sequence number.
    // Tracks the first byte of data that has been sent but not yet acknowledged.
    // Everything before snd_una is confirmed as received by the peer.
    uint32_t snd_una;
    // Next sequence number to send.
    // Points to the next byte of data that will be transmitted.
    // Moves forward as you send payloads or 
    // control flags (SYN/FIN also consume sequence numbers).
    uint32_t snd_nxt;
    // send window
    // limits how much you can send before waiting for ACKs.
    uint32_t snd_wnd;
    // Initial send sequence number.
    // Chosen during the handshake when you send the first SYN.
    // Ensures uniqueness and protects against old duplicate segments.
    uint32_t iss;

// -- Receive --------
    // Next expected sequence number from the peer.
    // If you receive data with exactly this sequence number, 
    // you accept it and increment rcv_nxt.
    // If data arrives out of order, 
    // you buffer until the missing piece arrives.
    uint32_t rcv_nxt;
    // receive window
    // tells the peer how much buffer space you have available.
    uint32_t rcv_wnd; 
    // Initial receive sequence number.
    // Set when you accept the peer’s SYN
    // Defines the starting point of the peer’s sequence space.
    uint32_t irs;

//
// Buffers
//

// -- Send --------
    void *send_buffer;
    size_t send_buffer_len;
// -- Receive --------
    void *recv_buffer;
    size_t recv_buffer_len;

// Timers
    uint32_t rto;       // retransmission timeout
    uint32_t srtt;      // smoothed RTT
    uint32_t rttvar;    // RTT variance
    uint32_t last_ack;  // timestamp of last ACK
    uint32_t last_sent; // timestamp of last sent segment

// Flags and Options
// TCP options negotiated during handshake:
    int sack_enabled;
    int window_scaling;
    int timestamp_enabled;
    uint16_t mss;       // maximum segment size

// Congestion Control
    uint32_t cwnd;      // congestion window
    uint32_t ssthresh;  // slow start threshold

// Retransmission Tracking
    int retransmit_count;
    uint32_t last_retransmit;
};

// ...

// connection_d
// Represents a communication link.
// Local connections: only local_conn is used.
// Remote connections: server_endpoint + remote_endpoint describe
// the local socket and the remote endpoint.

// Connection types
#define CONN_TYPE_NONE    0
#define CONN_TYPE_TCP     1
#define CONN_TYPE_UDP     2
#define CONN_TYPE_LOCAL   3
#define CONN_TYPE_IPC     4   // optional, for inter-process comm

// Connection status (TCP states)
// Aliases for TCP states
#define CONN_STATUS_NONE          TCP_CLOSED
#define CONN_STATUS_CLOSED        TCP_CLOSED
#define CONN_STATUS_LISTEN        TCP_LISTEN 
#define CONN_STATUS_SYN_SENT      TCP_SYN_SENT
#define CONN_STATUS_SYN_RECEIVED  TCP_SYN_RECEIVED
#define CONN_STATUS_ESTABLISHED   TCP_ESTABLISHED
#define CONN_STATUS_FIN_WAIT1     TCP_FIN_WAIT_1
#define CONN_STATUS_FIN_WAIT2     TCP_FIN_WAIT_2
#define CONN_STATUS_CLOSE_WAIT    TCP_CLOSE_WAIT
#define CONN_STATUS_CLOSING       TCP_CLOSING
#define CONN_STATUS_LAST_ACK      TCP_LAST_ACK
#define CONN_STATUS_TIME_WAIT     TCP_TIME_WAIT


// Abstracts a communication link (TCP, UDP, LOCAL, IPC).
struct connection_d 
{
    int used;
    int magic;

    int id;       // unique connection identifier
    int type;     // LOCAL, TCP, UDP, etc.
    //int protocol;
    int status;   // NEW: generic connection status

// ep pair
    struct endpoint_pair_d *ep_pair;

// tcp connection
    struct tcp_connection_d *tcp_conn;

// udp connection
    // future: struct udp_connection_d *udp_conn;

// #test
    //struct network_buffer_d  *n_buf;

// 1 = we are the server, 
// 0 = we are the client
    int is_local_server;

    unsigned int packets_sent;
    unsigned int packets_received;

    uint8_t peer_mac[6];   // MAC of the remote peer
};


#define MAX_CONNECTIONS  256
// See: net.c
extern unsigned long connectionList[MAX_CONNECTIONS];

// ================================================

// Used for fast responses
struct network_saved_d
{
// Gateway info
    unsigned char gateway_ipv4[4];
    unsigned char gateway_mac[6];
// Our info.
// We have another structure for our information.
    //unsigned char our_ipv4[4];
    //unsigned char our_mac[6];
// Caller's info.
    unsigned char caller_ipv4[4];
    unsigned char caller_mac[6];

    // when the packet arrives
    unsigned int caller_ip_int;
    unsigned int target_ip_int;
};
extern struct network_saved_d  NetworkSaved;


// 8192
#define NETWORK_DEFAULT_BUFFER_SIZE  \
    E1000_DEFAULT_BUFFER_SIZE


// >> The register at offset 0x00 is the "IOADDR" window. 
// >> The register at offset 0x04 is the "IODATA" window. 

// packet format
// Ethernet IPv4 TCP/UDP DATA FCS

// =================================================

//#define DEFAULT_NUMBER_OF_NETWORK_BUFFERS  32

// Buffers for packet queues (per port/protocol).
struct network_buffer_d
{
    int used;
    int magic;
    int initialized;

// Port number this queue is bound to 
    uint16_t port;

// Protocol type (UDP, TCP, etc.) 
    int protocol;

// Associated socket object 
    struct socket_d *socket;

// Receive
    int receive_tail;
    int receive_head;

// Pointers
// It is an array of pointers to payload memory blocks, 
// each entry is a base address of a payload buffer.
    unsigned long payload_ptr[32];

// O status de cada buffer, se ele está vazio ou não.
    int is_full[32];
};
// See: net.c
// Network buffer 11888 (system port)
extern struct network_buffer_d  nb_rx_11888;

//========================================================

// Initialized?
#define NETWORK_INITIALIZED  TRUE
#define NETWORK_NOT_INITIALIZED  FALSE

// Online?
#define NETWORK_ONLINE   TRUE
#define NETWORK_OFFLINE  FALSE
#define ONLINE   NETWORK_ONLINE
#define OFFLINE  NETWORK_OFFLINE

struct network_initialization_d
{

// Status do driver de network
// 0 - uninitialized
// 1 - initialized
    int initialized;

// Are we online?
// Do we already have an valid IP?
// We are online when we already have a valid IP.
    int is_online;

    int locked;

// ...

};
extern struct network_initialization_d  NetworkInitialization;

// =================================================

// Metadata about the network interface (gateway, NICs, stats, etc.).
// Describe our network
// #todo
// There is a lot of fields here,
// let's include pointers to another structures.
struct network_info_d
{
    int used;
    int magic;
    int initialized;  // This structure was initialied

    int id;  // Network ID

// Strings

// Network name
    char *name_string;
    size_t name_string_size;
// String mostrando a versão. ex: (1.1.1234)
    char *version_string;
    size_t version_string_size;

// Values
// #bugbug
// We don't need this.
    //unsigned short version_major;
    //unsigned short version_minor;
    //unsigned short version_revision;

// Network status
    //int status;
    //int is_online;

//adaptador de rede.
    //struct intel_nic_info_d *nic_info;

    // struct user_info_d *user_info;
    struct host_info_d *host_info;
    //..

// Gateway support
    uint8_t gateway_mac[6];
    uint8_t gateway_ipv4[4];
    //uint8_t gateway_ipv6[6];
    int gateway_initialized;


// Number of nic devices in the machine.
    int nic_counter;
// The interface is using this nic device.
    //int nic_in_use;

// ...

// Stats
// For all the NICs?
    unsigned long tx_counter;
    unsigned long rx_counter;

// The domain controller.
    //struct domain_d *domain_controller;

// This network interface belongs to this cgroup.
// If a process belongs to another cgroup i will be unable to 
// accress this interface.
// This way we can create multiple network interface and 
// each container/vm can use his own network interface.
    //struct cgroup_d  *cgroup;

    struct network_info_d  *next;
};
extern struct network_info_d *NetworkInfo;

// =================================================

struct endpoint_d *create_endpoint_object(void);
struct endpoint_pair_d *create_endpoint_pair_object(void);
struct connection_d *create_connection(int type);
int connection_register(struct connection_d *conn);
struct connection_d *get_connection(int id);
void network_show_connections(void);

struct socket_d *get_client_socket_from_connection(struct connection_d *conn);
struct socket_d *get_server_socket_from_connection(struct connection_d *conn);


//
// == Prototypes ====================
//

// Network interface for keyboard input.
int 
network_keyboard_event( 
    int event_id,
    long long1, 
    long long2 );

// Network interface for mouse input.
int 
network_mouse_event( 
    int event_id, 
    long data1, 
    long data2 );


//
// Register main system components
//

// + Display server
// + Network server
// + OS Shell (explorer/taskbar)
// + Default browser
// ...

// Display server: (Service: sci0 513)
// Register display server into a given valid cgroup.
int 
network_register_ring3_display_server(
    struct cgroup_d *cg,
    pid_t caller_pid );

// Network server:
int 
network_register_ring3_network_server(
    struct cgroup_d *cg,
    pid_t caller_pid );

// OS Shell (explorer/taskbar)
int 
network_register_ring3_osshell(
    struct cgroup_d *cg,
    pid_t caller_pid );
  
// Default browser - (service: sc0 518)
// Register browser into a given valid cgroup.
int 
network_register_ring3_browser(
    struct cgroup_d *cg,
    pid_t caller_pid );


//
// Networking
//

// Get the MAC address for a given Intel NIC. (only Intel for now)
// Return pointer to NIC's MAC address
unsigned char *net_get_mac_address(void);

void 
network_fill_mac(
    unsigned char *to, 
    unsigned char *from );
void 
network_fill_ipv4(
    unsigned char *to,
    unsigned char *from );
void 
network_fill_ipv6(
    unsigned char *to,
    unsigned char *from );

unsigned short 
net_checksum(
    const unsigned char *phdr, 
    int phdr_len, 
    const unsigned char *start, 
    const unsigned char *end);

void network_test_NIC(void);

void 
network_send_raw_packet (
    size_t frame_len, 
    const char *frame_address );

//
// Handling packets
//

// Called when a packet came in from a device driver.
int 
network_on_receiving ( 
    const unsigned char *frame, 
    ssize_t frame_size );

// Called when sending some raw packet.
// #ps: We do NOT send, we're called by the sending routines.
int network_on_sending (void);

// Push and Pop data.
int network_push_packet( void *src_buffer, int len );
int network_pop_packet( void *u_buffer, int len );

// Service 118
unsigned long sys_network_push_packet(void *u_buffer, int len);
// Service 119
unsigned long sys_network_pop_packet(void *u_buffer, int len);


void networkSetStatus(int status);
int networkGetStatus(void);

void networkLock (void);
void networkUnlock (void);
int networkIsLocked (void);

void networkSetOnlineStatus(int status);
int networkGetOnlineStatus(void);

void networkUpdateCounter(int the_counter);

int netInitialize(void);

#endif    

