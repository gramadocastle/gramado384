// sockint.c
// The implementation of socket related functions.
// Internal routines.
// Low level worker called by socket.c
// Created by Fred Nora.

#include <kernel.h>


// globals
struct socket_d  *CurrentSocket;
struct socket_d  *LocalHostHTTPSocket;
// ...


unsigned long socketList[SOCKET_COUNT_MAX];



// Local IPC servers
// A small list of PIDs.
// A server can register its PID here
// telling the system that it is responsible for this kind of service.
static pid_t gramado_server_pids[GRAMADO_PORT_MAX];

// TCP servers
// static pid_t gramado_tcpserver_pids[SERVER_COUNT_MAX];
unsigned long serverList[SERVER_COUNT_MAX];

// ----------------------------

static int __initialize_gramado_server_pids_table(void);
static int __initialize_gramado_tcpserver_pids_table(void);

// -------------------------------

static int __initialize_gramado_server_pids_table(void)
{
    register int i=0;
    for (i=0; i<GRAMADO_PORT_MAX; i++){
        gramado_server_pids[i] = 0;
    };
    return 0;
}
static int __initialize_gramado_tcpserver_pids_table(void)
{
    register int i=0;
    for (i=0; i<SERVER_COUNT_MAX; i++)
    {
        serverList[i] = (unsigned long) 0;
    };
    return 0;
}

/*
 * create_socket_object: 
 *     It creates a socket structure.
 *     Every process has its own socket structure.
 *     The status is: NOT CONNECTED.
 * #ps: See the structure in socket.h
 */
struct socket_d *create_socket_object(void)
{
    struct socket_d *s;
    register int i=0;

// Create and clean the structure
    s = (void *) kmalloc( sizeof(struct socket_d) );
    if ((void *) s ==  NULL){
        printk("create_socket_object: s\n");
        goto fail;
    }
    memset( s, 0, sizeof(struct socket_d) );

    //s->kobj._type = 0
    //s->kobj._class = 0

    s->id = 0;  //#todo

    // Get PID for the current process for a given core.
    // IN: core id

    s->pid = (pid_t) get_current_process(0);
    s->tid = (tid_t) lapic_info[0].current_tid;
    s->uid = (uid_t) current_user;
    s->gid = (gid_t) current_group;

// #todo
    //s->addr = 0;

    s->family = 0;
    s->type = 0;   // (SOCK_STREAM, SOCK_DGRAM, SOCK_RAW ...)
    s->protocol = 0;

    s->conn = NULL;  // Belongs to this connection
    s->ep = NULL;    // Belongs to this ep

// IP:Port
    s->ip_ipv6 = (unsigned long) 0;
    s->ip_ipv4 = (unsigned int) 0;
    s->port = (unsigned short) 0;

// The buffer.
// The data goes into the stream.
    s->private_file = NULL;

// Socket flags
// The flags that describe the state of this socket.
    s->flags = 0;

// The flags used in TCP connections,
// Data Offset (4bits) | Reserved (6bits) | Control bits (6bits).
    s->tcp__do_res_flags = 0;

// Initializing pointers.
// We don't want this kinda crash in the real machine.

// It's a pointer to another socket. 
    s->link = NULL;

// Backlog (Max is 32)
    for (i=0; i<32; i++)
    {
        s->pending_server_endpoints[i] = 0;
        s->pending_client_endpoints[i] = 0;
    };
// The counter
    s->pending_server_count = 0;
    s->pending_client_count = 0;

    s->backlog_head = 0;   //sai
    s->backlog_max = 4;    //default 

// Not yet.
// listen() will set this flag.
    s->isAcceptingConnections = FALSE;

// The socket needs to be initialized 
// in the disconnected state.
    s->state = SS_UNCONNECTED;

    s->free = FALSE;  // In use at this moment
    s->debug = FALSE;  // We can set this via ioctl

// #bugbug
// It tells us that write() will copy 
// the data to the connected socket.
    s->conn_copy = TRUE;  //YES, copy!
// The server finds a place in the server_process->Objects[i].
    s->clientfd_on_server = -1;

    // ...

    s->used = TRUE;
    s->magic = 1234;
    return (struct socket_d *) s;

fail:
    return NULL;
}

/*
 * socket_get_gramado_server_pid:
 *     Retrieve the PID of a local IPC server (AF_GRAMADO) from the table.
 *     IN: index (0..GRAMADO_PORT_MAX-1)
 *     OUT: PID of the server registered at that index, or -1 on error.
 */
pid_t socket_get_gramado_server_pid (int port)
{
    if (port<0 || port >31){
        debug_print ("socket_get_gramado_server_pid: port fail\n");
        return (pid_t) -1;
    }
    return (pid_t) gramado_server_pids[port];
}

/*
 * socket_set_gramado_server_pid:
 *     Register a local IPC server (AF_GRAMADO) in the PID table.
 *     IN: index (0..GRAMADO_PORT_MAX-1), PID of the server process.
 *     OUT: 0 on success, -1 on error.
 *     NOTE: This allows the kernel to know which process is responsible
 *           for handling requests on a given Gramado service slot.
 *     NOTE: Normally used for AF_GRAMADO in local c/s communication.
 */
int socket_set_gramado_server_pid (int port, pid_t pid)
{
    if (port<0 || port >31){
        debug_print ("socket_set_gramado_server_pid: port fail\n");
        return -1;
    }
    if (pid<0 || pid >= PROCESS_COUNT_MAX){
        debug_print ("socket_set_gramado_server_pid: port fail\n");
        return -1;
    }
    gramado_server_pids[port] = (pid_t) pid;
    return 0;
}

/*
 * socket_get_tcpserver_pid:
 *     Retrieve the PID of a TCP server (AF_INET) from the table.
 *     IN: index (0..SERVER_COUNT_MAX-1)
 *     OUT: PID of the server registered at that index, or -1 on error.
 *     NOTE: Used when a SYN arrives for a given port, so the kernel
 *           can locate the listening process.
 */
pid_t socket_get_tcpserver_pid(int port) 
{
    struct server_d *s;

    if (port < 0 || port >= SERVER_COUNT_MAX) {
        debug_print("socket_get_tcpserver_pid: port fail\n");
        return (pid_t) -1;
    }

    s = (struct server_d *) serverList[port];
    if ((void*) s == NULL)
        return -1;
    if (s->magic != 1234)
        return -1;

    // return PID
    return (pid_t) s->pid;
}

/*
 * socket_set_tcpserver_pid:
 *     Register a TCP server (AF_INET) in the PID table.
 *     IN: index (0..SERVER_COUNT_MAX-1), PID of the server process.
 *     OUT: 0 on success, -1 on error.
 *     NOTE: Called during bind()+listen() so the kernel knows which
 *           process owns a given TCP listening port.
 */
int socket_set_tcpserver_pid(int port, pid_t pid) 
{
    struct server_d *s;

    if (port < 0 || port >= SERVER_COUNT_MAX) {
        debug_print("socket_set_tcpserver_pid: port fail\n");
        return -1;
    }
    if (pid < 0 || pid >= PROCESS_COUNT_MAX) {
        debug_print("socket_set_tcpserver_pid: pid fail\n");
        return -1;
    }

    s = (struct server_d *) serverList[port];
    if ((void*) s == NULL)
        return -1;
    if (s->magic != 1234)
        return -1;
    s->pid = (pid_t) pid;

    return 0;  // done
}


/*
 * socket_find_empty_tcpserver_slot:
 *     Search the gramado_tcpserver_pids[] table for a free slot.
 *     A free slot is one where the PID value is 0 (unused).
 *     OUT: index of the free slot (0..SERVER_COUNT_MAX-1),
 *          or -1 if no slot is available.
 *     NOTE: Called when a new AF_INET server is created, before
 *           registering its PID with socket_set_tcpserver_pid().
 */
int socket_find_empty_tcpserver_slot(void)
{
    struct server_d *s;
    int i;

    for (i=0; i < SERVER_COUNT_MAX; i++)
    {
        s = (struct server_d *) serverList[i]; // Get one pointer
        if ((void*) s == NULL)
        {
            return (int) i;  // done
        }
    };

    return (int) -1;  // no free slot
}


/*
 * is_it_a_local_server:
 *   Check if the given TCP port belongs to a registered local server.
 *
 *   IN:  target_port (unsigned short)
 *   OUT: TRUE (1) if the port is registered in serverList[],
 *        FALSE (0) otherwise.
 *
 *   Usage:
 *     if (is_it_a_local_server(dport)) {
 *         __handle_tcp_for_local_servers(...);
 *     } else {
 *         __handle_tcp_for_non_local_servers(...);
 *     }
 *
 *   Importance:
 *     - This abstracts away the probing logic.
 *     - Keeps network_handle_tcp clean and readable.
 *     - Ensures that any server registered in serverList[] is
 *       automatically recognized, without hard‑coding port numbers.
 */
int is_it_a_local_server(unsigned short target_port)
{
    struct server_d *srv;
    int i;

    for (i = 0; i < SERVER_COUNT_MAX; i++) 
    {
        srv = (struct server_d *) serverList[i];
        if ((void*) srv != NULL) {
            if (srv->magic == 1234) 
            {
                if (srv->port == target_port) 
                {
                    return TRUE;  // Found a registered local server
                }
            }
        }
    };

    return FALSE;  // Not found
}


/*
 * socket_get_tcpserver_socket_by_port:
 *     Retrieve the listening socket_d pointer for a TCP server
 *     bound to a given real port number.
 *     IN: real TCP port number (unsigned short)
 *     OUT: pointer to the socket_d structure if found,
 *          or NULL if no server is registered for that port.
 *     NOTE: Used when handling incoming connections or data,
 *           so the kernel can route directly to the server's socket.
 */
struct socket_d *socket_get_tcpserver_socket_by_port(unsigned short port)
{
    struct server_d *srv;
    int i;

    for (i=0; i < SERVER_COUNT_MAX; i++)
    {
        srv = (struct server_d *) serverList[i];
        if ((void*) srv != NULL){
            if (srv->magic == 1234)
            {
                if (srv->port == port){
                    return (struct socket_d *) srv->socket;  // Direct pointer to the listening socket
                }
            }
        }
    }

    return NULL;  // Not found
}

// Client‑side lookup (used when receiving SYN+ACK during connect):
// Emphasizes that this is for the local client initiating a connection,
// matching local client IP/port against the remote server IP/port.
struct connection_d *tcp_find_connection_client_side(
    unsigned int local_ip,
    unsigned short local_port,
    unsigned int remote_ip,
    unsigned short remote_port)
{
// Client is local

    int i;
    for (i = 0; i < MAX_CONNECTIONS; i++) 
    {
        struct connection_d *conn = connectionList[i];
        if (conn && conn->magic == 1234) 
        {
            if (conn->ep_pair && 
                conn->ep_pair->c_ep && 
                conn->ep_pair->s_ep) 
            {
                struct socket_d *c_sock = conn->ep_pair->c_ep->socket; // local client
                struct socket_d *s_sock = conn->ep_pair->s_ep->socket; // remote server

                if (c_sock && c_sock->magic == 1234 &&
                    s_sock && s_sock->magic == 1234)
                {
                    // Client is local
                    if (c_sock->ip_ipv4 == local_ip &&
                        c_sock->port    == local_port &&
                        s_sock->ip_ipv4 == remote_ip &&
                        s_sock->port    == remote_port)
                    {
                        return (struct connection_d *) conn; // Found the right connection
                    }
                }
            }
        }
    }
    return NULL; // Not found
}

// Server‑side lookup (used when receiving SYN during accept): 
// Emphasizes that this is for the local server listening, 
// matching remote client IP/port against the local server IP/port.
//
// What’s happening:
// Bind phase: 
//     Local server socket gets ip_ipv4 = 127.0.0.1 or 0.
// SYN arrives from remote client: 
//     Destination IP in packet = dhcp_info.your_ipv4_int.
//

struct connection_d *tcp_find_connection_server_side(
    unsigned int local_ip,
    unsigned short local_port,
    unsigned int remote_ip,
    unsigned short remote_port)
{
// Client is remote

    int i;
    for (i=0; i < MAX_CONNECTIONS; i++) 
    {
        struct connection_d *conn = connectionList[i];
        if (conn && conn->magic == 1234) 
        {
            if ( conn->ep_pair && 
                 conn->ep_pair->c_ep && 
                 conn->ep_pair->s_ep ) 
            {
                struct socket_d *c_sock = conn->ep_pair->c_ep->socket;
                struct socket_d *s_sock = conn->ep_pair->s_ep->socket;

                if ( c_sock && 
                     c_sock->magic == 1234 &&
                     s_sock && 
                     s_sock->magic == 1234 )
                {
                    // Client is remote
                    if (c_sock->ip_ipv4 == remote_ip &&
                        c_sock->port    == remote_port &&
                        s_sock->ip_ipv4 == local_ip &&
                        s_sock->port    == local_port )
                    {
                        return (struct connection_d *) conn; // Found the right connection
                    }
                }
            }
        }
    }
    return NULL; // Not found
}


// tcp_find_connection_by_remote_peer:
// Client-side lookup. Finds the connection whose REMOTE endpoint
// (the peer we sent a SYN to) matches the given ip:port.
// Used when a SYN-ACK arrives, to locate the connection object
// that tcp_client_connect() created for the matching SYN.
// Client-side lookup: find the connection we created in tcp_client_connect()
// by matching the REMOTE peer (s_ep).
struct connection_d *
tcp_find_connection_by_remote_peer(unsigned int remote_ip, unsigned short remote_port)
{
    register int i;
    struct connection_d *conn;
    struct socket_d *remote_sock;

    for (i = 0; i < MAX_CONNECTIONS; i++)
    {
        conn = (struct connection_d *) connectionList[i];
        if ((void *) conn == NULL)
            continue;
        if (conn->magic != 1234)
            continue;
        if (conn->type != CONN_TYPE_TCP)
            continue;
        if ((void *) conn->ep_pair == NULL)
            continue;
        if ((void *) conn->ep_pair->s_ep == NULL)
            continue;

        remote_sock = conn->ep_pair->s_ep->socket;
        if ((void *) remote_sock == NULL)
            continue;
        if (remote_sock->magic != 1234)
            continue;

        // In tcp_client_connect():
        //   pair->c_ep = local client
        //   pair->s_ep = remote server
        if (remote_sock->ip_ipv4 == remote_ip &&
            remote_sock->port    == remote_port)
        {
            return conn;
        }
    }

    return NULL;
}

struct connection_d *tcp_find_connection_by_client(
    unsigned int remote_ip,
    unsigned short remote_port)
{
    int i;
    for (i = 0; i < MAX_CONNECTIONS; i++) 
    {
        struct connection_d *conn = connectionList[i];
        if (conn && conn->magic == 1234) 
        {
            if (conn->ep_pair && conn->ep_pair->c_ep) 
            {
                struct socket_d *c_sock = conn->ep_pair->c_ep->socket;
                if (c_sock && c_sock->magic == 1234) 
                {
                    if (c_sock->ip_ipv4 == remote_ip &&
                        c_sock->port    == remote_port)
                    {
                        return conn; // Found by client side only
                    }
                }
            }
        }
    }
    return NULL; // Not found
}


struct connection_d *
tcp_find_connection_by_local_socket(struct socket_d *sk)
{
    register int i;
    struct connection_d *conn;
    struct socket_d *sk00;

    if ((void *) sk == NULL)
        return NULL;
    if (sk->magic != 1234)
        return NULL;

    for (i = 0; i < MAX_CONNECTIONS; i++)
    {
        conn = (struct connection_d *) connectionList[i];
        if ((void *) conn == NULL)
            continue;
        if (conn->magic != 1234)
            continue;
        if (conn->type != CONN_TYPE_TCP)
            continue;
        if ((void *) conn->ep_pair == NULL)
            continue;
        if ((void *) conn->ep_pair->c_ep == NULL)
            continue;
        sk00 = (struct socket_d *) conn->ep_pair->c_ep->socket;
        if (sk00 == sk)
            return conn;
    }

    return NULL;
}

// #debug
// Show the private socket for a process
void show_socket_for_a_process(pid_t pid)
{
    struct te_d  *p;
    struct socket_d  *s;

    // #debug
    printk ("Socket info for pid %d: \n", pid);

// Parameter
    if (pid<0 || pid >= PROCESS_COUNT_MAX){
        printk ("pid limits\n");
        goto fail;
    }

// process
    p = (struct te_d *) teList[pid];
    if ((void *) p == NULL){
        printk("p\n");
        goto fail;
    }
    if ( p->used != TRUE || p->magic != 1234 ){
        printk("p validation\n");
        goto fail;
    }

// Socket struture.
// Pega o ponteiro para a estrutura privada de soquete.
    s = (struct socket_d *) p->priv;
    if ((void *) s == NULL){
        printk("s\n");
        goto fail;
    }
    if (s->used != TRUE || s->magic != 1234){
        printk ("s validation\n");
        goto fail;
    }

// done:
// Show sockaddr structure
    printk ("family %d \n", s->addr.sa_family);
    printk ("data %s   \n", s->addr.sa_data);
    // ...
    return;

fail:
   return;
}

// Get from the current process.
// Get the pointer for the socket structure 
// given the fd.
// OUT: Returning a pointer for a 
// ring0 socket structure.
struct socket_d *get_socket_from_fd(int fd)
{
    struct te_d *p;
    pid_t current_process = -1;
    file *fp;

// Parameter:
    if (fd<0 || fd >= OPEN_MAX){
        goto fail;
    }

//----------------
// #todo: We need a worker for that routine.
// process

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);
    if (current_process < 0 || 
        current_process >= PROCESS_COUNT_MAX)
    {
        goto fail;
    }

    p = (struct te_d *) teList[current_process];
    if ((void *) p == NULL){
        goto fail;
    }
    // magic?
//----------------

// The file pointer
    fp = (file *) p->Objects[fd];
    if ((void *) fp == NULL){
        goto fail;
    }
    if (fp->magic != 1234){
        goto fail;
    }

// Return the pointer for the socket structure given the fd.
    return (struct socket_d *) fp->socket;
fail:
    return NULL;
}

// #ps: 
// Both are files that belongs to the same process. 
// The current process.
int
sock_socketpair ( 
    int family, 
    int type, 
    int protocol, 
    int usockvec[2] )
{
    int fd1 = -1; 
    int fd2 = -1;
    struct socket_d *sock1;
    struct socket_d *sock2;

// #todo
// Check parameters.

// ===============
    fd1 = (int) sys_socket(family,type,protocol);
    // #todo: Check validation.
    sock1 = (struct socket_d *) get_socket_from_fd(fd1);
    if ((void*) sock1 == NULL){
        debug_print("sock_socketpair: sock1\n");
        return -1;
    }
// ===============
    fd2 = (int) sys_socket(family,type,protocol);
    // #todo: Check validation.
    sock2 = (struct socket_d *) get_socket_from_fd(fd2);
    if ((void*) sock2 == NULL){
        debug_print("sock_socketpair: sock2\n");
        return -1;
    }
// #todo
// Antes é preciso verificar a área de memória.
    usockvec[0] = (int) fd1;
    usockvec[1] = (int) fd2;

    return 0;
}

// #test: Dialog (procedure) for multiple services.
// socket_dialog
// Serviços de soquetes da klibc
// #todo: rever os números.
// #todo: devemos mudar os argumentos 
// para ficar no padrão da libc.
// OUT: ?
unsigned long 
socket_dialog ( 
    unsigned long number, 
    unsigned long arg2, 
    unsigned long arg3, 
    unsigned long arg4 )
{

    // #debug
    printk ("socket_dialog: number=%d \n", number);

    if ( number < 7000 || number >= 8000 ){
        //message
        return 0;
    }

// Service numbers
    switch (number)
    {
        // socket(...)
        // family, type, protocol
        // vai retornar o descritor de uma stream.
        case 7000:
            debug_print ("socket_dialog: 7000. sys_socket\n");
            return (unsigned long) sys_socket ( (int) arg2, 
                                       (int) arg3, (int) arg4 );
            break;

        // send
        // case 7001:
        //     return (unsigned long) 1;
        //     break;

        // ...

        default:
            debug_print ("socket_dialog: default\n");
            printk      ("socket_dialog: default\n");
            break;
    };

// Fail
    return 0;
}

unsigned int getSocketIPV4(struct socket_d *socket)
{
    if ((void *) socket == NULL){
        return 0;
    }
    if (socket->magic != 1234){
        return 0;
    }
    return (unsigned int) socket->ip_ipv4;
}

unsigned long getSocketIPV6(struct socket_d *socket)
{
    if ((void *) socket == NULL){
        return 0;
    }
    if (socket->magic != 1234){
        return 0;
    }
    return (unsigned long) socket->ip_ipv6;
}

unsigned short getSocketPort(struct socket_d *socket)
{
    if ((void *) socket == NULL){
        return 0;
    }
    if (socket->magic != 1234){
        return 0;
    }
    return (unsigned short) socket->port;
}

// Get the socket structure in the process list given the port number.
struct socket_d *get_socket_in_process_list(unsigned short target_port)
{
    struct socket_d *sock;
    register int i=0;
    struct te_d *process;

    for (i=0; i<PROCESS_COUNT_MAX; i++)
    {
        // Get process
        process = (struct te_d *) teList[i];
        if ((void*) process != NULL)
        {
            if (process->magic == 1234)
            {
                // Get the socket structure.
                sock = (struct socket_d *) process->priv;
                if ((void*) sock != NULL)
                {
                    if (sock->magic == 1234)
                    {
                        // Is it a socket structure?
                        if (sock->kobj._type == ObjectTypeSocket)
                        {
                            // OK, we have a valid socket structure.
                            // Let's find out if this is socket we're
                            // looking for.
                            if (sock->port == target_port){
                                return (struct socket_d *) sock;
                            }
                        }
                    }
                }
            }
        }
    };
    
fail:
    return NULL;
}

// Helper for updating ip:port into a socket
// Update ipv4 and port info
int 
update_socket ( 
    struct socket_d *socket, 
    unsigned int ip_ipv4, 
    unsigned short port )
{
    if ((void *) socket == NULL){
        return (int) -1;
    }
    socket->ip_ipv4 = (unsigned int) ip_ipv4;
    socket->port = (unsigned short) port;
    return 0;
}

int socket_read(int fd, char *buf, int count)
{
    debug_print ("socket_read:[TODO]\n");

    if (fd<0)
        return (int) -EINVAL;

// #todo:
// Here we can check if it is really a socket.

    return (int) __read_imp(fd, buf, count);
}

// IN:
// fd = The file that handles the socket structure.
// buf
// count.
int socket_write(int fd, char *buf, int count)
{
    debug_print ("socket_write:[TODO]\n");

    if (fd<0)
        return (int) -EINVAL;

// #todo:
// Here we can check if it is really a socket.

    return (int) __write_imp(fd, buf, count);
}


/*
 * socket_close:
 * -----------------
 * Kernel-side implementation of close() for socket file descriptors.
 *
 * Purpose:
 *   Initiates the TCP connection shutdown sequence when a process
 *   calls close() on a socket. This routine drives the TCP state
 *   machine into the correct closing path depending on who initiated
 *   the shutdown.
 *
 * Behavior:
 *   • If the peer closed first (conn->status == CONN_STATUS_CLOSE_WAIT):
 *       - We send our FIN.
 *       - Transition to CONN_STATUS_LAST_ACK.
 *       - LAST_ACK means: waiting for the peer to ACK our FIN.
 *         Once acknowledged, the connection goes to CLOSED.
 *
 *   • If we are initiating the close (conn->status == CONN_STATUS_ESTABLISHED):
 *       - We send our FIN.
 *       - Transition to CONN_STATUS_FIN_WAIT1.
 *       - FIN_WAIT1 means: waiting for the peer to ACK our FIN.
 *         If the peer also sends its FIN, we may move to CLOSING
 *         or FIN_WAIT2 before reaching CLOSED.
 *
 *   • After the peer ACKs our FIN:
 *       - Transition to CONN_STATUS_CLOSED.
 *       - Socket state becomes SS_CLOSED.
 *
 * Notes:
 *   - This routine should also release or mark the socket and
 *     connection structures for reuse.
 *   - Proper FIN/ACK exchange ensures a clean shutdown and prevents
 *     half-open connections.
 */

int socket_close(struct socket_d *sk)
{
    // #debug
    printk("socket_close: #test\n");

// Socket
    if (!sk) 
        return -EINVAL;
    if (sk->magic != 1234) 
        return -EINVAL;

// Connection
    struct connection_d *conn = sk->conn;
    if (!conn) 
        return -ENOTCONN;
    if (conn->magic != 1234) 
        return -ENOTCONN;

// LAST_ACK:
// Meaning: The peer closed first (you received their FIN), and 
// you replied with your own FIN.
// The peer closed first (we were in CLOSE_WAIT).
// We sent our FIN in response and are now waiting
// for the peer to ACK it. Once acknowledged, the
// connection transitions to CLOSED.

// FIN_WAIT1:
// Meaning: Your side has initiated the close by sending a FIN.
// We sent a FIN to the peer, beginning the active close.
// Waiting for an ACK of our FIN. If the peer also sends
// its own FIN, we will move to CLOSING or FIN_WAIT2.


// Connection status
    if (conn->status == CONN_STATUS_CLOSE_WAIT) {
        // #todo: Send FIN
        // Change status to last_ack
        conn->status = CONN_STATUS_LAST_ACK;
        sk->state = SS_DISCONNECTING;
    }
    else if (conn->status == CONN_STATUS_ESTABLISHED) {
        // #todo: Send FIN
        // Change status to fin_wait1
        conn->status = CONN_STATUS_FIN_WAIT1;
        sk->state = SS_DISCONNECTING;
    } else {
        printk("socket_close: Invalid connection state\n");
    }

    // After peer ACKs our FIN:
    conn->status = CONN_STATUS_CLOSED;
    sk->state = SS_CLOSED;

    // #todo:
    // Release or mark to reuse the socket structure
    // Release or mark to reuse the connection structure

    return 0;   // OK
}

int socket_ioctl(int fd, unsigned long request, unsigned long arg)
{
    struct te_d *p;
    pid_t current_process = -1;
    file *fp;
    struct socket_d *sk;

    debug_print ("socket_ioctl: TODO\n");

// Parameters
    if (fd < 0 || fd >= OPEN_MAX){
        return (int) (-EBADF);
    }
// ...

// process

    // Get PID for the current process for a given core.
    // IN: core id
    current_process = (pid_t) get_current_process(0);
    p = (void*) teList[current_process];
    if ((void *) p == NULL)
    {
        debug_print("socket_ioctl: p\n");
        goto fail;
    }
    if (p->magic != 1234){
        debug_print("socket_ioctl: p validation\n");
        goto fail;
    }

// file
    fp = (file *) p->Objects[fd];
    if ((void *) fp == NULL){
        debug_print("socket_ioctl: fp\n");
        goto fail;
    }
    if (fp->used != TRUE || fp->magic != 1234)
    {
        panic("socket_ioctl: fp validation\n");
    }

// socket
// #ps: It needs to be a socket object.

    // Is it a socket object?
    if (fp->____object != ObjectTypeSocket){
        debug_print("socket_ioctl: fp is not a socket\n");
        return -ENOTSOCK;
    }

    sk = fp->socket;
    if (!sk) 
        return -ENOTSOCK;
    if (sk->magic != 1234) 
        return -ENOTSOCK;

// Request

    switch (request){


    // === Standard requests ===
    case FIONBIO:  // toggle non-blocking mode
        if (arg){ 
            fp->_flags |= O_NONBLOCK;
        } else {     
            fp->_flags &= ~O_NONBLOCK;
        }
        return 0;
        break;

    case FIONREAD: {
        int available = (fp->_w >= fp->_r) ? (fp->_w - fp->_r) : 0;
        if (fp->_fsize > 0 && 
            available > (fp->_fsize - fp->_r)) 
        {
            available = fp->_fsize - fp->_r;
            if (available < 0) 
                available = 0;
        }
        // If socket not readable, return 0
        if (fp->sync.can_read != TRUE) 
            available = 0;
            return available;
        }
        break;

    case 4000:
        debug_print ("socket_ioctl: [4000]\n");
        printk("socket_ioctl: [4000] fd %d pid %d #debug\n", fd, arg);
        // Is it a valid pid?
        fp->sync.sender_pid = (pid_t) arg;
        return 0;
        break;

    case 4001:  return (int) fp->sync.sender_pid;   break;
    case 4002:  return (int) fp->sync.can_read;     break;
    case 4003:  return (int) fp->sync.can_write;    break;
    case 4004:  return (int) fp->sync.can_execute;  break;
    // ...

    // === Debugging / custom flags ===
    case 4100:  // toggle debug mode
        // sk->debug = (int) arg;
        return 0;
        break;

    default:
        return (int) (-EINVAL);
        break;
    };

fail:
    return (int) -1;
}


// #todo:
// Configura a estrutura de socket para um socket da família AF_GRAMADO.
// Vai retornar o descritor de um arquivo.
int 
socket_gramado ( 
    struct socket_d *sock, 
    int family, 
    int type, 
    int protocol )
{
// Called by sys_socket().

    struct te_d *Process;
    pid_t current_process = -1;
    file *_file;
    char *buff;
    register int i=0;
    int __slot = -1;

    //debug_print ("socket_gramado:\n");

// Parameters
    if ((void*) sock == NULL){
        debug_print ("socket_gramado: sock\n");
        goto fail;
    }
    if (sock->magic != 1234){
        debug_print ("socket_gramado: sock validation\n");
        goto fail;
    }
    if (family != AF_GRAMADO){
        debug_print ("socket_gramado: family\n");
        goto fail;
    }

/*
// #todo: Valid types for AF_GRAMADO
    int IsValidType = FALSE;
    // #ps: Everything is valid for now
    switch (type){
    case SOCK_DGRAM:  IsValidType = TRUE;  break;
    case SOCK_RAW:    IsValidType = TRUE;  break;
    default:
        IsValidType = TRUE;
        break;
    };
*/

    sock->addr.sa_family = family;
    // 2 bytes pathname
    sock->addr.sa_data[0] = 'x';  // xx are placeholders
    sock->addr.sa_data[1] = 'x';

// #todo
// For AF_GRAMADO the type needs to be SOCK_RAW
// and the protocol needs to be GRAMADO_PROTOCOL.

// Process

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if ( current_process < 0 || current_process >= PROCESS_COUNT_MAX ){
        printk ("socket_gramado: current_process\n");
        goto fail;
    }
    Process = (void *) teList[current_process];
    if ((void *) Process == NULL){
        printk("socket_gramado: Process\n");
        goto fail;
    }
    if (Process->used != TRUE || Process->magic != 1234){
        printk("socket_gramado: Process validation\n");
        goto fail;
    }

//#todo
//temos que criar uma rotina que procure slots em Process->Objects[]
//e colocarmos em process.c
//essa é afunção que estamos criando.
    
    // process_find_empty_stream_slot ( struct te_d *process );

// #improvisando
// 0, 1, 2 são reservados para o fluxo padrão.
// Como ainda não temos rotinas par ao fluxo padrão,
// pode ser que peguemos os índices reservados.
// Para evitar, começaremos depois deles.
// Reserva um slot.
// 31 is also reserved. The server is reading only in this fd.

    __slot = -1;  //fail

    // #ps: 
    // 31 is out limit, but we have 32 slots.
    // The last one is reserved.

    for ( i=3; i<31; i++ )
    {
        if (Process->Objects[i] == 0)
        { 
            __slot = (int) i;
            break; 
        }
    };

// Check slot validation
    if (__slot == -1){
        printk ("socket_gramado: [FAIL] No free slots\n");
        goto fail;
    }

// Buffer
    buff = (char *) kmalloc(BUFSIZ);
    if ((void *) buff == NULL)
    {
        debug_print ("socket_gramado: buff fail\n");
        printk      ("socket_gramado: buff fail\n");
        goto fail;
    }

// File
    _file = (void *) kmalloc ( sizeof(file) );
    if ((void *) _file == NULL)
    {
        debug_print ("socket_gramado: [FAIL] _file fail\n");
        printk      ("socket_gramado: [FAIL] _file fail\n");
        goto fail;
    }
    memset( _file, 0, sizeof(struct file_d) );

// Object type
    _file->____object = ObjectTypeSocket;

// #todo: Call the methods
    _file->pid = (pid_t) current_process;
    _file->uid = (uid_t) current_user;
    _file->gid = (gid_t) current_group;

// sync
// #todo: Maybe we can have a method for this routine.

    _file->sync.sender_pid = (pid_t) -1;
    _file->sync.receiver_pid = (pid_t) -1;
    _file->sync.action = ACTION_NULL;
    _file->sync.can_read    = TRUE;
    _file->sync.can_write   = TRUE;
    _file->sync.can_execute = FALSE;
    _file->sync.can_accept  = TRUE;
    _file->sync.can_connect = TRUE;

    _file->sync.block_on_read = FALSE;
    _file->sync.block_on_read_empty = TRUE;

    _file->sync.block_on_write = TRUE;
    _file->sync.block_on_write_full = TRUE;

// Is it blocked?
    _file->sync.is_blocked = FALSE;
// flags
    _file->_flags = __SWR;  // OK to write.

// No name for now.
    _file->_tmpfname = NULL;
    //_file->_tmpfname = "socket";

// Buffer

    _file->_base = buff;
    _file->_p    = buff;
    _file->_lbfsize = BUFSIZ;
    _file->_cnt = _file->_lbfsize;  // The empty space
    // Offsets
    _file->_r = 0;
    _file->_w = 0;
// Status do buffer do socket
    _file->socket_buffer_full = 0;

//
// Socket
//

// Socket pointer
// Associando a estrutura de socket à estrutura de arquivo.
    _file->socket = sock;
// O arquivo do soquete, o buffer ?
    sock->private_file = (file *) _file; 
// Socket pointer.
// Salvamos o ponteira para estrutura de soquete
// na estrutura de processo do processo atual.
    Process->priv = (void *) sock;

    _file->_file = __slot;  // Save fd

    // Save the pointer into the list of open files
    Process->Objects[__slot] = (unsigned long) _file;

    _file->used = TRUE;
    _file->magic = 1234;

    return (int) __slot;  // Return fd

fail:
    debug_print ("socket_gramado: fail\n");
    return (int) (-1);
}

// Configura a estrutura de socket para um socket da
// família AF_UNIX or AF_LOCAL.
// Precisa ser uma rotina parecida com a do outro tipo criado.
// Called by sys_socket().
int 
socket_unix ( 
    struct socket_d *sock, 
    int family, 
    int type, 
    int protocol )
{
    struct te_d *Process;
    pid_t current_process = -1;
    file *_file;
    char *buff;
    register int i=0;
    int __slot = -1;

    //debug_print ("socket_unix:\n");

// Parameters
    if ((void*) sock == NULL){
        debug_print ("socket_unix: sock\n");
        goto fail;
    }
    if (sock->magic != 1234){
        debug_print ("socket_unix: sock validation\n");
        goto fail;
    }
    if (family != AF_UNIX){
        debug_print ("socket_unix: family\n");
        goto fail;
    }

/*
// #todo: Valid types for AF_UNIX
    int IsValidType = FALSE;
    // #ps: Everything is valid for now
    switch (type){
    case SOCK_STREAM: IsValidType = TRUE;  break;
    case SOCK_DGRAM:  IsValidType = TRUE;  break;
    case SOCK_RAW:    IsValidType = TRUE;  break;
    default:
        IsValidType = TRUE;
        break;
    };
*/

    sock->addr.sa_family = family;
    // Pathname
    sock->addr.sa_data[0] = 'x';  // xx are placeholders
    sock->addr.sa_data[1] = 'x';

// #test
// GRAMADO_PROTOCOL is a valid protocol in AF_UNIX.

// Process

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if ( current_process < 0 || current_process >= PROCESS_COUNT_MAX )
    {
        printk ("socket_unix: current_process\n");
        goto fail;
    }
    Process = (void *) teList[current_process];
    if ((void *) Process == NULL){
        printk("socket_unix: Process\n");
        goto fail;

    }
    if ( Process->used != TRUE || Process->magic != 1234 ){
        printk("socket_unix: Process validation\n");
        goto fail;
    }

// #todo
// Temos que criar uma rotina que procure slots em Process->Streams[]
// e colocarmos em process.c
// essa é afunção que estamos criando.
// process_find_empty_stream_slot ( struct te_d *process );

// #improvisando
// 0, 1, 2 são reservados para o fluxo padrão.
// Como ainda não temos rotinas par ao fluxo padrão,
// pode ser que peguemos os índices reservados.
// Para evitar, começaremos depois deles.

    __slot = -1;
    // Reserva um slot.
    //for ( i=3; i< NUMBER_OF_FILES; i++ )
    for ( i=3; i< 31; i++ )
    {
        if ( Process->Objects[i] == 0 )
        { 
            __slot = (int) i; 
            break; 
        }
    };

// Check slot validation
    if (__slot == -1){
        printk ("socket_unix: No free slots\n");
        goto fail;
    }

// Buffer
    buff = (char *) kmalloc(BUFSIZ);
    if ((void *) buff == NULL){
        //Process->Objects[__slot] = (unsigned long) 0;
        debug_print ("socket_unix: [FAIL] Buffer allocation fail\n");
        printk      ("socket_unix: [FAIL] Buffer allocation fail\n");
        goto fail;
    }

// File
    _file = (void *) kmalloc( sizeof(file) );
    if ((void *) _file == NULL){
        //Process->Objects[__slot] = (unsigned long) 0;
        printk ("socket_unix: _file fail\n");
        goto fail;
    }
    memset( _file, 0, sizeof(struct file_d) );

// #todo: 
// Podemos adiar isso para o fim da rotina.
    _file->used = TRUE;
    _file->magic = 1234;

// #todo: Use methods.
    _file->pid = (pid_t) current_process;
    _file->uid = (uid_t) current_user;
    _file->gid = (gid_t) current_group;

    _file->____object = ObjectTypeSocket;

// sync
// #todo: Maybe we can have a method for this routine.

    _file->sync.sender_pid = (pid_t) -1;
    _file->sync.receiver_pid = (pid_t) -1;
    _file->sync.action = ACTION_NULL;
    _file->sync.can_read = TRUE;
    _file->sync.can_write = TRUE;
    _file->sync.can_execute = FALSE;
    _file->sync.can_accept = TRUE;
    _file->sync.can_connect = TRUE;

    _file->sync.block_on_read = FALSE;
    _file->sync.block_on_read_empty = TRUE;

    _file->sync.block_on_write = TRUE;
    _file->sync.block_on_write_full = TRUE;

// Is it blocked?
    _file->sync.is_blocked = FALSE;
// Flags
    _file->_flags = __SWR;  // OK to write.

// No name for now.
// #bugbug: 
// unix sockets has names.
// it's like a normal fs pathname.
    _file->_tmpfname = NULL;
    //_file->_tmpfname = "/tmp/socketXXX";    

// Buffer

    _file->_base = buff;
    _file->_p    = buff;
    _file->_lbfsize = BUFSIZ; 
// Quanto falta
    _file->_cnt = _file->_lbfsize;
    _file->_r = 0;
    _file->_w = 0;
    _file->socket_buffer_full = 0;  

//
// Socket
//

    _file->socket = sock;
// O arquivo do soquete, o buffer?
    sock->private_file = (file *) _file; 
// Salvamos o ponteira para estrutura de soquete
// na estrutura de processo do processo atual.
    Process->priv = (void *) sock;

// fd
    _file->_file = __slot;
//Colocando na lista de arquivos abertos no processo.
    Process->Objects[__slot] = (unsigned long) _file;
// ok.
// Retornamos o fd na lista de arquivos abertos pelo processo.
    return (int) __slot;

fail:
    debug_print ("socket_unix: fail\n");
    return (int) (-1);
}

// Configura a estrutura de socket para um socket da
// família AF_INET.
// Precisa ser uma rotina parecida com a do outro tipo criado.
// Esse domínio lida com tcp/ip ?

// #todo
// Based on the socket type when the domain is AF_INET.
// + SOCK_STREAM = tcp socket.
// + SOCK_DGRAM  = udp socket.
// + SOCK_RAW    = raw socket.

// Called by sys_socket() in socket.c
int 
socket_inet ( 
    struct socket_d *sock, 
    int family,
    int type, 
    int protocol )
{
    struct te_d *Process;
    pid_t current_process = -1;
    file *fp;
    char *buff;
    register int i=0;
    int __slot = -1;

// Parameters
    if ((void*) sock == NULL){
        debug_print ("socket_inet: sock\n");
        goto fail;
    }
    if (sock->magic != 1234){
        debug_print ("socket_inet: sock validation\n");
        goto fail;
    }
    if (family != AF_INET){
        debug_print ("socket_inet: family\n");
        goto fail;
    }

// #ps:
// For AF_INET (IPv4), the valid socket types are 
// SOCK_STREAM, SOCK_DGRAM, and SOCK_RAW.
// #todo:
// Some client-side application are using AF_INET. 
// We gotta check the types they are using.

    // #todo: Valid types for AF_INET
    int IsValidType = FALSE;
    // #ps: Everything is valid for now
    switch (type){
    case SOCK_STREAM: IsValidType = TRUE;  break;
    case SOCK_DGRAM:  IsValidType = TRUE;  break;
    case SOCK_RAW:    IsValidType = TRUE;  break;
    default:
        IsValidType = TRUE;
        break;
    };

    // family
    sock->addr_in.sin_family = AF_INET;
    // ip, port
    sock->addr_in.sin_addr.s_addr = SYS_SOCKET_IP(0,0,0,0);
    sock->addr_in.sin_port = 0;
    // #todo:
    // This is a default port number ... we need to pick 
    // a valid one for each process created.

// #todo
// Based on the socket type when the domain is AF_INET.
// + SOCK_STREAM = tcp socket.
// + SOCK_DGRAM  = udp socket.
// + SOCK_RAW    = raw socket.

    // Already done when the socket was created.
    // sock->type = type;
    // sock->type = protocol;

// #test
// GRAMADO_PROTOCOL is a valid protocol in AF_INET.

// Process
// Get PID for the current process for a given core.
// IN: core id

    current_process = (pid_t) get_current_process(0);

    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        printk ("socket_inet: current_process\n");
        goto fail;
    }
    Process = (void *) teList[current_process];
    if ((void *) Process == NULL){
        printk("socket_inet: Process\n");
        goto fail;
    }
    if ( Process->used != TRUE || Process->magic != 1234 ){
        printk("socket_inet: Process validation\n");
        goto fail;
    }

//#todo
//temos que criar uma rotina que procure slots em Process->Streams[]
//e colocarmos em process.c
//essa é afunção que estamos criando.

    // process_find_empty_stream_slot ( struct te_d *process );

// #improvisando
// 0, 1, 2 são reservados para o fluxo padrão.
// Como ainda não temos rotinas par ao fluxo padrão,
// pode ser que peguemos os índices reservados.
// Para evitar, começaremos depois deles.
    
    __slot=-1;
    //for ( i=3; i< NUMBER_OF_FILES; i++ )
    for ( i=3; i< 31; i++ )
    {
        if (Process->Objects[i] == 0)
        {
            __slot = (int) i;
            break;
        }
    };

// Fail
    if (__slot == -1){
        printk ("socket_inet: No free slots\n");
        goto fail;
    }

// Buffer
    buff = (char *) kmalloc(BUFSIZ);
    if ((void *) buff == NULL){
        //Process->Objects[__slot] = (unsigned long) 0;
        debug_print ("socket_inet: [FAIL] Buffer allocation fail\n");
        printk      ("socket_inet: [FAIL] Buffer allocation fail\n");
        goto fail;
    }

// File
// Create a new file structure and clear the structure.
    fp = (void *) kmalloc(sizeof(file));
    if ((void *) fp == NULL){
        //Process->Objects[__slot] = (unsigned long) 0;
        printk ("socket_inet: fp fail\n");
        goto fail;
    }
    memset( fp, 0, sizeof(struct file_d) );

// Object type
    fp->____object = ObjectTypeSocket;
// Save it into the socket structure
    sock->private_file = (file *) fp;

// #todo: Use methods to grab these values
    fp->pid = (pid_t) current_process;
    fp->uid = (uid_t) current_user;
    fp->gid = (gid_t) current_group;

// sync
// #todo: Maybe we can use methods for this routine.
    fp->sync.sender_pid = (pid_t) -1;
    fp->sync.receiver_pid = (pid_t) -1;
    fp->sync.action = ACTION_NULL;
    fp->sync.can_read = TRUE;
    fp->sync.can_write = TRUE;
    fp->sync.can_execute = FALSE;
    fp->sync.can_accept = TRUE;
    fp->sync.can_connect = TRUE;

    fp->sync.block_on_read = FALSE;
    fp->sync.block_on_read_empty = TRUE;

    fp->sync.block_on_write = TRUE;
    fp->sync.block_on_write_full = TRUE;

// Is it blocked?
    fp->sync.is_blocked = FALSE;
// flags 
    fp->_flags = __SWR;  // OK to write.

// No name for now.
    fp->_tmpfname = NULL;
    //fp->_tmpfname = "socket";

// Buffer support:
    fp->_base = buff;
    fp->_p = buff;
    fp->_lbfsize = BUFSIZ;
// Quanto falta
    fp->_cnt = fp->_lbfsize;
    fp->_r = 0;
    fp->_w = 0;
    fp->socket_buffer_full = 0;

    fp->_file = __slot;  // File descriptor. (fd) (id)

// Validation
    fp->used = TRUE;
    fp->magic = 1234;

//
// Socket
//

    fp->socket = sock;

// Salvamos o ponteira para estrutura de soquete
// na estrutura de processo do processo atual.
    Process->priv = (void *) sock;

// Inject fp (structure pointer) into the list of open files
    Process->Objects[__slot] = (unsigned long) fp;

    return (int) __slot;  // OK, return the fd

fail:
    debug_print ("socket_inet: fail\n");
    return (int) (-1);
}

//
// #
// INITIALIZATION
//

// Initialize socket list
int socket_init(void)
{
    register int i=0;

    for (i=0; i<32; i++){
        socketList[i] = (unsigned long) 0;
    };

    // A table for PIDs of the local servers
    __initialize_gramado_server_pids_table();

    // A table for PIDs of TCP connection servers
    __initialize_gramado_tcpserver_pids_table();

    // ...
    return 0;
}

