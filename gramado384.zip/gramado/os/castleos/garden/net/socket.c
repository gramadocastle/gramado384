// socket.c
// Wrappers for the implementation of main libc socket related functions.
// Kernel-side implementation of socket infrastructure.
// The APIs for the syscalls related to sockets.
// Called by sci.c
// #ps: Implementations are in sockint.c
// Created by Fred Nora.

// See:
// https://en.wikipedia.org/wiki/Berkeley_sockets

#include <kernel.h>  

// Used by sys_connect().
// Random base number for new port numbers for the clients.
#define BASE_NEW_CLIENT_PORT_NUMBER  11000
static unsigned short __new_client_port_number = 
    BASE_NEW_CLIENT_PORT_NUMBER;

// Used by sys_connect().
unsigned char localhost_ipv4[4] = { 127, 0, 0, 1 };


static int __listen_imp(int sockfd, int backlog);

static int 
__accept_imp (
    int sockfd, 
    struct sockaddr *addr, 
    socklen_t *addrlen,
    unsigned long flags );

static int 
__connect_af_gramado ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags );

static int 
__connect_inet_local ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags );

static int 
__connect_inet_remote ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags );

static int __connect_inet(
    int sockfd,
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags);

// ====================


int 
sys_getsockname ( 
    int sockfd, 
    struct sockaddr *addr, 
    socklen_t *addrlen )
{
// Service 7007

// Process, file and socket.
    struct te_d  *p;
    pid_t current_process = -1;
    struct file_d     *f;
    struct socket_d   *s;

// Parameter
    if ( sockfd < 0 || sockfd >= OPEN_MAX ){
        printk ("sys_getsockname: sockfd\n");
        goto fail;
    }
// addr
// Usando a estrutura que nos foi passada.
    if ((void *) addr == NULL){
        printk ("sys_getsockname: addr\n");
        goto fail;
    }
// Invalid pointer for return value.
    if ((void*)addrlen == NULL){
        printk ("sys_getsockname: addrlen\n");
        return (int) (-EINVAL);
    }

// process

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    p = (struct te_d *) teList[current_process]; 
    if ((void *) p == NULL){
        printk ("sys_getsockname: p fail\n");
        goto fail;
    }

// file
    f = (file *) p->Objects[sockfd];
    if ((void *) f == NULL){
        printk ("sys_getsockname: f fail\n");
        goto fail;
    }

//socket
    s = (struct socket_d *) p->priv;
    if ((void *) s == NULL){
        printk ("sys_getsockname: s fail\n");
        goto fail;
    }

// Everything is ok.
// So now we need to include the 'name' into the socket structure
// respecting the socket's family.
    register int n = 0;
    
    if (s->addr.sa_family == AF_GRAMADO)
    {
        // Binding the name to the socket.
        printk ("sys_getsockname: Getting the name and the size\n");
        addrlen[0] = n;
        // Always 14.
        for (n=0; n<14; n++){
            addr->sa_data[n] = s->addr.sa_data[n];
        };
        debug_print ("sys_getsockname: copy ok\n");

        // Done!
        return 0;
    }

    // #todo
    // More families.
    //if ( ...
    //if ( ...
    //if ( ...
    // ...

    printk ("sys_getsockname: process %d ; family %d ; len %d\n", 
        current_process, addr->sa_family, addrlen  );
 
 fail:
    printk ("sys_getsockname: fail\n");
    return (int) -1;
}

// libc shutdown() function.
// See: https://linux.die.net/man/3/shutdown
int sys_socket_shutdown(int socket, int how)
{
// Service 7009

    // #todo
    // Desconectar dois sockets,
    // mas nao destruir o socket?

// The current process.
    struct te_d *p;
    pid_t current_process = -1;
// The file indicated by the fd.
    file *f;
// The socket structure for the file.
    struct socket_d *s;
// Is this file a socket object?
    int IsSocketObject = -1;

    debug_print ("sys_socket_shutdown: [TODO]\n");
    //printk      ("sys_socket_shutdown: [TODO] fd=%d how=%d\n",
    //    socket, how );

// Invalid fd.
    if ( socket < 0 || socket >= OPEN_MAX ){
        debug_print ("sys_socket_shutdown: [FAIL] fd\n");
        printk      ("sys_socket_shutdown: [FAIL] fd\n");
        return (int) (-EBADF);
    }

// Process

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if (current_process < 0  || current_process >= PROCESS_COUNT_MAX){
        printk      ("sys_socket_shutdown: p fail\n");
        goto fail;        
    }
    p = (struct te_d *) teList[current_process];
    if ((void *) p == NULL){
        debug_print ("sys_socket_shutdown: p fail\n");
        printk      ("sys_socket_shutdown: p fail\n");
        goto fail;
    }

// File
// sender's file
// Objeto do tipo socket.

    f = (file *) p->Objects[socket];
    if ((void *) f == NULL){
        debug_print("sys_socket_shutdown: f fail\n");
        printk     ("sys_socket_shutdown: f fail\n");
        goto fail;
    }

// Is this file a socket object?
    IsSocketObject = (int) is_socket((file *) f);
    if (IsSocketObject != TRUE){
        return (int) (-ENOTSOCK);
    }

// Socket
// Yes, This is a socket object.
// Let's get the socket structure associated with the file.
// Let's simply change the flag for this socket.
    s = (struct socket_d *) f->socket;
    if ((void *) s == NULL){
        debug_print ("sys_socket_shutdown: s fail\n");
        printk      ("sys_socket_shutdown: s fail\n");
        goto fail;
    // permanece conectado, mas usaremos outro da fila.
    } else {
        s->state = 216;  // ?
        return 0;
    };

    // ...

fail:
    debug_print("sys_socket_shutdown: [FAIL]\n");
    printk     ("sys_socket_shutdown: [FAIL]\n");
    return (int) -1;
}


// https://linux.die.net/man/2/sendto
ssize_t 
sys_sendto ( 
    int sockfd, 
    const void *ubuf, 
    size_t len, 
    int flags,
    const struct sockaddr *dest_addr, 
    socklen_t addrlen )
{
/*
    if (sockfd < 0 || !ubuf || len == 0 || !dest_addr)
        return -EINVAL;

    struct sockaddr_in *k_dest_addr = (struct sockaddr_in *)dest_addr;
    if (addrlen < sizeof(struct sockaddr_in))
        return -EINVAL;

    // Convert the destination IP address from struct sockaddr_in
    uint8_t target_ip[4] = { k_dest_addr->sin_addr.s_addr & 0xFF,
                             (k_dest_addr->sin_addr.s_addr >> 8) & 0xFF,
                             (k_dest_addr->sin_addr.s_addr >> 16) & 0xFF,
                             (k_dest_addr->sin_addr.s_addr >> 24) & 0xFF };

    uint8_t target_mac[6] = {  }; // Resolve MAC via ARP or existing table 
    unsigned short source_port = ; //Retrieve from socket state
    unsigned short target_port = ntohs(k_dest_addr->sin_port);

    // Call the UDP worker function using the user-provided buffer directly
    int ret = network_send_udp(source_ip, target_ip, target_mac, source_port, target_port, (char *)ubuf, len);

    return (ret < 0) ? ret : len; // Return number of bytes sent or error code

*/
    return (int) -ENOSYS;
}

ssize_t sys_sendmsg (int sockfd, const struct msghdr *msg, int flags)
{
/*
    if (sockfd < 0 || !msg || msg->msg_iovlen == 0)
        return -EINVAL; // Invalid argument

    struct sockaddr_in *dest_addr = (struct sockaddr_in *)msg->msg_name;
    if (!dest_addr || msg->msg_namelen < sizeof(struct sockaddr_in))
        return -EINVAL;

    // Convert destination IP
    uint8_t target_ip[4] = { dest_addr->sin_addr.s_addr & 0xFF,
                             (dest_addr->sin_addr.s_addr >> 8) & 0xFF,
                             (dest_addr->sin_addr.s_addr >> 16) & 0xFF,
                             (dest_addr->sin_addr.s_addr >> 24) & 0xFF };

    uint8_t target_mac[6] = {  };   // Resolve MAC via ARP or internal table
    unsigned short source_port = ;  // Retrieve from socket state 
    unsigned short target_port = ntohs(dest_addr->sin_port);

    // Compute total buffer length
    size_t total_len = 0;
    for (int i = 0; i < msg->msg_iovlen; i++)
        total_len += msg->msg_iov[i].iov_len;

    if (total_len == 0)
        return -EINVAL; // No data to send

    // Call the UDP worker directly using user-space buffer(s)
    int ret = network_send_udp(source_ip, target_ip, target_mac, source_port, target_port,
                               (char *)msg->msg_iov[0].iov_base, total_len);

    return (ret < 0) ? ret : total_len; // Return bytes sent or error code
*/

    return (int) -ENOSYS;
}

//
// ============================================================
// Well know libc methods for socket support
//


/*
 * sys_socket:
 * This is the socket() function implementation.
 * Estamos na klibc dentro do kernel base.
 */
// The function socket() creates an endpoint for communication and 
// returns a file descriptor for the socket.
// socket() creates a new socket of a certain type, 
// identified by an integer number, and 
// allocates system resources to it.
// See: 
// https://www.gnu.org/software/libc/manual/html_node/Sockets.html
// #example:
// tcp_socket = socket(AF_INET, SOCK_STREAM, 0);
// udp_socket = socket(AF_INET, SOCK_DGRAM, 0);
// raw_socket = socket(AF_INET, SOCK_RAW, protocol);
// #todo
// Fazer um switch para tratar os vários tipos.
// Se o protocolo for '0', então precisamos encontrar o 
// protocolo adequado.
// OUT:
//     fd if ok.
//     -1 if it fails.

// Service 7000
// #ps: This wrapper calls some workers inside sockint.c file.
int sys_socket(int family, int type, int protocol)
{
    struct endpoint_d *ep;
    struct socket_d *sk;

    // Current process
    struct te_d *p;
    pid_t current_process = -1;

// ip:port
// Used in the socket struture
    unsigned long _ipv6  = (unsigned long)  0x0000000000000000;
    unsigned int _ipv4   = (unsigned int)   0x00000000;
    unsigned short _port = (unsigned short) 0x0000;
    int Verbose = FALSE;

    // #debug

    /*
    if (Verbose == TRUE){
        printk ("\n======================================\n");
        printk ("sys_socket: PID %d | family %d | type %d | protocol %d \n",
            current_process, family, type, protocol );
    }
    */

    // #ps: Using core 0
    //debug_print("sys_socket:\n");
    do_credits_by_tid( lapic_info[0].current_tid );

// Filters
// For now we're only accepting AF_UNIX, AF_INET and AF_GRAMADO.
    if (family < 0){
        debug_print ("sys_socket: family not supported\n");
        return (int) (-EINVAL);
    }

// #todo
// Based on the socket type when the domain is AF_INET.
// + SOCK_STREAM = tcp socket.
// + SOCK_DGRAM  = udp socket.
// + SOCK_RAW    = raw socket.
// #todo: SOCK_GRAMADO_MSG

    if (type != SOCK_STREAM &&
        type != SOCK_DGRAM  &&
        type != SOCK_RAW)
    {
        debug_print ("sys_socket: type not supported\n");
        return (int) (-EINVAL);
    }

// #todo
// We are accepting only the gramado native protocol for the sockets.
// Each kind of request has its own message structure.
// For now the message starts in the top of the buffer, 
// there is no ethernet header or tcp/ip header and the message
// is not in the payload. This is a plain for the future. #todo.
// 0 = GRAMADO NATIVE PROTOCOL.
    if (protocol < 0){
        debug_print ("sys_socket: protocol not supported\n");
        return (int) (-EINVAL);
    }

// #debug
// '0' is the only valid value for now.
    if (protocol != 0)
    {
        //panic("sys_socket: protocol not supported yet.\n");
    }

//
// Process
//

    // Current pid
    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX){
        debug_print ("sys_socket: current_process fail\n");
        panic       ("sys_socket: current_process fail\n");
    }
// Process structure
    p = (struct te_d *) teList[current_process];
    if ((void *) p == NULL){
        debug_print ("sys_socket: p\n");
        panic       ("sys_socket: p\n");
    }
    if (p->magic != 1234){
        panic ("sys_socket: p validation\n");
    }

// -----------------------------------
// socket structure:

    // Allocate memory for a socket structure and 
    // initialize some basic fields.
    sk = (struct socket_d *) create_socket_object();
    if ((void *) sk == NULL){
        debug_print ("sys_socket: sk\n");
        printk      ("sys_socket: sk\n");
        goto fail;
    }
    // family, type and protocol.
    sk->family = family;
    sk->type = type;
    sk->protocol = protocol;
    // Initialize with zeros
    sk->ip_ipv6 = (unsigned long) _ipv6;
    // ip:port
    sk->ip_ipv4 = (unsigned int) _ipv4;
    sk->port = (unsigned short) _port;

    // #ps: Redundant. It was already done during the
    // creationg of the socket object.
    // pid, tid, uid, gid.
    // #todo: Use methods to grab these informations.
    sk->pid = (pid_t) current_process;
    sk->tid = (tid_t) lapic_info[0].current_tid;
    sk->uid = (uid_t) current_user;
    sk->gid = (gid_t) current_group;
// -----------------------------------

   // #bugbug: 
   // And if a process creates another socket?
    p->priv = (struct socket_d *) sk;

// -----------------------------------
// ep structure:

    // Allocate memory for the ep structure and 
    // fill some basic fields.
    ep = (struct endpoint_d *) create_endpoint_object();
    if ((void*) ep == NULL)
        panic("sys_socket: ep\n");
    if (ep->magic != 1234)
        panic("sys_socket: ep->magic\n");
    // Save the pointer for the socket in the ep structure.
    // Valid for local and remote connection;
    ep->socket = sk;
    ep->is_remote = FALSE;  // default until connect()
    // #ps: Saving the ep pointer for future usage
    sk->ep = ep;
// -----------------------------------

// The workers here will create a file associated with 
// this new socket and return the fd for the caller.
// see: sockint.c
    switch (family){

    case AF_GRAMADO:
        debug_print ("sys_socket: AF_GRAMADO\n");
        sk->connection_type = 1;  // (local connection) (IPC)
        return (int) socket_gramado( (struct socket_d *) sk, 
                        AF_GRAMADO, type, protocol );
        break;

    // AF_UNIX (aka AF_LOCAL) → 
    // Local interprocess communication (IPC) via Unix domain sockets.
    // AF_LOCAL has the same value.
    case AF_UNIX:
        debug_print ("sys_socket: AF_UNIX\n");
        sk->connection_type = 1;  // (local connection) (IPC)
        return (int) socket_unix ( (struct socket_d *) sk, 
                        AF_UNIX, type, protocol );
        break;

    // AF_INET6 → IPv6 networking.
    // case AF_INET6: break;

    //#bugbug: 
    //talvez precisamos rever sockaddr 
    //para essa função, e usarmos outra estrutura.
    // AF_INET → IPv4 networking (TCP/UDP).        
    case AF_INET:
        debug_print ("sys_socket: AF_INET\n");
        // #bugbug: We dont know if the client will
        // connecth with local or remote using inet.
        sk->connection_type = 0;
        //sk->connection_type = 1;  // Local connection.
        // (Remote or local connection)
        // It depends on the IP address.
        // If the IP address is Localhost, so it is a local connection.
        // #todo: For now we set it to '0'.

        int IsValidProtocol = FALSE;
        //if (type == SOCK_STREAM)
        if (type == SOCK_STREAM || type == SOCK_SEQPACKET)
        {
            if (protocol == 0){
                sk->protocol = IPPROTO_TCP;
            }
            if (protocol == IPPROTO_TCP){
                IsValidProtocol = TRUE;
            }
            if (IsValidProtocol != TRUE){
                goto fail;
            }

            return (int) socket_inet( 
                (struct socket_d *) sk, AF_INET, type, sk->protocol );
        }

        // For now we're only accepting raw sockets
        // AF_INET sockets can also use a type of SOCK_RAW. 
        // If this type is set, the application connects directly to the IP layer and 
        // does not use either the TCP or UDP transport.
        // #bugbug #todo
        // But in this case, for local connections we're gonna use raw type
        // and do not use any protocol ... just the raw frame.

        if (type == SOCK_RAW)
        {
            return (int) socket_inet( 
                (struct socket_d *) sk, AF_INET, type, protocol );
        }

        break;

    // AF_PACKET → Raw access to Ethernet frames (used by tcpdump, Wireshark).
    //case AF_PACKET: break;

    // AF_NETLINK → Kernel ↔ user space communication (used by iproute2, netfilter).
    //case AF_NETLINK: break;

    // AF_BLUETOOTH → Bluetooth communication.
    // AF_BTH in Windows
    //case AF_BLUETOOTH: break;

    // AF_IRDA → Infrared sockets (legacy).

    // ...

    default:
        debug_print ("sys_socket: [FAIL] bad family\n");
        //debug_print ("sys_socket: Couldn't create the file\n");
        goto fail;
        break;
    };

    // ...

fail:
    debug_print ("sys_socket: fail\n");
    return (int) (-1);
}

/*
 * sys_bind:
 *    When a socket is created with socket(), it exists in a 
 *    name space (address family) but has no address assigned to it. 
 *    bind() assigns the address specified by addr to the socket 
 *    referred to by the file descriptor sockfd.
 */
// bind() is typically used on the server side, and 
// associates a socket with a socket address structure, 
// i.e. a specified local 'IP address' and a 'port number'.
// See:
// https://man7.org/linux/man-pages/man2/bind.2.html
// Service 7003

int 
sys_bind ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen )
{
    struct te_d  *p;   // Process
    pid_t current_process = -1;
    struct file_d     *f;   // File
    struct socket_d   *s;   // Socket
    register int i=0;
    int Verbose=FALSE;

    // #debug
    //debug_print ("sys_bind:\n");
    do_credits_by_tid( lapic_info[0].current_tid );

// fd
    if ( sockfd < 0 || sockfd >= OPEN_MAX )
    {
        debug_print("sys_bind: sockfd\n");
        printk     ("sys_bind: sockfd\n");
        return (int) (-EBADF);
    }

// Check addr structure
    if ((void *) addr == NULL)
    {
        debug_print("sys_bind: addr\n");
        printk     ("sys_bind: addr\n");
        goto fail;
    }

// Address validation.
// It needs to be a ring3 address.
// #todo: Check agains more limits.
    if (addr < FLOWERTHREAD_BASE){
        panic("sys_bind: addr is not ring3\n");
        //return (int) (-EINVAL);
    }

// Invalid lenght for the address.
    if (addrlen == 0)
        return (int) (-EINVAL);

// Process

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    // #debug
    if (Verbose == TRUE){
        printk("sys_bind: PID %d | fd %d \n", current_process, sockfd );
    }
    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        printk("sys_bind: current_process\n");
        goto fail;
    }
    p = (struct te_d *) teList[current_process];
    if ((void *) p == NULL){
        debug_print("sys_bind: p\n");
        printk     ("sys_bind: p\n");
        goto fail;
    }
    if (p->magic != 1234){
        printk("sys_bind: p validation\n");
        goto fail;
    }

// file:
// The objects type is 'socket'.

    f = (file *) p->Objects[sockfd];
    if ((void *) f == NULL){
        debug_print ("sys_bind: f\n");
        printk      ("sys_bind: f\n");
        goto fail;
    }
    if (f->magic != 1234){
       printk("sys_bind: f validation\n");
       goto fail; 
    }

// Is this file a socket object?
    if ( is_socket(f) != TRUE ){
        return (int) (-ENOTSOCK);
    }

// socket structure:
// A socket object has a socket structure associates with the file.
    s = (struct socket_d *) f->socket;
    if ((void *) s == NULL){
        debug_print("sys_bind: s\n");
        printk     ("sys_bind: s\n");
        goto fail; 
    }

// family
// Binding the name to the socket.
// So, now we need to include the 'name' into the socket structure,
// respecting the socket's family.
// Each family has a different size?
// For now we have only two server, gwssrv and gnssrv,
// and they are using this type of family.

//
// Domains
//

// AF_GRAMADO: Uses a symbolic service name (sa_data) as the endpoint identity
// AF_UNIX:    Uses a pathname in sa_data
// AF_INET:    Uses ip:port as the endpoint identity


// ---------------------
// AF_GRAMADO
// Copy. Always 14.
// #important:
// For this family, the information associated with the
// servers socket is a two byte string. Example: 'ws' or 'ns'.

    if (s->addr.sa_family == AF_GRAMADO)
    {
        debug_print ("sys_bind: [AF_GRAMADO] Bind the name to the socket\n");

        //memset(&s->addr, 0, sizeof(struct sockaddr));

        for (i=0; i<14; i++){
            s->addr.sa_data[i] = addr->sa_data[i];
        };
        // #debug
        if (Verbose == TRUE){
            printk ("sys_bind: process %d | family %d | len %d\n", 
                current_process, addr->sa_family, addrlen  );
        }

        s->addr.sa_family = addr->sa_family;

        // No IP/port for these families
        // s->ip_ipv4 = 0;
        // s->port    = 0;

        return 0;  // Done
    }

// ---------------------
// AF_UNIX ou AF_LOCAL
// See: http://man7.org/linux/man-pages/man7/unix.7.html
    if (s->addr.sa_family == AF_UNIX)
    {
        debug_print ("sys_bind: AF_UNIX not supported yet\n");
        printk      ("sys_bind: AF_UNIX not supported yet\n");

        //memset(&s->addr, 0, sizeof(struct sockaddr));

        for (i=0; i<14; i++){
            s->addr.sa_data[i] = addr->sa_data[i];
        };
        // #debug
        if (Verbose == TRUE){
            printk ("sys_bind: process %d | family %d | len %d\n", 
                current_process, addr->sa_family, addrlen  );
        }

        s->addr.sa_family = addr->sa_family;

        // No IP/port for these families
        // s->ip_ipv4 = 0;
        // s->port    = 0;
        
        goto fail;
    }

// ---------------------
// AF_INET
    struct sockaddr_in *in_addr = (struct sockaddr_in *) addr;

    if (in_addr->sin_family == AF_INET)
    {
        debug_print ("sys_bind: AF_INET family\n");
        printk      ("sys_bind: AF_INET family\n");

        // Copy values into the socket structure
        s->addr_in.sin_family      = in_addr->sin_family;
        s->addr_in.sin_addr.s_addr = in_addr->sin_addr.s_addr;
        s->addr_in.sin_port        = in_addr->sin_port;

        // Copy IP:PORT
        s->ip_ipv4 = ntohl(in_addr->sin_addr.s_addr);  // convert to host order
        s->port    = ntohs(in_addr->sin_port);         // convert to host order
        //s->ip_ipv4 = in_addr->sin_addr.s_addr;
        //s->port = ntohs(in_addr->sin_port);

        // Mark socket as bound
        s->state = SS_UNCONNECTED;
        s->flags = 0;

        if (s->port == 0){
            printk("sys_bind: Port not defined\n");
            goto fail;
        }

        printk("sys_bind: AF_INET bound to IP %x port %d\n",
            s->ip_ipv4, s->port );

        // #test: Register our new AF_INET server
        int slot = socket_find_empty_tcpserver_slot();
        if (slot >= 0) 
        {
            struct server_d *srv = kmalloc(sizeof(struct server_d));
            memset(srv, 0, sizeof(struct server_d));

            // Quick hook
            srv->pid = current_process;   // PID
            srv->port = s->port;  // The port

            // Real store
            srv->process = p;       // te_d for the process
            srv->file    = f;       // file_d from Objects[sockfd]
            srv->socket  = s;       // direct pointer to socket_d

            // Validation
            srv->used = TRUE;
            srv->magic = 1234;

            serverList[slot] = (unsigned long) srv;

            // #important:
            printk("AF_INET server registered: pid=%d port=%d slot=%d\n",
               current_process, s->port, slot);

        } else {
            printk("sys_bind: No free TCP server slots\n");
        }

        return 0;  // done
    }

// #fail
// A família é de um tipo não suportado.
    debug_print ("sys_bind: [FAIL] family not valid\n");
    printk      ("sys_bind: [FAIL] family not valid\n");

fail:
    debug_print ("sys_bind: fail\n");
    printk      ("sys_bind: fail\n");
    return (int) (-1);
}

/*
 * __listen_imp:
 *     It's used to say that the server ready to accept connections 
 * and how many connection it accepts.
 */
// Used by a server to place a stream socket in a passive state, 
// indicating that it is ready to accept incoming client connection requests.
// listen() is used on the server side, and 
// causes a bound TCP socket to enter listening state.
// Setup how many pending connections.
// See:
// https://man7.org/linux/man-pages/man2/listen.2.html
/*
 The backlog argument defines the maximum length to which the queue of
 pending connections for sockfd may grow. If a connection request
 arrives when the queue is full, the client may receive an error with
 an indication of ECONNREFUSED or, if the underlying protocol supports
 retransmission, the request may be ignored so that a later reattempt
 at connection succeed.
*/
// SOMAXCONN is the default limit on backlog.
// IN:
// sockfd  = The fd of the server's socket.
// backlog = The server indicates the 'size of the list'.
static int __listen_imp(int sockfd, int backlog) 
{
    file *f;
    int DesiredBacklog=0;
    struct socket_d  *server_socket;

    struct te_d  *p;
    pid_t current_process = -1;

    int i=0;

    do_credits_by_tid( lapic_info[0].current_tid );

// #debug
    //debug_print ("__listen_imp: [TODO]\n");
    //printk      ("__listen_imp: [TODO] fd=%d backlog=%d\n",
        //sockfd, backlog);

// Parameter
// The fd of the server's socket.
    if (sockfd < 0 || sockfd >= OPEN_MAX)
    {
        debug_print ("__listen_imp: sockfd\n");
        printk      ("__listen_imp: sockfd\n");
        return (int) (-EBADF);
    }

// ==============================================

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        printk("__listen_imp: current_process\n");
        goto fail;
    }
// process
    p = (struct te_d *) teList[current_process];
    if ((void *) p == NULL){
        debug_print("__listen_imp: p fail\n");
        printk     ("__listen_imp: p fail\n");
        goto fail;
    }

// The server's socket fd opens the fp associated with a socket structure.
    f = (file *) p->Objects[sockfd];
    if ((void *) f == NULL){
        debug_print("__listen_imp: f fail\n");
        printk     ("__listen_imp: f fail\n");
        goto fail;
    }

// Is this file a socket object?
    int IsSocketObject = -1;
    IsSocketObject = (int) is_socket((file *) f);
    if (IsSocketObject != TRUE){
        return (int) (-ENOTSOCK);
    }

// This is right place for doing this?
// Not ready yet?
    //f->sync.can_accept = TRUE;

// Get the socket structure associated with the file
    server_socket = (struct socket_d *) f->socket;
    if ((void *) server_socket == NULL){
        printk("__listen_imp: server_socket fail\n");
        goto fail;
    }
    server_socket->isAcceptingConnections = FALSE;  // ?

    // #todo: Why?
    if (f->socket != p->priv){
        panic("__listen_imp: [TEST] f->socket != p->priv\n");
    }

//
// Backlog
//

// The limit of connected clients.
// #bugbug:
// It can't be bigger than the size of the array.
// #todo: Use SOCKET_MAX_PENDING_CONNECTIONS
// SOMAXCONN

    DesiredBacklog = backlog;
    if (DesiredBacklog < 1) { DesiredBacklog=1; }
    if (DesiredBacklog > 31){ DesiredBacklog=31; }

    // Set backlog value
    server_socket->backlog_max = (int) DesiredBacklog;
 
    // what is this?
    for (i=0; i<32; i++){
        server_socket->pending_server_endpoints[i] = 0;
        server_socket->pending_client_endpoints[i] = 0;
    };
    server_socket->pending_server_count = 0;
    server_socket->pending_client_count = 0;

// This server now listening and accepting new connections
    server_socket->state = SS_LISTENING;
    server_socket->isAcceptingConnections = TRUE;
    return 0;

fail:
    debug_print("__listen_imp: fail\n");
    printk     ("__listen_imp: fail\n");
    return (int) -1;
}

// Service 7004
// Called by sci.c
// IN:
// sockfd  = The fd of the server's socket.
// backlog = The server indicates the 'size of the list'.
// #todo: Listen operation is not valid for datagrams.
int sys_listen (int sockfd, int backlog)
{
    int rv=0;

// There is a file associated with the server's socket.
    if ( sockfd < 0 || sockfd >= OPEN_MAX )
    {
        debug_print ("sys_listen: sockfd\n");
        printk      ("sys_listen: sockfd\n");
        return (int) (-EBADF);
    }

// Call the implemetation
    rv = (int) __listen_imp(sockfd, backlog);

    return (int) rv;
}

/*
 * __accept_imp: 
 *     This is a work in progress.
 */
// accept() is used on the server side. 
// It accepts a received incoming attempt to create 
// a new TCP connection from the remote client, 
// and creates a new socket associated with 
// the socket address pair of this connection.
// #todo
// Pega um socket da lista de conexoes incompletas.
// Nosso maior objetivo aqui eh retornar o fd arquivo 
// de socket do cliente.
// #todo
// We need to create a new socket. Only this way the process
// will have a new file in p->Objects[].
// == todo =========================
// #solution
// We create a new socket and connect this 
// new socket with the client.
// This way we can return the fd of the socket.
// #obs:
// When write() writes in the new socket, the data
// will be copied to the client socket. But it can be only an option.
/*
 * From Linux 0.98.1:
 * For accept, 
 * we attempt to create a new socket, 
 * set up the link with the client, 
 * wake up the client, then 
 * return the new connected fd.
 */
// #importante: Retornando o fd do cliente.
// Dessa forma o servido pode escrever nele
// e o cliente poderá ler.

// The listening socket is being reused as a communication endpoint
// That is not the standard way. We need to create a new socket 
// for each client, spetially for remote connections.

// #ps: 'addrlen' is a pointer.
static int 
__accept_imp (
    int sockfd, 
    struct sockaddr *addr, 
    socklen_t *addrlen,
    unsigned long flags )
{
// Service 7002

    //#todo: see: net.h
    //struct connection_d *our_connection;

// Server process
    struct te_d *sProcess;
    pid_t current_process = -1;

//  The listening socket
    struct socket_d *listening_socket;
// The connection end points (Good for local connections)
    struct socket_d *ep1_pending_socket; 
    struct socket_d *ep2_accepted_socket;

// Files for the server and client sockets.
    file *listening_fp;
// Connection
    file *ep1_pending_fp;
    file *ep2_accepted_fp;  //#todo

// File descriptors for the server and client sockets.
    int listening_fd = -1;
// Connection
    //int ep1_pending_fd = -1;
    //int ep2_pending_fd = -1;

// Iterator for the pending connections queue
    register int i=0;

    unsigned long Flags = flags;

    int Verbose = FALSE;  // #debug

    // #debug
    // debug_print ("sys_accept:\n");
    do_credits_by_tid(lapic_info[0].current_tid);

//
// fd Server 
//

// #todo
// O argumento dá o descritor para o socket do servidor.
// A função accept seleciona um dos sockets da lista
// de conexões pendentes criadas por listen() e conecta
// com o socket do servidor.
// Ao fim devemos retornar o descritor do socket selecionado
// na lista de conexões pendentes.

    listening_fd = sockfd;
    if ( listening_fd < 0 || listening_fd >= OPEN_MAX )
    {
        debug_print ("__accept_imp: [FAIL] listening_fd\n");
        return (int) (-EBADF);
    }

// Check parameter validation: (addr)
// #ps: 
// We still do not know what is the type/size of the structure.
// Not in use yet!

    if ((void *) addr == NULL){
        printk("__accept_imp: addr\n");
        return (int) (-EINVAL);
    }

// It can't be less that the base of a ring 3 thread.
// #todo: Check agains more limits

    if (addr < FLOWERTHREAD_BASE){
        panic("__accept_imp: addr is not ring3\n");
        //return (int) (-EINVAL);
    }

// #ps:
// What is this?
// The 'addrlen' argument is a value-result argument: 
// The caller must initialize it to contain the size (in bytes) 
// of the structure pointed to by addr. On return it will contain 
// the actual size of the peer address.
// See: https://man7.org/linux/man-pages/man2/accept.2.html

// #todo:
// We are not setting up this return value yet

// Is it and invalid pointer for return value?
    if ((void*)addrlen == NULL){
        return (int) (-EINVAL);
    }

// Current process. (The server)
// The accept() was called by the server.

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if ( current_process < 0  || current_process >= PROCESS_COUNT_MAX )
    {
        debug_print ("__accept_imp: [FAIL] current_process\n");
        printk      ("__accept_imp: [FAIL] current_process\n");
        goto fail;
    }
// Server process
    sProcess = (struct te_d *) teList[current_process];
    if ((void *) sProcess == NULL){
        debug_print ("__accept_imp: [FAIL] sProcess\n");
        printk      ("__accept_imp: [FAIL] sProcess\n");
        goto fail;
    }
    if ( sProcess->used != TRUE || sProcess->magic != 1234 ){
        debug_print ("__accept_imp: [FAIL] sProcess validation\n");
        printk      ("__accept_imp: [FAIL] sProcess validation\n");
        goto fail;
    }

// file:
// The object/file related with the server socket.
// The socket is a file and belongs to the process.

    listening_fp = (file *) sProcess->Objects[listening_fd];
    if ((void *) listening_fp == NULL){
        debug_print ("__accept_imp: listening_fp fail\n");
        printk      ("__accept_imp: listening_fp fail\n");
        goto fail;
    }
    if ( listening_fp->used != TRUE || listening_fp->magic != 1234 )
    {
        printk ("__accept_imp: [FAIL] listening_fp validation\n");
        goto fail;
    }
// Is this file a socket object?
    if ( is_socket(listening_fp) != TRUE ){
        return (int) (-ENOTSOCK);
    }
    if (listening_fp->sync.can_accept != TRUE){
        debug_print ("__accept_imp: listening_fp can NOT accept connections\n");
             printk ("__accept_imp: listening_fp can NOT accept connections\n");
        goto fail;
    }

// Get the server's private socket.
// And check its validation.

    listening_socket = (struct socket_d *) listening_fp->socket;
    if ((void *) listening_socket == NULL){
        printk      ("__accept_imp: [FAIL] listening_socket\n");
        goto fail;
    }
    if ( listening_socket->used != TRUE || listening_socket->magic != 1234 )
    {
        printk("__accept_imp: [FAIL] listening_socket validation\n");
        goto fail;
    }

/*
    // #test
    // The indicated socket need to be the same of the privete socket.
    if (f->socket != s){
        //#debug Testing ...
        panic("sys_accept: [FIXME] Check the original socket in the process %d!",
            current_process);
    }
 */

    // #debug
    //printk ("sys_accept: process %d | family %d | len %d \n", 
        //current_process, addr->sa_family, addrlen  );

// sys_accept deve apenas pegar um fd da lista de conexoes
// pending_client_endpoints[].
// Lembre-se que o fd do cliente estah numa lista em outro processo.
 
// #test
// Se o socket do servidor já está conectado.
// Se ele jah esta conectado, entao o seu slave tem um arquivo e esse
// arquivo deve ir para a lista de arquivos abertos pelo processo?
// Estamos retornando o fd do proprio servidor porque o write() 
// copia de um socket para o outro. Mas a intençao nao eh essa.

// #todo
// Na verdade precisamos pegar um da fila.
// #test
// Se a conexão do socket do servidor está pendente.
// Pega um socket da lista de conexoes pendentes.
// #bugbug
// Devemos retornar o descritor do socket cliente.
// #todo: Para devolver um descritor para o servidor,
// então o socket do cliente deve estar na lista de
// arquivos abertos pelo servidor.
// #bugbug
// A estado de SS_CONNECTING foi atribuido pelo connect().
// Se connect() preconectar os sockets, isso será ruim,
// pois poderíamos transmitir dados mesmo antes do accept()
// selecionar um da fila de conexoes pendentes. 
// ele tambem esta em um dos slots e no slot 31.

// Se o socket ja está conectado ou 
// esta esperando para se conectar.

    int OldState = listening_socket->state;

    // #todo: This is the only valid state.
    // The rest cannot call accept()
    //if (listening_socket->state != SS_LISTENING)
        //return -EINVAL;

    // #ps: For now we are considering these states
    // as valid states for the Accept operation.
    if ( listening_socket->state == SS_LISTENING ||
         listening_socket->state == SS_CONNECTING || 
         listening_socket->state == SS_CONNECTED )
    {
        // Let's Indicate that the socket is connected
        // #todo:
        // But remember: The server can't use the listening socket for 
        // the connection. It needs to create a new one.

        listening_socket->state = SS_CONNECTED;

        // If there is another socket linked to the server socket.
        // #todo:
        // At this moment we get the first one from the 
        // list of pending connections, respecting the order.

        // Let's round using the backlog head.
        listening_socket->backlog_head++;
        if (listening_socket->backlog_head >= listening_socket->backlog_max){
            listening_socket->backlog_head = 0;
        }
        i = listening_socket->backlog_head;
        if ( i < 0 || 
             i >= listening_socket->backlog_max )
        {
            panic("__accept_imp: Backlog limits\n");
        }

        // Probe for a valid pointer.
        // OK. Let's get one client socket from the server's list.
        // That was include here when the client called connect().

        while (i <= listening_socket->backlog_max)
        {
            ep1_pending_socket = (struct socket_d *) listening_socket->pending_client_endpoints[i];
            if ((void*) ep1_pending_socket != NULL){
                break;
            }
            i++;  // next
        };

        // [NO] - Not valid Client socket
        if ((void*) ep1_pending_socket == NULL)
        {
            // #bugbug
            // No clients yet?
            // debug_print ("__accept_imp: [FAIL] ep1_pending_socket\n");
            
            listening_socket->state = OldState;  // Back to the old state
            goto fail;
        }

        // [YES] - Valid Client socket
        // Let's stablish the connection
        if ((void *) ep1_pending_socket != NULL)
        {
            // check validation
            if ( ep1_pending_socket->used != TRUE || 
                 ep1_pending_socket->magic != 1234 )
            {
                debug_print ("__accept_imp: [FAIL] ep1_pending_socket validation\n");
                listening_socket->state = OldState;  // Back to the old state
                goto fail;
            }

            // #test: 
            // What? The Magic C indicates a pending connection.
            if ( ep1_pending_socket->magic_string[0] == 'C' )
            {
                //debug_print("MAGIC C\n");
                //printk ("magic: %s\m",ep1_pending_socket->magic_string);
            }

            // Connection stablished
            ep1_pending_socket->state = SS_CONNECTED;

            // Get the file structure associated with the client socket
            ep1_pending_fp = (file *) ep1_pending_socket->private_file;

            // #ps: Important
            // Gramado OS Kernel is using the last slot, 31,
            // as a place to put the socket file. The server
            // ONLY read from this file.
            // This is the list of files opened by the server process.

            // Salvando o ponteiro de estrutura de arquivo 
            // no slot prealocado na inicializacao.
            // Essa é a estrutura de processo do servidor.

            //sProcess->Objects[ sProcess->_client_sock_fd ] = ep1_pending_fp;
            sProcess->Objects[31] = (unsigned long) ep1_pending_fp;  // last slot
            ep1_pending_fp->_file = 31;
            
            //debug_print ("__accept_imp: done\n");

            if (Verbose == TRUE)
            {
                printk("__accept_imp: Server's pid {%d}\n",current_process);
                printk("__accept_imp: Server's socket fd {%d}\n",sockfd);
                //printk("__accept_imp: Breakpoint\n");
                while (1){
                    asm (" cli "); 
                    asm (" hlt ");
                };
            }

            // #important:
            // Returning the fd for the file that represents
            // the client socket. Server will read/write from/in it.
            // #ps: It is always 31 in Gramado OS for now.

            return (int) ep1_pending_fp->_file;  // 31 
        }

        // fail
        debug_print ("__accept_imp: [FAIL] Pending connection\n");

        listening_socket->state = OldState;  // Back to the old state
        goto fail;
    }

// fail
// #todo:
// Are we already connected?
// So we need a flag to indicate this status.

fail:
    //debug_print ("sys_accept: [FAIL] Something is wrong!\n");
    return (int) -1;
}

// #ps: 'addrlen' is a pointer.
// #todo: Accept operation is not valid for datagrams.
int 
sys_accept (
    int sockfd, 
    struct sockaddr *addr, 
    socklen_t *addrlen )
{
    int rv=0;

    // #todo: This is test
    unsigned long Flags=0;

// Call the implementation
    rv = (int) __accept_imp( sockfd, addr, addrlen, Flags );
    return (int) rv;
}

int 
sys_gramado_accept (
    int sockfd, 
    struct sockaddr *addr, 
    socklen_t *addrlen )
{
    int rv=0;

    // #todo: This is test
    unsigned long Flags=0;

// Call the implementation
    rv = (int) __accept_imp( sockfd, addr, addrlen, Flags );
    return (int) rv;
}


// ============================================================
// __connect_af_gramado()
// Handle connections for AF_GRAMADO sockets.
// This worker is used when the socket family is Gramado native IPC.
// It bypasses TCP/IP and connects directly to local Gramado services.
// Called by sys_connect() when addr->sa_family == AF_GRAMADO.
// ============================================================

/*
 * __connect_af_gramado:
 *     Connecting to a server given an address.
 */
// connect() is used on the client side, and 
// assigns a free local port number to a socket. 
// In case of a TCP socket, it causes an attempt 
// to establish a new TCP connection.
// connect.
// Em nosso exemplo o cliente quer se conectar com o servidor.
// Conectando a um servidor dado um endereço.
// O endereço pode vir em formatos diferentes dependendo
// do domínio indicado na estrutura.
// #atenção
// O servidor poderá estar conectado a vários clientes,
// mas estará ouvindo a apenas um por vez. Ou precisaremos 
// de instâncias.
// #todo
// O socket do cliente precisa ter um fd no processo servidor.
// #??
// connect() eh chamado uma vez pelo cliente quando
// ele inicializa. Essa chamada fornece o fd do cliente.
// O servidor quando chama accept() seleciona um dos
// clientes conectados. 
// O servidor nao pode simplesmente aceitar
// o ultimo que se conectou.
// #bugbug: lembrando que nosso write copia de um socket para outro.
// Entao podemoriamos deixar as conexoes pendentes e selecionarmos
// somete uma a cada accept. 
// O write ira falhar se nao estiver conectado?
/*
 The backlog argument defines the maximum length to which the queue of
 pending connections for sockfd may grow.  If a connection request
 arrives when the queue is full, the client may receive an error with
 an indication of ECONNREFUSED or, if the underlying protocol supports
 retransmission, the request may be ignored so that a later reattempt
 at connection succeed.
*/
// At this moment, the operating system has to assign a not used 
// random port number to the client.
// IN: client fd, address, address len
// OUT: 0=ok <0=fail

static int 
__connect_af_gramado ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags )
{
// Worker, called by sys_connect().
// AF_GRAMADO, AF_UNIX/AF_LOCAL domains only.

// #todo
// O socket do cliente precisa de um arquivo aberto no
// processo alvo.
// #bugbug:
// Se nao fecharmos o arquivo ao fim da conexao, entao
// a lista de arquivos abertos se esgotara rapidamente.

// Client process and server process.
    struct te_d *cProcess;
    struct te_d *sProcess;
    pid_t target_pid = (-1);  //fail
// Client socket and server socket.
    struct socket_d *client_socket;
    struct socket_d *server_socket;
    int client_socket_fd = -1;
// File.
    struct file_d *f;
// #importante
// No caso de endereços no estilo inet
// vamos precisar de outra estrututura.

//No inet. This is for local domains only.
    //struct sockaddr_in *addr_in;

    int Verbose = FALSE;
    register int i=0;

    unsigned long Flags = connection_flags;

    unsigned char *given_ip;

    do_credits_by_tid( lapic_info[0].current_tid );

    // Get PID for the current process for a given core.
    // IN: core id

    pid_t current_process = (pid_t) get_current_process(0);

    if (Verbose == TRUE){
        printk ("__connect_af_gramado: Client's pid {%d}\n", current_process );
        printk ("__connect_af_gramado: Client's socket id {%d}\n", sockfd );
    }

// Client fd.
// client_socket_fd é um soquete de quem quer se conectar.
// O addr indica o alvo.
    client_socket_fd = sockfd;
    if ( client_socket_fd < 0 || client_socket_fd >= OPEN_MAX )
    {
        debug_print ("__connect_af_gramado: client_socket_fd\n");
        printk      ("__connect_af_gramado: client_socket_fd\n");
        return (int) (-EINVAL);
    }

// addr
// Usando a estrutura que nos foi passada.
    if ((void *) addr == NULL)
    {
        printk ("__connect_af_gramado: addr\n");
        return (int) (-EINVAL);
    }

//  ==============

// Getting the target PID.
// #todo:
// Devemos obter o número do processo alvo dado um endereço.
// O tipo de endereço depende do tipo de domínio (família).

// Tente inet, ao menos que mudemos de planos por 
// encontrarmos af_gramado, af_unix ou af_local.

// Let's try the AF_INET domain.
    //int IsRemote = FALSE;

// The client is trying to cennect to the localhost
// in the AF_INET domain.
    int in_localhost = FALSE;

// #importante
// opções de domínio se o endereço é no estilo unix. 
// >>> sockaddr

// ------------------------------------------
// Local
// Vamos pegar o pid do processo associado a determinada porta.
// Apenas as famílias AF_GRAMADO e AF_UNIX.
    switch (addr->sa_family){

    // #todo: This is a work in progress.
    //case AF_LOCAL:
    case AF_UNIX:
        // Trabalhando com pathname.
        debug_print ("__connect_af_gramado: AF_UNIX\n");
        printk      ("__connect_af_gramado: AF_UNIX\n");        
        goto fail;
        break;

    // AF_GRAMADO = 8000
    // Vamos obter o número do processo alvo dado o endereço.
    // 32 ports only.
    case AF_GRAMADO:
        // Trabalhando com string.

        debug_print ("__connect_af_gramado: AF_GRAMADO ok\n");

        // ds: Display server
        if ( addr->sa_data[0] == 'd' && addr->sa_data[1] == 's' ){
            target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_DS);
        }
        // wm: ...
        // ns: Network server
        if ( addr->sa_data[0] == 'n' && addr->sa_data[1] == 's' ){
            target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_NS);
        }
        // fs: File system server
        if ( addr->sa_data[0] == 'f' && addr->sa_data[1] == 's' ){
            target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_FS);
        }
        // #todo: we: Web server
        //if (addr->sa_data[0] == 'w' && addr->sa_data[1] == 'e'){
        //    target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_WE);
        //}
        // #todo:  ft: FTP server
        //if (addr->sa_data[0] == 'f' && addr->sa_data[1] == 't'){
        //    target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_FT);
        //}
        // #todo:  tn: Telnet server
        //if (addr->sa_data[0] == 't' && addr->sa_data[1] == 'n'){
        //   target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_TN);
        //}

        if ( target_pid<0 || target_pid >= PROCESS_COUNT_MAX ){
            printk ("__connect_af_gramado: AF_GRAMADO target_pid\n");
            goto fail;
        }
        if (Verbose == TRUE){
            printk ("__connect_af_gramado: target pid %d \n", target_pid);
        }
        break;

        // Not a local domains
        default:
            printk("__connect_af_gramado: This is not a valid local domain\n");
            goto fail;
            break;
    };

// ====================================================================
// OK, now we have a target pid for local domains.

// Check
// Have a valid target_pid ?

//__go:

//
// == Client process =============================
//

// Vamos obter o arquivo do tipo soquete que pertence ao sender.

    if (current_process<0 || current_process >= PROCESS_COUNT_MAX){
        printk ("__connect_af_gramado: current_process\n");
        goto fail;
    }

// Client process.
// sender's process structure.
    cProcess = (struct te_d *) teList[current_process];
    if ((void *) cProcess == NULL){
        debug_print("__connect_af_gramado: cProcess fail\n");
        printk     ("__connect_af_gramado: cProcess fail\n");
        goto fail;
    }

// #todo
// Check structure validation
    // if (cProcess->magic ...

// The client's socket file.
// #bugbug
// Estamos pegando o arquivo de socket do cliente
// Então estamos presumindo que é uma conexão local.
// Se o servidor fechar esse arquivo, então
// o cliente será incapaz de enviar mensagens?
// Por isso no momento do accept devemos
// criar um arquivo para o cliente. Que poderá ser fechado
// pelo sevidor para encessar a conexão ... até que
// o cliente se conecte novamente.
// #importante: Mas para isso o cliente precisa
// possuir um arquivo de socket ainda válido.
// O servidor não pode fechar o arquivo de socket do cliente remoto.
// E também não devemos permitir que isso aconteça na conexão local.

    f = (file *) cProcess->Objects[client_socket_fd];
    if ((void *) f == NULL){
        printk("__connect_af_gramado: [FAIL] f. The client's socket\n");
        goto fail;
    }

// Is this file a socket object?
    int IsSocketObject = -1;
    IsSocketObject = (int) is_socket((file *) f);
    if (IsSocketObject != TRUE){
        return (int) (-ENOTSOCK);
    }

// This file doesn't accept connections.
// #todo:
// This way we can reject connections before the server binds with an address.

    if (f->sync.can_connect != TRUE){
        printk("__connect_af_gramado: [PERMISSION FAIL] Client doesn't accept connections.\n");
        goto fail;
    }

// Client socket structure
// Socket structure in the sender's file.
// Pega a estrutura de socket associada ao arquivo.

    client_socket = (struct socket_d *) f->socket;
    if ((void *) client_socket == NULL){
        printk("__connect_af_gramado: [FAIL] client_socket\n");
        goto fail;
    }

// The client socket needs to be unconnected.
// #perigo
// Só podemos conectar se o socket estiver nesse estado.
// #todo
// Caso fechar conexão podemos perder esse estado 
// naõ conseguirmos mais conectar.

    if (client_socket->state != SS_UNCONNECTED) {
        printk("__connect_af_gramado: [FAIL] client socket is not SS_UNCONNECTED\n");
        goto fail;
    }


// #test
// Assign a port number to the client socket.
// #todo #bugbug We gotta work on this routine.
    __new_client_port_number++;
    client_socket->port = (unsigned short) __new_client_port_number;

// Server process
// #todo
// O arquivo de socket do cliente 
// precisa ter um fd no processo servidor.
// target pid.
// O pid do processo servidor.
// Pegamos o target_pid logo acima na porta solicitada.

    if (target_pid<0 || target_pid >= PROCESS_COUNT_MAX)
    {
        debug_print("__connect_af_gramado: target_pid\n");
        printk     ("__connect_af_gramado: target_pid\n");
        goto fail;
    }

// The server's process structure.
// O processo cliente chamou essa função e
// então pegaremos agora o processo alvo,
// que é um servidor.

    sProcess = (struct te_d *) teList[target_pid];
    if ((void *) sProcess == NULL){
        debug_print("__connect_af_gramado: sProcess fail\n");
        printk     ("__connect_af_gramado: sProcess fail\n");
        goto fail;
    }

// #todo
// Checar a validade da estrutura de processo.
    // if ( sProcess->magic != ...

// Procurando um slot livre na lista de objetos abertos
// presente na estrutura do processo servidor.

    register int __slot = -1;  // Default is fail.
    for (i=3; i<31; i++)
    {
        if (sProcess->Objects[i] == 0)
        {
            __slot = (int) i;
            goto __OK_new_slot;
        }
    };

// #fail: 
// No more slots.
    panic("__connect_af_gramado: [FIXME] We need a slot in the server\n");

// ok
__OK_new_slot:

    if (__slot == -1){
        printk("__connect_af_gramado: No empty slot\n");
        goto fail;
    }

// Esse é o socket do processo servidor.
// Sim, porque é o cliente que está tentando se conectar.
// Dessa forma o alvo é o servidor.

    server_socket = (struct socket_d *) sProcess->priv;
    if ((void *) server_socket == NULL){
        printk ("__connect_af_gramado: [FAIL] server_socket\n");
        goto fail;
    }

// Salvando o fd do socket do cliente.
    server_socket->clientfd_on_server = __slot;
    client_socket->clientfd_on_server = __slot;

// #todo
// Temos que rever as coisas por aqui. kkk
// incluimos como objeto do servidor o ponteiro para 
// o arquivo que representa o socket do cliente.
// O arquivo de socket do cliente agora tem um fd
// no processo servidor.
// Nossa intenção aqui é usar um dos slots livres
// encontrado em p->Objects[], mas por enquanto estamos usando 
// apenas o slot número 31.

// :: The free slot we found before.
    //sProcess->Objects[__slot] = (unsigned long) f;
// :: The standard fd used by the servers in GramadoOS.
    sProcess->Objects[31] = (unsigned long) f;


// Connecting!
// #bugbug
// connect() eh chamado somente uma vez pelo cliente.
// A conexao deve ficar pendente numa lista e o accept
// seleciona uma delas.
// #test: 
// Pra começar, vamos deixar apenas uma pendente
// e o accept() selecionara ela.
// #todo
// Temos que colocar os pedidos de conexão em uma fila.
// O tamanho dessa fila foi determinado pelo servidor
// com a chamada listen(). Mas podemos ter um tamanho padrão.
// Talvez tamanho 1 para começar.
// Link:
// Conectando o socket do processo alvo ao ponto de
// conexão do processo cliente.
// Conectando o socket do cliente ao ponto de conecção do
// processo servidor.
// Flags:
// State:
// Acionando as flags que indicam a conecção.
// Nesse momento poderíamos usar a flag SS_CONNECTING
// e a rotina accept() mudaria para SS_CONNECTED. 
// #bugbug
// Nao podemos mudar o estado do servidor,
// estamos apenas entrando na fila e implorando para nos conectarmos.
// Quem realizara a conexão sera o accept(), 
// pegando o cliente da fila de conexões pendentes.

// Linking:
// Connecting
    client_socket->link = (struct socket_d *) server_socket;
    server_socket->link = (struct socket_d *) client_socket;
// Flags:
// State
    client_socket->state = SS_CONNECTING;
    server_socket->state = SS_CONNECTING;
// Magic signature
    client_socket->magic_string[0] = 'C';
    client_socket->magic_string[1] = 0; 

//
// Backlog
//

// #todo
// Precisamos de uma lista de conexões pendentes.
// O cliente invocou a conexão apenas uma vez
// e precisa usar o servidor varias vezes
// #obs: 
// Isso funcionou. Vamos tentar com lista.
// #obs: 
// Algumas implementacões usam lista encadeada de conexões pendentes. 
// 'server_socket->iconn'
// #bugbug: 
// Essa lista fica na estrutura de socket so servidor, 
// dessa forma o servidor pode ter mais de uma socket?

    //server_socket->pending_client_count++;
    //if(server_socket->pending_client_count >= server_socket->backlog_max )
    //    return ECONNREFUSED;

// Circula
// #bugbug:
// Actually we're gonna reject the new connections when the queue is full.

    int BacklogTail = 0;

    server_socket->pending_client_count++;
    if (server_socket->pending_client_count >= server_socket->backlog_max)
    {
        server_socket->pending_client_count = 0;
    }
    BacklogTail = server_socket->pending_client_count;

// coloca na fila.
// Coloca o ponteiro para estrutura de socket
// na fila de conexões pendentes na estrutura do servidor.
// Isso será usado pelo accept() para encontrar
// a estrutura do socket do cliente.
    server_socket->pending_client_endpoints[BacklogTail] = 
        (unsigned long) client_socket;

// #
// O cliente está esperando que sua conexão seja aceita pelo servidor.

    // #debug
    //debug_print("sys_connect: Pending connection\n");

    // #debug
    //if (Verbose==TRUE){
    //    printk("sys_connect: Pending connection\n");
    //}

    // #debug breakpoint
    if (Verbose == TRUE)
    {
        printk("__connect_af_gramado: Breakpoint\n");
        //die();
        while (1){
            asm (" cli ");
            asm (" hlt ");
        };
    }

    return 0;  // OK

fail:
    debug_print("__connect_af_gramado: fail\n");
    printk     ("__connect_af_gramado: fail\n");
    return (int) -1;
}


// ============================================================
// __connect_inet_local()
// Handle AF_INET connections to local servers.
// This worker is used when the destination IP is loopback (127.0.0.1)
// AND the destination port is one of the canonical local service ports
// (__PORTS_DISPLAY_SERVER, __PORTS_NETWORK_SERVER).
// Called by sys_connect() via __connect_inet().
// ============================================================
// Client connects using AF_INET, but inside local
// probably localhost and LAN.
static int 
__connect_inet_local ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags )
{
    // Client process and server process
    struct te_d *cProcess;
    struct te_d *sProcess;
    pid_t target_pid = (-1);  //fail

    // Client socket and server socket
    struct socket_d *client_socket;
    struct socket_d *server_socket;
    int client_socket_fd = -1;

    // File
    struct file_d *f;

    struct sockaddr_in *addr_in;  // Address style in the case of AF_INET

    // Target IP: the remote peer you want to connect to.
    unsigned int target_ip_int = 0;
    unsigned short target_port_short = 0;

    unsigned long Flags = connection_flags;

    register int i=0;
    int Verbose = FALSE;  //TRUE;

    do_credits_by_tid( lapic_info[0].current_tid );

    // Get PID for the current process for a given core.
    // IN: core id

    pid_t current_process = (pid_t) get_current_process(0);
    if (Verbose == TRUE){
        printk ("__connect_inet_local: Client's pid {%d}\n", current_process);
    }

// Client fd.
// client_socket_fd é um soquete de quem quer se conectar.
// O addr indica o alvo.
    client_socket_fd = sockfd;
    if (Verbose == TRUE){
        printk ("__connect_inet_local: Client's socket id {%d}\n", sockfd );
    }
    if ( client_socket_fd < 0 || client_socket_fd >= OPEN_MAX ){
        debug_print ("__connect_inet_local: client_socket_fd\n");
        printk      ("__connect_inet_local: client_socket_fd\n");
        return (int) (-EINVAL);
    }

// addr
// Usando a estrutura que nos foi passada.
    if ((void *) addr == NULL){
        printk ("__connect_inet_local: addr\n");
        return (int) (-EINVAL);
    }

//  ==============

// Getting the target PID.
// #todo:
// Devemos obter o número do processo alvo dado um endereço.
// O tipo de endereço depende do tipo de domínio (família).

// Tente inet, ao menos que mudemos de planos por 
// encontrarmos af_gramado, af_unix ou af_local.

// #importante
// opções de domínio se o endereço é no estilo unix. 
// >>> sockaddr

// ------------------------------------------
// This routine do not accept local domains.
// It is only for AF_INET.
    switch (addr->sa_family){
    case AF_UNIX:     goto fail;  break;
    case AF_GRAMADO:  goto fail;  break;
    };

// ------------------------------------------
// Not Local
// Tentaremos com outro formato de endereço, o sockaddr_in.
// Agora trabalharemos com IP e PORTA. Não mais com string
// ou pathname.
// Vamos pegar o pid do processo associado a determinada porta.
// Para a família AF_INET.

// The client is trying to cennect to the localhost
// in the AF_INET domain.
    int in_localhost = FALSE;


// #ps: addr_in is the right structure for AF_INET. 
    //addr_in = (struct sockaddr *) addr;
    addr_in = addr;

    // Opções de domínio se o endereço é no estilo internet.
    switch (addr_in->sin_family){

    case AF_INET:
    // Trabalhando com ip e porta.
    // Estamos usando inet em conexão local.
    // Então precisamos usar localhost como ip.

        debug_print("__connect_inet_local: AF_INET\n");
        //#debug
        //printk("sys_connect: AF_INET port {%d}\n", addr_in->sin_port);

        // Copy IP:PORT
        target_ip_int     = ntohl(addr_in->sin_addr.s_addr);  // convert to host order
        target_port_short = ntohs(addr_in->sin_port);         // convert to host order

        // Yes
        // Check the port.
        // This way we know what is the server's pid.

        // 21 - FTP
        if (target_port_short == 21){
            printk("__connect_inet_local: [21] FTP #todo\n");
            goto fail;
        }

        // 23 - Telnet
        if (target_port_short == 23){
            printk("__connect_inet_local: [23] Telnet #todo\n");
            goto fail;
        }

        // 67 - DHCP
        if (target_port_short == 67){
            printk("__connect_inet_local: [67] DHCP #todo\n");
            goto fail;
        }

        // 80 - HTTP ;; Not allowed for now
        if (target_port_short == 80){
            printk("__connect_inet_local: [80] HTTP #test\n");
            //break;
            goto fail;
        }

        // 443 - HTTPS 
        if (target_port_short == 443){
            printk("__connect_inet_local: [443] HTTPS #todo\n");
            goto fail;
        }

        // 4040 - Display server
        // If the port is Display Server,
        // let's use the PID associated with this port.
        // #important:
        // Now we are comparing between two values in HOST byte order.
        if (target_port_short == __PORTS_DISPLAY_SERVER)
        {
            // Get target PID!
            target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_DS);
            if (Verbose == TRUE)
            {
                printk("__connect_inet_local: [AF_INET] Connecting to the Display Server\n");
                printk("__connect_inet_local: IP {%x}\n",   target_ip_int );
                printk("__connect_inet_local: PORT {%d}\n", target_port_short );
                //#debug
                //while(1){}
            }
            break;
        }

        // 4041 - Network server
        // Se a porta for , então usaremos o pid do Network Server.
        // #important:
        // Now we are comparing between two values in HOST byte order.
        if (target_port_short == __PORTS_NETWORK_SERVER)
        {
            // Get target PID!
            target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_NS);
            if (Verbose==TRUE)
            {
                printk("__connect_inet_local: [AF_INET] Connecting to the Network Server\n");
                printk("__connect_inet_local: IP {%x}\n",   target_ip_int );
                printk("__connect_inet_local: PORT {%d}\n", target_port_short );
                //#debug
                //while(1){}
            }
            break;
        }

        // 4042 - PORTS_FS #todo
        // Web server #todo
        // FTP server #todo
        // Telnet server #todo

        // #debug
        printk("__connect_inet_local: Invalid port number {%d}\n",
            target_port_short );

        debug_print("__connect_inet_local: Invalid port number\n");

        goto fail;
        break;

        //...

    default:
        debug_print("__connect_inet_local: domain not supported\n");
        printk("__connect_inet_local: [FAIL] Family not supported {%d}\n",
            addr_in->sin_family );
        goto fail;
        break;

    };  // switch

// ====================================================================
// Check
// Have a valid target_pid ?

//__go:

// #bugbug
// Daqui pra frente só faz sentido continuarmos
// se a intenção do cliente foi conectar-se com um servidor
// dentro do localhost.

//
// == Client process =============================
//

// Vamos obter o arquivo do tipo soquete que pertence ao sender
    if (current_process<0 || current_process >= PROCESS_COUNT_MAX)
    {
        printk ("__connect_inet_local: current_process\n");
        goto fail;
    }
// Client process.
// sender's process structure.
    cProcess = (struct te_d *) teList[current_process];
    if ((void *) cProcess == NULL){
        debug_print("__connect_inet_local: cProcess fail\n");
        printk     ("__connect_inet_local: cProcess fail\n");
        goto fail;
    }

// #todo
// Check structure validation
    // if (cProcess->magic ...

// The client's socket file.
// #bugbug
// Estamos pegando o arquivo de socket do cliente
// Então estamos presumindo que é uma conexão local.
// Se o servidor fechar esse arquivo, então
// o cliente será incapaz de enviar mensagens?
// Por isso no momento do accept devemos
// criar um arquivo para o cliente. Que poderá ser fechado
// pelo sevidor para encessar a conexão ... até que
// o cliente se conecte novamente.
// #importante: Mas para isso o cliente precisa
// possuir um arquivo de socket ainda válido.
// O servidor não pode fechar o arquivo de socket do cliente remoto.
// E também não devemos permitir que isso aconteça na conexão local.

    f = (file *) cProcess->Objects[client_socket_fd];
    if ((void *) f == NULL){
        printk("__connect_inet_local: [FAIL] f. The client's socket\n");
        goto fail;
    }

// Is this file a socket object?
    int IsSocketObject = -1;
    IsSocketObject = (int) is_socket((file *) f);
    if (IsSocketObject != TRUE){
        return (int) (-ENOTSOCK);
    }

// This file doesn't accept connections.
// #todo:
// This way we can reject connections before the server binds with an address.

    if (f->sync.can_connect != TRUE){
        printk("__connect_inet_local: [PERMISSION FAIL] Client doesn't accept connections.\n");
        goto fail;
    }

// Client socket structure
// Socket structure in the sender's file.
// Pega a estrutura de socket associada ao arquivo.

    client_socket = (struct socket_d *) f->socket;
    if ((void *) client_socket == NULL){
        printk("__connect_inet_local: [FAIL] client_socket\n");
        goto fail;
    }

    client_socket->is_client_connecting_with_remote_server = FALSE;
    client_socket->connection_type = 1;  // LOCAL

// #ps: 
// For now this it the only valid state.
// #todo:
// We need to handle some other states here too.

    if (client_socket->state != SS_UNCONNECTED) 
    {
        printk("__connect_inet_local: Client socket is not SS_UNCONNECTED\n");
        goto fail;
    }

// #test
// Assign a port number to the client socket.
// #todo #bugbug We gotta work on this routine.
    __new_client_port_number++;
    client_socket->port = (unsigned short) __new_client_port_number;

//
// Is it remote
//

// In this case we do not handle the server process
// Not allowed for now
    //if (target_port_short == 80)
        //goto remote_go;

// ---------------------------------------------------    
// Server process
// #todo
// O arquivo de socket do cliente 
// precisa ter um fd no processo servidor.
// target pid.
// O pid do processo servidor.
// Pegamos o target_pid logo acima na porta solicitada.

    if (target_pid<0 || target_pid >= PROCESS_COUNT_MAX)
    {
        debug_print("__connect_inet_local: target_pid\n");
        printk     ("__connect_inet_local: target_pid\n");
        goto fail;
    }

// The server's process structure.
// O processo cliente chamou essa função e
// então pegaremos agora o processo alvo, que é um servidor.

    sProcess = (struct te_d *) teList[target_pid];
    if ((void *) sProcess == NULL){
        debug_print("__connect_inet_local: sProcess fail\n");
        printk     ("__connect_inet_local: sProcess fail\n");
        goto fail;
    }

// #todo
// Checar a validade da estrutura de processo.
    // if ( sProcess->magic != ...

// Procurando um slot livre na lista de objetos abertos
// presente na estrutura do processo servidor.

    register int __slot = -1;  // Default is fail.
    for (i=3; i<31; i++)
    {
        if (sProcess->Objects[i] == 0)
        {
            __slot = (int) i;
            goto __OK_new_slot;
        }
    };

    // No more slots
    panic("__connect_inet_local: [FIXME] We need a slot in the server\n");

// ok
__OK_new_slot:

    if (__slot == -1){
        printk("__connect_inet_local: No empty slot\n");
        goto fail;
    }

// Esse é o socket do processo servidor.
// Sim, porque é o cliente que está tentando se conectar.
// Dessa forma o alvo é o servidor.

// #important:
// Rhe socket for the server for now is already valid only for two ports.
// 4040 and 4041

// --------------------------------------------------
// #ps
// Continue in the case we are connectiong with 
// well known server in localhost.

    server_socket = (struct socket_d *) sProcess->priv;
    if ((void *) server_socket == NULL){
        printk ("__connect_inet_local: [FAIL] server_socket\n");
        goto fail;
    }

// Salvando o fd do socket do cliente.
    server_socket->clientfd_on_server = __slot;
    client_socket->clientfd_on_server = __slot;

// #todo
// Temos que rever as coisas por aqui. kkk
// incluimos como objeto do servidor o ponteiro para 
// o arquivo que representa o socket do cliente.
// O arquivo de socket do cliente agora tem um fd
// no processo servidor.
// Nossa intenção aqui é usar um dos slots livres
// encontrado em p->Objects[], mas por enquanto estamos usando 
// apenas o slot número 31.

// :: The free slot we found before.
    //sProcess->Objects[__slot] = (unsigned long) f;
// :: The standard fd used by the servers in GramadoOS.
    sProcess->Objects[31] = (unsigned long) f;

// Connecting!
// #bugbug
// connect() eh chamado somente uma vez pelo cliente.
// A conexao deve ficar pendente numa lista e o accept
// seleciona uma delas.
// #test: 
// Pra começar, vamos deixar apenas uma pendente
// e o accept() selecionara ela.
// #todo
// Temos que colocar os pedidos de conexão em uma fila.
// O tamanho dessa fila foi determinado pelo servidor
// com a chamada listen(). Mas podemos ter um tamanho padrão.
// Talvez tamanho 1 para começar.
// Link:
// Conectando o socket do processo alvo ao ponto de
// conexão do processo cliente.
// Conectando o socket do cliente ao ponto de conecção do
// processo servidor.
// Flags:
// State:
// Acionando as flags que indicam a conecção.
// Nesse momento poderíamos usar a flag SS_CONNECTING
// e a rotina accept() mudaria para SS_CONNECTED. 
// #bugbug
// Nao podemos mudar o estado do servidor,
// estamos apenas entrando na fila e implorando para nos conectarmos.
// Quem realizara a conexão sera o accept(), 
// pegando o cliente da fila de conexões pendentes.

// #important:
// Rhe socket for the server for now is already valid only for two ports.
// 4040 and 4041

// Linking:
// Connecting
    client_socket->link = (struct socket_d *) server_socket;
    server_socket->link = (struct socket_d *) client_socket;
// Flags:
// State
    client_socket->state = SS_CONNECTING;
    server_socket->state = SS_CONNECTING;
// Magic signature
    client_socket->magic_string[0] = 'C';
    client_socket->magic_string[1] = 0; 

//
// Backlog
//

// #todo
// Precisamos de uma lista de conexões pendentes.
// O cliente invocou a conexão apenas uma vez
// e precisa usar o servidor varias vezes
// #obs: 
// Isso funcionou. Vamos tentar com lista.
// #obs: 
// Algumas implementacões usam lista encadeada de conexões pendentes. 
// 'server_socket->iconn'
// #bugbug: 
// Essa lista fica na estrutura de socket so servidor, 
// dessa forma o servidor pode ter mais de uma socket?

    //server_socket->pending_client_count++;
    //if(server_socket->pending_client_count >= server_socket->backlog_max )
    //    return ECONNREFUSED;

// Circula
// #bugbug:
// Actually we're gonna reject the new connections when the queue is full.

// The insertion index
    int BacklogTail = 0;

    server_socket->pending_client_count++;
    if (server_socket->pending_client_count >= server_socket->backlog_max)
    {
        server_socket->pending_client_count = 0;
    }
    BacklogTail = server_socket->pending_client_count;

// coloca na fila.
// Coloca o ponteiro para estrutura de socket
// na fila de conexões pendentes na estrutura do servidor.
// Isso será usado pelo accept() para encontrar
// a estrutura do socket do cliente.
    server_socket->pending_client_endpoints[BacklogTail] = 
        (unsigned long) client_socket;

// #
// O cliente está esperando que sua conexão seja aceita pelo servidor.

    // #debug
    //debug_print("sys_connect: Pending connection\n");

    // #debug
    //if (Verbose==TRUE){
    //    printk("sys_connect: Pending connection\n");
    //}

    /*
    // #debug breakpoint
    if (Verbose == TRUE)
    {
        printk("__connect_inet_local: Breakpoint\n");
        // die();
        while (1){
            asm (" cli ");
            asm (" hlt ");
        };
    }
    */

    // printk("__connect_inet_local: Done\n");

    return 0;  // OK

fail:
    debug_print("__connect_inet_local: fail\n");
    printk     ("__connect_inet_local: fail\n");
    return (int) -1;
}


// ============================================================
// __connect_inet_remote()
// Handle AF_INET connections to remote servers.
// This worker is used when the destination IP/port does not match
// the local loopback + canonical ports.
// It allocates an ephemeral client port, builds a TCP SYN,
// and initiates the handshake with the remote host.
// Called by sys_connect() via __connect_inet().

/*
 * __connect_inet_remote:
 * ------------------------------------------------------------
 * AF_INET connect worker.
 *
 * Responsibilities:
 * 1) Inject the file pointer into p->Objects[]:
 *    - Binds the socket fd to the process’s fd table.
 *
 * 2) Inject the client’s socket structure pointer into
 *    sk->pending_client_endpoints[]:
 *    - Registers the socket in kernel connection tracking.
 *
  * This way, anyone reading the function knows immediately:
 * + p->Objects[] is about the process’s view (fd table).
 * + sk->pending_client_endpoints[] is about the kernel’s view 
 *   (connection tracking).
 *
 * 3) For remote servers:
 *    - Extract remote IP/port from sockaddr_in.
 *    - Save into socket_d (ip_ipv4, port).
 *    - Initiate protocol handshake:
 *        * TCP → send SYN via network_send_tcp(), wait for SYN/ACK.
 *        * UDP → send initial datagram via network_send_udp().
 *    - Update socket state (SS_CONNECTING → SS_CONNECTED).
 *
 * This bridges userland fd tables with kernel socket state,
 * and, in the remote case, drives the actual network handshake
 * to establish communication with external servers.
 */

/*
 * __connect_inet_remote:
 * ------------------------------------------------------------
 * AF_INET connect worker (client side).
 *
 * Responsibilities:
 * 1) Save remote IP/port into socket_d.
 * 2) Allocate local ephemeral port and update socket_d.
 * 3) Send initial SYN via network_send_tcp().
 * 4) Block the calling process until handshake completes.
 *    - On SYN/ACK: update state, send final ACK.
 *    - On timeout/RST: fail with error.
 * 5) Transition socket state to SS_CONNECTED and return success.
 *
 * This mirrors the handshake logic already implemented for
 * server-side connections, but applied to client-side sys_connect().
 */


// connect() is used on the client side, and 
// assigns a free local port number to a socket. 
// In case of a TCP socket, it causes an attempt 
// to establish a new TCP connection.
// connect.
// Em nosso exemplo o cliente quer se conectar com o servidor.
// Conectando a um servidor dado um endereço.
// O endereço pode vir em formatos diferentes dependendo
// do domínio indicado na estrutura.
// #atenção
// O servidor poderá estar conectado a vários clientes,
// mas estará ouvindo a apenas um por vez. Ou precisaremos 
// de instâncias.
// #todo
// O socket do cliente precisa ter um fd no processo servidor.
// #??
// connect() eh chamado uma vez pelo cliente quando
// ele inicializa. Essa chamada fornece o fd do cliente.
// O servidor quando chama accept() seleciona um dos
// clientes conectados. 
// O servidor nao pode simplesmente aceitar
// o ultimo que se conectou.
// #bugbug: lembrando que nosso write copia de um socket para outro.
// Entao podemoriamos deixar as conexoes pendentes e selecionarmos
// somete uma a cada accept. 
// O write ira falhar se nao estiver conectado?
/*
 The backlog argument defines the maximum length to which the queue of
 pending connections for sockfd may grow.  If a connection request
 arrives when the queue is full, the client may receive an error with
 an indication of ECONNREFUSED or, if the underlying protocol supports
 retransmission, the request may be ignored so that a later reattempt
 at connection succeed.
*/
// At this moment, the operating system has to assign a not used 
// random port number to the client.
// IN: client fd, address, address len
// OUT: 0=ok <0=fail

// #todo:
// ok, this method of connection has been useful when server and client 
// are running on ring3 of my hobby os. Good. But now we are trying 
// to expand it to the scenario where the client is a 
// ring3 process in my hobby os and the server is a remote server.
// For AF_INET sockets, the connect path has to do more than 
// just inject pointers; it now has to actually 
// drive the network handshake out onto the wire.

// Validate parameters:
// + Ensure sockfd is valid.
// + Ensure addr points to a valid struct sockaddr_in.
// + Ensure addrlen matches the expected size.

// Return:
// + On success, return 0.
// + On failure, return -1 or 
//   an error code (-ECONNREFUSED, -EINVAL, etc.).

// Worker, called by sys_connect().
// AF_INET domains only.

static int 
__connect_inet_remote ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags )
{
    // Client process and server process
    struct te_d *cProcess;
    struct te_d *sProcess;
    pid_t target_pid = (-1);  //fail

    // Client socket and server socket
    struct socket_d *client_socket;
    struct socket_d *server_socket;
    int client_socket_fd = -1;

    // File
    struct file_d *fp_client;

    struct sockaddr_in *addr_in;  // Address style in the case of AF_INET

    // Target IP: the remote peer you want to connect to.
    unsigned int target_ip_int = 0;
    unsigned short target_port_short = 0;

    unsigned long Flags = connection_flags;

    register int i=0;
    int Verbose = FALSE;

    int IsValidPort = FALSE;

    do_credits_by_tid( lapic_info[0].current_tid );

    // Get PID for the current process for a given core.
    // IN: core id

    pid_t current_process = (pid_t) get_current_process(0);
    if (Verbose == TRUE){
        printk ("__connect_inet_remote: Client's pid {%d}\n", current_process);
    }

// Client fd.
// client_socket_fd é um soquete de quem quer se conectar.
// O addr indica o alvo.
    client_socket_fd = sockfd;
    if (Verbose == TRUE){
        printk ("__connect_inet_remote: Client's socket id {%d}\n", sockfd );
    }
    if ( client_socket_fd < 0 || client_socket_fd >= OPEN_MAX ){
        debug_print ("__connect_inet_remote: client_socket_fd\n");
        printk      ("__connect_inet_remote: client_socket_fd\n");
        return (int) (-EINVAL);
    }

// addr
// Usando a estrutura que nos foi passada.
    if ((void *) addr == NULL){
        printk ("__connect_inet_remote: addr\n");
        return (int) (-EINVAL);
    }

//  ==============

// Getting the target PID.
// #todo:
// Devemos obter o número do processo alvo dado um endereço.
// O tipo de endereço depende do tipo de domínio (família).

// Tente inet, ao menos que mudemos de planos por 
// encontrarmos af_gramado, af_unix ou af_local.

// #importante
// opções de domínio se o endereço é no estilo unix. 
// >>> sockaddr

// ------------------------------------------
// This routine do not accept local domains.
// It is only for AF_INET.
    switch (addr->sa_family){
    case AF_UNIX:     goto fail;  break;
    case AF_GRAMADO:  goto fail;  break;
    };

// ------------------------------------------
// Not Local
// Tentaremos com outro formato de endereço, o sockaddr_in.
// Agora trabalharemos com IP e PORTA. Não mais com string
// ou pathname.
// Vamos pegar o pid do processo associado a determinada porta.
// Para a família AF_INET.

// The client is trying to cennect to the localhost
// in the AF_INET domain.
    int in_localhost = FALSE;


// #ps: addr_in is the right structure for AF_INET. 
    //addr_in = (struct sockaddr *) addr;
    addr_in = addr;

    // Opções de domínio se o endereço é no estilo internet.
    switch (addr_in->sin_family){

    case AF_INET:
    // Trabalhando com ip e porta.
    // Estamos usando inet em conexão local.
    // Então precisamos usar localhost como ip.

        debug_print("__connect_inet_remote: AF_INET\n");
        //#debug
        //printk("sys_connect: AF_INET port {%d}\n", addr_in->sin_port);

        // Copy IP:PORT
        target_ip_int     = ntohl(addr_in->sin_addr.s_addr);  // convert to host order
        target_port_short = ntohs(addr_in->sin_port);         // convert to host order

        // Yes
        // Check the port.
        // This way we know what is the server's pid.

        // 21 - FTP
        if (target_port_short == 21){
            printk("__connect_inet_remote: [21] FTP #todo\n");
            IsValidPort = TRUE;
            break;
        }

        // 23 - Telnet
        if (target_port_short == 23){
            printk("__connect_inet_remote: [23] Telnet #todo\n");
            IsValidPort = TRUE;
            break;
        }

        // 67 - DHCP
        if (target_port_short == 67){
            printk("__connect_inet_remote: [67] DHCP #todo\n");
            IsValidPort = TRUE;
            break;
        }

        // 80 - HTTP
        if (target_port_short == 80){
            printk("__connect_inet_remote: [80] HTTP #test\n");
            IsValidPort = TRUE;
            break;
        }

        // 443 - HTTPS 
        if (target_port_short == 443){
            printk("__connect_inet_remote: [443] HTTPS #todo\n");
            IsValidPort = TRUE;
            break;
        }

        // 4040 - Display server
        // If the port is Display Server,
        // let's use the PID associated with this port.
        // #important:
        // Now we are comparing between two values in HOST byte order.
        if (target_port_short == __PORTS_DISPLAY_SERVER)
        {
            /*
            // Get target PID!
            target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_DS);
            if (Verbose == TRUE)
            {
                printk("__connect_inet_remote: [AF_INET] Connecting to the Display Server\n");
                printk("__connect_inet_remote: IP {%x}\n",   target_ip_int );
                printk("__connect_inet_remote: PORT {%d}\n", target_port_short );
                //#debug
                //while(1){}
            }
            break;
            */
            IsValidPort = TRUE;
            break;
        }

        // 4041 - Network server
        // Se a porta for , então usaremos o pid do Network Server.
        // #important:
        // Now we are comparing between two values in HOST byte order.
        if (target_port_short == __PORTS_NETWORK_SERVER)
        {
            /*
            // Get target PID!
            target_pid = (pid_t) socket_get_gramado_server_pid(GRAMADO_PORT_NS);
            if (Verbose==TRUE)
            {
                printk("__connect_inet_remote: [AF_INET] Connecting to the Network Server\n");
                printk("__connect_inet_remote: IP {%x}\n",   target_ip_int );
                printk("__connect_inet_remote: PORT {%d}\n", target_port_short );
                //#debug
                //while(1){}
            }
            break;
            */
            IsValidPort = TRUE;
            break;
        }

        // 4042 - PORTS_FS #todo
        // Web server #todo
        // FTP server #todo
        // Telnet server #todo

        // #debug
        printk("__connect_inet_remote: Other ports {%d}\n",
            target_port_short );

        IsValidPort = TRUE;
        break;
        //goto fail;
        //break;

        //...

    default:
        debug_print("__connect_inet_remote: domain not supported\n");
        printk("__connect_inet_remote: [FAIL] Family not supported {%d}\n",
            addr_in->sin_family );
        goto fail;
        break;

    };  // switch

// ====================================================================
// Check
// Have a valid target_pid ?

//__go:

// #bugbug
// Daqui pra frente só faz sentido continuarmos
// se a intenção do cliente foi conectar-se com um servidor
// dentro do localhost.

    /*
    // #todo: This is temporary
    if (in_localhost != TRUE)
    {
        printk ("__connect_inet_remote: #todo Trying to connect to another machine\n");
        goto fail;
    }
    */

//
// == Client process =============================
//

// Vamos obter o arquivo do tipo soquete que pertence ao sender
    if (current_process<0 || current_process >= PROCESS_COUNT_MAX)
    {
        printk ("__connect_inet_remote: current_process\n");
        goto fail;
    }
// Client process.
// sender's process structure.
    cProcess = (struct te_d *) teList[current_process];
    if ((void *) cProcess == NULL){
        debug_print("__connect_inet_remote: cProcess fail\n");
        printk     ("__connect_inet_remote: cProcess fail\n");
        goto fail;
    }

// #todo
// Check structure validation
    // if (cProcess->magic ...

// The client's socket file.
// #bugbug
// Estamos pegando o arquivo de socket do cliente
// Então estamos presumindo que é uma conexão local.
// Se o servidor fechar esse arquivo, então
// o cliente será incapaz de enviar mensagens?
// Por isso no momento do accept devemos
// criar um arquivo para o cliente. Que poderá ser fechado
// pelo sevidor para encessar a conexão ... até que
// o cliente se conecte novamente.
// #importante: Mas para isso o cliente precisa
// possuir um arquivo de socket ainda válido.
// O servidor não pode fechar o arquivo de socket do cliente remoto.
// E também não devemos permitir que isso aconteça na conexão local.

    fp_client = (file *) cProcess->Objects[client_socket_fd];
    if ((void *) fp_client == NULL){
        printk("__connect_inet_remote: [FAIL] fp_client. The client's socket\n");
        goto fail;
    }

// Is this file a socket object?
    int IsSocketObject = -1;
    IsSocketObject = (int) is_socket((file *) fp_client);
    if (IsSocketObject != TRUE){
        return (int) (-ENOTSOCK);
    }

// This file doesn't accept connections.
// #todo:
// This way we can reject connections before the server binds with an address.

    if (fp_client->sync.can_connect != TRUE){
        printk("__connect_inet_remote: [PERMISSION FAIL] Client doesn't accept connections.\n");
        goto fail;
    }

// Client socket structure
// Socket structure in the sender's file.
// Pega a estrutura de socket associada ao arquivo.

    client_socket = (struct socket_d *) fp_client->socket;
    if ((void *) client_socket == NULL){
        printk("__connect_inet_remote: [FAIL] client_socket\n");
        goto fail;
    }

    client_socket->is_client_connecting_with_remote_server = TRUE;
    client_socket->connection_type = 2;  // REMOTE

// #ps: 
// For now this it the only valid state.
// #todo:
// We need to handle some other states here too.

    if (client_socket->state != SS_UNCONNECTED){
        printk("__connect_inet_remote: [FAIL] client socket is not SS_UNCONNECTED\n");
        goto fail;
    }

// #test
// Assign a port number to the client socket.
// #todo #bugbug We gotta work on this routine.
    __new_client_port_number++;
    client_socket->port = (unsigned short) __new_client_port_number;

//
// Is it remote
//

// In this case we do not handle the server process
    if (IsValidPort == TRUE)
       goto remote_go;
    //if (target_port_short == 80)
        //goto remote_go;

// ---------------------------------------------------    
// Server process
// #todo
// O arquivo de socket do cliente 
// precisa ter um fd no processo servidor.
// target pid.
// O pid do processo servidor.
// Pegamos o target_pid logo acima na porta solicitada.

    if (target_pid<0 || target_pid >= PROCESS_COUNT_MAX)
    {
        debug_print("__connect_inet_remote: target_pid\n");
        printk     ("__connect_inet_remote: target_pid\n");
        goto fail;
    }

// The server's process structure.
// O processo cliente chamou essa função e
// então pegaremos agora o processo alvo, que é um servidor.

    sProcess = (struct te_d *) teList[target_pid];
    if ((void *) sProcess == NULL){
        debug_print("__connect_inet_remote: sProcess fail\n");
        printk     ("__connect_inet_remote: sProcess fail\n");
        goto fail;
    }

// #todo
// Checar a validade da estrutura de processo.
    // if ( sProcess->magic != ...

// Procurando um slot livre na lista de objetos abertos
// presente na estrutura do processo servidor.

    register int __slot = -1;  // Default is fail.
    for (i=3; i<31; i++)
    {
        if (sProcess->Objects[i] == 0)
        {
            __slot = (int) i;
            goto __OK_new_slot;
        }
    };

// #fail: 
// No more slots.
    panic("__connect_inet_remote: [FIXME] We need a slot in the server\n");

// ok
__OK_new_slot:

    if (__slot == -1){
        printk("__connect_inet_remote: No empty slot\n");
        goto fail;
    }

// Esse é o socket do processo servidor.
// Sim, porque é o cliente que está tentando se conectar.
// Dessa forma o alvo é o servidor.

// #important:
// Rhe socket for the server for now is already valid only for two ports.
// 4040 and 4041

// --------------------------------------------------
// #ps
// In the case the target is not our well know server,
// we need to connect to a remote server.
// Here we initialize the 3 step handshake sending a SYN
// and creating the connection structure.

    // #todo: This is a work in progress!

remote_go:

    if (target_port_short != __PORTS_DISPLAY_SERVER &&
        target_port_short != __PORTS_NETWORK_SERVER)
    {
        // --- Call the new worker at the end ---
        // #ps: Using the host order for ip and port.
        // IN: socket, ip, port.
        int __rv = 
        tcp_client_connect(
            client_socket, 
            target_ip_int, target_port_short );

        if (__rv < 0) {
            printk("__connect_inet_remote: tcp_client_connect failed\n");
            return __rv;
        }

        // Confirming. (redundant)
        // We ar still waiting for the syn_ack
        fp_client->sync.action = ACTION_CONNECTING;

        // Block until handshake completes (to be implemented)
        // wait_for_socket_state(s, SS_CONNECTED);

        return 0;   // OK for now
    }

// --------------------------------------------------
// #ps
// Continue in the case we are connectiong with 
// well known server in localhost.

    server_socket = (struct socket_d *) sProcess->priv;
    if ((void *) server_socket == NULL){
        printk ("__connect_inet_remote: [FAIL] server_socket\n");
        goto fail;
    }

// Salvando o fd do socket do cliente.
    server_socket->clientfd_on_server = __slot;
    client_socket->clientfd_on_server = __slot;

// #todo
// Temos que rever as coisas por aqui. kkk
// incluimos como objeto do servidor o ponteiro para 
// o arquivo que representa o socket do cliente.
// O arquivo de socket do cliente agora tem um fd
// no processo servidor.
// Nossa intenção aqui é usar um dos slots livres
// encontrado em p->Objects[], mas por enquanto estamos usando 
// apenas o slot número 31.

// :: The free slot we found before.
    //sProcess->Objects[__slot] = (unsigned long) f;
// :: The standard fd used by the servers in GramadoOS.
    sProcess->Objects[31] = (unsigned long) fp_client;

// Connecting!
// #bugbug
// connect() eh chamado somente uma vez pelo cliente.
// A conexao deve ficar pendente numa lista e o accept
// seleciona uma delas.
// #test: 
// Pra começar, vamos deixar apenas uma pendente
// e o accept() selecionara ela.
// #todo
// Temos que colocar os pedidos de conexão em uma fila.
// O tamanho dessa fila foi determinado pelo servidor
// com a chamada listen(). Mas podemos ter um tamanho padrão.
// Talvez tamanho 1 para começar.
// Link:
// Conectando o socket do processo alvo ao ponto de
// conexão do processo cliente.
// Conectando o socket do cliente ao ponto de conecção do
// processo servidor.
// Flags:
// State:
// Acionando as flags que indicam a conecção.
// Nesse momento poderíamos usar a flag SS_CONNECTING
// e a rotina accept() mudaria para SS_CONNECTED. 
// #bugbug
// Nao podemos mudar o estado do servidor,
// estamos apenas entrando na fila e implorando para nos conectarmos.
// Quem realizara a conexão sera o accept(), 
// pegando o cliente da fila de conexões pendentes.

// #important:
// Rhe socket for the server for now is already valid only for two ports.
// 4040 and 4041

// Linking:
// Connecting
    client_socket->link = (struct socket_d *) server_socket;
    server_socket->link = (struct socket_d *) client_socket;
// Flags:
// State
    client_socket->state = SS_CONNECTING;
    server_socket->state = SS_CONNECTING;
// Magic signature
    client_socket->magic_string[0] = 'C';
    client_socket->magic_string[1] = 0; 

//
// Backlog
//

// #todo
// Precisamos de uma lista de conexões pendentes.
// O cliente invocou a conexão apenas uma vez
// e precisa usar o servidor varias vezes
// #obs: 
// Isso funcionou. Vamos tentar com lista.
// #obs: 
// Algumas implementacões usam lista encadeada de conexões pendentes. 
// 'server_socket->iconn'
// #bugbug: 
// Essa lista fica na estrutura de socket so servidor, 
// dessa forma o servidor pode ter mais de uma socket?

    //server_socket->pending_client_count++;
    //if(server_socket->pending_client_count >= server_socket->backlog_max )
    //    return ECONNREFUSED;

// Circula
// #bugbug:
// Actually we're gonna reject the new connections when the queue is full.

// The insertion index
    int BacklogTail = 0;

    server_socket->pending_client_count++;
    if (server_socket->pending_client_count >= server_socket->backlog_max)
    {
        server_socket->pending_client_count = 0;
    }
    BacklogTail = server_socket->pending_client_count;

// coloca na fila.
// Coloca o ponteiro para estrutura de socket
// na fila de conexões pendentes na estrutura do servidor.
// Isso será usado pelo accept() para encontrar
// a estrutura do socket do cliente.
    server_socket->pending_client_endpoints[BacklogTail] = 
        (unsigned long) client_socket;

// #
// O cliente está esperando que sua conexão seja aceita pelo servidor.

    // #debug
    //debug_print("sys_connect: Pending connection\n");

    // #debug
    //if (Verbose==TRUE){
    //    printk("sys_connect: Pending connection\n");
    //}

    // #debug breakpoint
    if (Verbose == TRUE)
    {
        printk("__connect_inet_remote: Breakpoint\n");
        // die();
        while (1){
            asm (" cli ");
            asm (" hlt ");
        };
    }

    return 0;  // OK

fail:
    debug_print("__connect_inet_remote: fail\n");
    printk     ("__connect_inet_remote: fail\n");
    return (int) -1;
}

// ============================================================
// __connect_inet()
// Dispatcher for AF_INET connections.
// Decides whether to route the connection to __connect_inet_local()
// or __connect_inet_remote() based on the destination IP and port.
// Called directly by sys_connect() when addr->sa_family == AF_INET.
// ============================================================
// Connect using AF_INET.
// We have two options. One for local server and 
// another one for remote servers.
static int __connect_inet(
    int sockfd,
    const struct sockaddr *addr,
    socklen_t addrlen,
    unsigned long connection_flags)
{
    struct sockaddr_in *in_addr = (struct sockaddr_in *) addr;

    // printk("__connect_inet:\n");

    // Sanity check
    if (!in_addr)
        return -EINVAL;
    if (in_addr->sin_family != AF_INET)
        return -EINVAL;

    unsigned int   target_ip_int     = ntohl(in_addr->sin_addr.s_addr);  // convert to host order
    unsigned short target_port_short = ntohs(in_addr->sin_port);         // convert to host order

    int IsCanonicalLocalPort = FALSE;
    if (target_port_short == __PORTS_DISPLAY_SERVER){
        IsCanonicalLocalPort = TRUE;
    }
    if (target_port_short == __PORTS_NETWORK_SERVER){
        IsCanonicalLocalPort = TRUE;
    }

// LOCAL: loopback ip and canonical ports
    if (IsCanonicalLocalPort == TRUE)
    {
        //printk("__connect_inet: It is canonical port\n");
        //unsigned int loopbackip_hostorder = 0x7F000001; // 127.0.0.1 in host order
        unsigned int loopbackip_hostorder = INADDR_LOOPBACK; 
        //printk("__connect_inet: target_ip_int=%x loopbackip_hostorder=%x raw_network=%x\n",
        //   target_ip_int,
        //   loopbackip_hostorder,
        //   in_addr->sin_addr.s_addr );
        // while(1){}

        if (target_ip_int == loopbackip_hostorder)
        {
            //printk("__connect_inet: forcing local connection\n");
            return __connect_inet_local(sockfd, addr, addrlen, connection_flags);
        }
    }

    //printk("__connect_inet: remote connection\n");

// REMOTE: remote peers
    return __connect_inet_remote(sockfd, addr, addrlen, connection_flags);
}


// Service 7001
// Purpose: 
// Establishes a connection between a client socket and 
// a remote server (IP + port).
// Dispatch: 
// It checks the socket’s family (AF_INET, AF_UNIX, AF_GRAMADO) and 
// then calls the appropriate worker (__connect_inet_remote, __connect_af_gramado, etc.).

// #warning
// We can have two types of address.
// One for local and another one for inet.

int 
sys_connect ( 
    int sockfd, 
    const struct sockaddr *addr,
    socklen_t addrlen )
{
    //unsigned long *limit_address = (unsigned long *) FLOWERTHREAD_BASE;

// Parameters:

    if (sockfd < 0 || sockfd >= OPEN_MAX)
    {
        debug_print("sys_connect: sockfd\n");
        printk     ("sys_connect: sockfd\n");
        return (int) (-EBADF);
    }

// Invalid address
    if ((void *) addr == NULL){
        printk ("sys_connect: addr\n");
        return (int) (-EINVAL);
    }
// Address validation.
// It needs to be a ring3 address.
// #todo: Check agains more limits.
// #bugbug: Comparison between pointer and integer.
    if (addr < FLOWERTHREAD_BASE){
        panic("sys_connect: addr is not ring3\n");
        //return (int) (-EINVAL);
    }

// Invalid lenght for the address
    if (addrlen == 0)
        return (int) (-EINVAL);

// -----------------------------
// Testing for local domains.
// If ti fails, try the inet domains.
    int IsAFGRAMADO = FALSE;

    switch (addr->sa_family)
    {
        //case AF_LOCAL:
        case AF_UNIX:
        case AF_GRAMADO:
            IsAFGRAMADO = TRUE;
            break;
        // When the family is AF_INET, the worker is __connect_inet_remote():
        //case AF_INET:
        default:
            IsAFGRAMADO = FALSE;
            break;
    };

// ----------------------------------
// We're gonna need the same parameters
// in both cases.
// #test
// Ate o momento, todos os clientes em zz/omega2/apps/
// estao usando AF_INET e o IP e' localhost.
// #todo
// see: socket.h and in.h for the structures.

    // #todo: This is a test yet
    unsigned long ConnectionFlags = 0;

    // It is AF_GRAMADO family
    if (IsAFGRAMADO == TRUE){
        return (int) __connect_af_gramado(sockfd, addr, addrlen, ConnectionFlags);

    // It is NOT AF_GRAMADO family
    } else if (IsAFGRAMADO == FALSE){

        // if AF_INET
        return (int) __connect_inet(sockfd, addr, addrlen, ConnectionFlags);
    }; 

// Unexpected error
    return (int) -1;
}

//
// End
//

