// core.c
// #todo
