// kunistd.c
// Created by Fred Nora.

#include <kernel.h>


// 179 - Get file descriptor table size.
// See: kstdio.h and klimits2.h
int sys_getdtablesize(void){
    return (int) RLIMIT_NOFILE;
}

// execve:
// This is a work in progress.
int 
sys_execve ( 
    const char *path, 
    char *const argv[], 
    char *const envp[] )
{
    return -1;
}

long fpathconf(int fildes, int name)
{
    debug_print("fpathconf: [TODO]\n");
    return -1;
}

long pathconf(const char *pathname, int name)
{
    debug_print("pathconf: [TODO]\n");    
    return -1;
} 

// sys_gethostname:
// Get host name.
// pegando host name
// faremos igual fizemos com usuário.
// suporte a rotina da libc.
// #todo: How many bytes we can copy into the buffer.
// We need a parameter for that.
int sys_gethostname(char *ubuff)
{
    char *hostname_buffer = (char *) ubuff;
    int size=0;

// Parameters
// Invalid buffer. Bad address.
    if ((void*) ubuff == NULL){
        return (int) -EFAULT;
    }
// Estrutura default para informações sobre o host.
// see: host.h
    if ((void *) HostInfo == NULL){
        printk("sys_gethostname: HostInfo\n");
        goto fail;
    }

// #bugbug: We need another version of this funcion that
// uses kernel_strcpy_safe insted of strcpy

// Copy 64 bytes
    strcpy ( 
        hostname_buffer, 
        (const char *) HostInfo->__hostname );

    //kernel_strcpy_safe ( 
        //hostname_buffer, 
        //HostInfo->hostName_len,
        //(const char *) HostInfo->__hostname );

// Get the size
    size = (int) HostInfo->hostName_len;
    return (int) size;

fail:
    return (int) -1;
}

// sys_sethostname:
// Set host name.
// #todo
// configurando o hostname.
// do mesmo jeito que configuramos o username,
// só que em estruturas diferentes
int sys_sethostname(const char *new_hostname, size_t len)
{
// #todo: This operation needs permition

    size_t StringLen=0;
    size_t GivenLen = len;

// Parameters
    if ((void*) new_hostname == NULL){
        goto fail;
    }
    if (*new_hostname == 0){
        goto fail;
    }

    StringLen = (size_t) strlen(new_hostname);
    StringLen = (size_t) (StringLen + 1);

// Estrutura HostInfo em host.h 
// (network)
    if ((void *) HostInfo == NULL){
        printk("sys_sethostname: HostInfo\n");
        goto fail;
    }
    HostInfo->hostName_len = (size_t) StringLen;
    // ...

    // #bugbug
    // Probably it gotta be less than 64

    if (HostInfo->hostName_len <= 0)
        goto fail;

    if (HostInfo->hostName_len > 64)
    {
        // HostInfo->hostName_len = 64;

        // #provisory
        goto fail;
    }

// #bugbug: We need another version of this funcion that
// uses kernel_strcpy_safe insted of strcpy

// Copy 64 bytes
    strcpy ( 
        HostInfo->__hostname, 
        (const char *) new_hostname );

    //kernel_strcpy_safe ( 
        //HostInfo->__hostname, 
        // HostInfo->hostName_len,
        //(const char *) new_hostname );

    return 0;

fail:
    return (int) -1;
}

// sys_lseek - reposition read/write file offset
// See:
// https://man7.org/linux/man-pages/man2/lseek.2.html
// #todo:
// IN: ??
// OUT: ??
off_t sys_lseek(int fd, off_t offset, int whence)
{
    file *f;
    struct te_d *p;
    pid_t current_process = -1;

    // #debug
    // debug_print("sys_lseek: [WORK IN PROGRESS]\n");

    if (fd<0 || fd >= 32){
        return (off_t) (-EBADF);
    }

//#todo
    //if(offset<0)
        //return (off_t) (-EINVAL);

    if (whence<0){
        return (off_t) -EINVAL;
    }

// pid

    // Get PID for the current process for a given core.
    // IN: core id

    current_process = (pid_t) get_current_process(0);

    if (current_process<0 || 
        current_process >= PROCESS_COUNT_MAX)
    {
        goto fail;
    }

// Process structure
    p = (struct te_d *) teList[current_process];
    if ((void *) p == NULL){
        debug_print("sys_lseek: p\n");
        goto fail;
    }
    if (p->magic != 1234){
        goto fail;
    }

// File
    f = (file *) p->Objects[fd];
    if ((void *) f == NULL){
        debug_print("sys_lseek: f\n");
        return -1;  // (off_t) (-EBADF); 
    }
    if (f->magic != 1234){
        return -1;  // (off_t) (-EBADF);
    }

// #todo
// Check if it is a pipe, socket or fifo.
// '-ESPIPE' fd is associated with a pipe, socket, or FIFO.

// fseek
// See: kstdio.c
    k_fseek( (file *) f, (long) offset, (int) whence );

    if (f->_p < f->_base)
    {
        // #debug
        panic("sys_lseek: #fixme f->_p < f->_base\n");
    }

// Final result.
    off_t FinalResult = (off_t) (f->_p - f->_base);
    return (off_t) FinalResult;

fail:
    return (off_t) -1;
}

//
// End
//

