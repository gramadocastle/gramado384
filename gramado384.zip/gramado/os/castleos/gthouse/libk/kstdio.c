// kstdio.c
// unix-like i/o support.
// Created by Fred Nora.

#include <kernel.h>

// The following should be enough for 32 bit int.
#define PRINT_BUF_LEN  12

//
// File pointers.
//

// Global list of files.
unsigned long file_table[NUMBER_OF_FILES];

struct file_table_info_d  FileTableInfo;

// Standard stream.
// Initialized by kstdio_initialize() in kstdio.c
file *stdin;
file *stdout;
file *stderr;
int kstdio_standard_streams_initialized=FALSE;

// VFS
// Not initialized yet.
file *vfs_fp;

// Rootdir for bootvolume and systemvolume.
// Initialized by fsInit() in fs.c
file *volume1_rootdir_fp;
file *volume2_rootdir_fp;

//...

// Global list of pipes.
unsigned long pipeList[NUMBER_OF_PIPES];

// 0
//Pipe para a rotina execve particular 
//usada no no init do ambiente Gramado Core.
file *pipe_gramadocore_init_execve;

// 1
//Pipe usado pela rotina execve.
file *pipe_execve;

int g_inputmode=0;

// The prompt[] support for input() and standard streams.
char prompt[PROMPT_SIZE];      //buffer para stdin
char prompt_out[PROMPT_SIZE];  //buffer para stdout
char prompt_err[PROMPT_SIZE];  //buffer para strerr
unsigned long prompt_pos=0;
unsigned long prompt_max=0; 
unsigned long prompt_status=0;

// Let's manage some stuff the happens in kstdio
struct kstdio_info_d  kstdio_info;

// Global sync stuff.
// see: kstdio.h
unsigned long syncList[SYNC_COUNT_MAX];

//
// =========================================================
//

static void __clear_prompt_buffers(void);
static void __initialize_file_table(void);
static void __initialize_inode_table(void);
static void __initialize_stdin(void);
static void __initialize_stdout(void);
static void __initialize_stderr(void);
static char *_vsputs_r(char *dest, char *src);

//
// =========================================================
//

// Feed stdin.
// ASCII Codes (0x00~0x7F)
// Extended ASCII Codes (0x80~0xFF)
int kstdio_feed_stdin(int ch)
{
    char Data = (char) (ch & 0xFF);
    char ch_buffer[2];
    int wbytes = 0;

// Parameter:
    //if (ch < 0)
        //return EOF;

// stdin validation
    if ((void*) stdin == NULL){
        goto fail;
    }
    if (stdin->used != TRUE){
        goto fail;
    }
    if (stdin->magic != 1234){
        goto fail;
    }

// #bugbug
// We're not respecting the flag.

// Can write.
    stdin->sync.can_write = TRUE;
// Can write and read.
    stdin->_flags = __SWR;
// Data
    ch_buffer[0] = (char) (Data & 0xFF);

// Write 1 byte.
// see: fslib.c

    wbytes = 
        (int) file_write_buffer ( 
            (file *) stdin, 
            (char *) ch_buffer, 
            (int) 1 );

// Can read.
// O aplicativo precisa disso.
    stdin->sync.can_read = TRUE;
// Can read.
// O worker no kernel precisa disso.
    stdin->_flags = __SRD;

// Return the number of written bytes.
    return (int) wbytes;

fail:
    return (int) -1;
}

// service 8002
// IN: fd for the new stdin
// OUT: TRUE or FALSE.
int sys_setup_stdin(int stdin_fd)
{
    file *f;
    struct te_d *p;
    pid_t current_process = -1;

    if (stdin_fd < 0 || stdin_fd >= 32){
        return FALSE;
    }

// process

    // Get PID for the current process for a given core.
    // IN: core id
    current_process = (pid_t) get_current_process(0);
    if (current_process < 0 || current_process >= PROCESS_COUNT_MAX)
    {
        return FALSE;
    }
    p = (struct te_d *) teList[current_process];
    if ((void*) p == NULL){
        return FALSE;
    }
    if (p->used != TRUE){
        return FALSE;
    }
    if (p->magic != 1234){
        return FALSE;
    }

// File structure
    f = (file *) p->Objects[stdin_fd];
    if ((void*) f == NULL){
        return FALSE;
    }
    if (f->used != TRUE){
        return FALSE;
    }
    if (f->magic != 1234){
        return FALSE;
    }

// The new stdin.
    stdin = (file *) f;
// Permission for writing.
    stdin->sync.can_write = TRUE;
// flags
    stdin->_flags |= __SWR;

// ok, we have a new stdin.
// this way the keyboard can put the bytes into this new file.
    return TRUE;
}

int is_socket(file *f)
{
    if ((void *) f == NULL){
        return FALSE;
    }
    if (f->magic != 1234){
        return FALSE;
    }
    // Yes it is a socket
    if (f->____object == ObjectTypeSocket){
        return TRUE;
    }
    return FALSE;  // No it's not
}

int is_virtual_console(file *f)
{
    if ((void *) f == NULL){
        return FALSE;
    }
    // Yes it is a console
    if (f->____object == ObjectTypeVirtualConsole){
        return TRUE;
    } 
    return FALSE;  // No it's not
}

// Kernel size version of the
// standard input() libc function.
unsigned long kinput(unsigned long ch)
{
    register int i=0;
    char c = (char) ch;

// Input mode.
// #bugbug:
// Estamos nos referindo ao tipo de linha, 
// se é simples ou multiplas linhas.
// Mas temos outra flag relativa à imput mode 
// que trata dos eventos.
// See: ???
// Onde estão as flags ???

    if (g_inputmode == INPUT_MODE_LINE)
    {
        if (prompt_pos >= PROMPT_SIZE)
        {
            //printk ("kstdio-input: [FAIL] INPUT_MODE_LINE full buffer!\n");
            goto fail;
        }
    }

    // Tem que ter o tamanho de um arquivo.
    if (g_inputmode == INPUT_MODE_MULTIPLE_LINES)
    {
        if (prompt_pos >= PROMPT_SIZE)
        {
            //printk("kstdio-input: [FAIL] INPUT_MODE_MULTIPLE_LINES full buffer\n");
            goto fail;
        }
    }

// Trata o caractere digitado

    switch (c){

    // Enter.
    // +se for modo comando devemos finalizar com zero.
    // +se for modo texto, devemos apenas incluir os caracteres \r \n.
    //case 0x1C:
    //case VK_RETURN:
    case '\n':
    case '\r':
        //modo linha 
        if (g_inputmode == INPUT_MODE_LINE)
        {
            prompt[prompt_pos] = (char )'\0';  // end of line
            //#todo: ?? ldiscCompare();
            // o compare está no aplicativo.
            for (i=0; i<PROMPT_MAX_DEFAULT; i++)
            {
                prompt[i]     = (char) '\0';
                prompt_out[i] = (char) '\0';
                prompt_err[i] = (char) '\0';
            };
            prompt_pos=0;
            goto input_done;
        }
        // modo multiplas linhas 
        if (g_inputmode == INPUT_MODE_MULTIPLE_LINES)
        {
            prompt[prompt_pos] = (char )'\r'; 
            prompt_pos++;
            prompt[prompt_pos] = (char )'\n';
            prompt_pos++;
        }
        break;

    // Backspace
    case 0x0E:
        if (prompt_pos <= 0)
        {
            prompt_pos = 0;
            prompt[prompt_pos] = (char ) '\0';
            break; 
        }
        // Apaga o anterior (no buffer).
        prompt_pos--;
        prompt[prompt_pos] = (char ) '\0';
        break;

    // ...

    // Para qualquer caractere que não sejam 
    // os especiais tratados acima.
    default:
        prompt[prompt_pos] = c;
        prompt_pos++;
        break;
    };

//input_more:
    return 0;

input_done:
    //return VK_RETURN;
    return (unsigned long) '\n';
fail:
    return (unsigned long) 0; 
}

/*
 * printchar:
 *     Coloca o caractere na string ou imprime.
 * Essa função chama uma rotina que deverá tratar o caractere e 
 * em seguida enviá-lo para a tela.
 * Essa rotina é chamada pelas funções: /print/printi/prints.
 */
// #importante
// Se a string existe colocamos nela,
// caso contrário imprimimos no backbuffer.
// Vamos aproveitar esse momento para ativarmos a
// pintura no caso dos caraters enviados para uma 
// stream de output, como stdout.
// Ativaremos a rotina de mostrar na tela só no momento em que 
// encontramos um fim de linha.
// IN:
//     **str // #dangerdanger
//     c
void printchar(char **str, int c)
{

// Valid pointer.
// We have a string.
    if (str){

        if (c == '\n'){
            // tty->print_pending = 1;
        }
        
        // #dangerdanger
        **str = c;

        ++(*str);

// Invalid pointer
// No string.
    } else {
        putchar (c);
    };
}

// Used for tests.
void putchar_K(void)
{
    putchar('K');
}

/*
 * putchar:
 *     Put a char on the screen. (libC).
 *     Essa rotina chama uma rotina de tratamento de caractes, 
 * somente depois é que o caractere será enviado para a tela.
 *     Essa rotina é chamada pelas funções: /printchar/input/.
 */
// Para virtual consoles.
// Em tty/console.c

int putchar(int ch)
{
// + Draw char.
// + Do not refresh char.

// #todo
// Maybe we can filter the printable chars
// for the console font.

// Parameter:
    if (ch < 0){
        goto fail;
    }

// Draw char into the foreground console.
// But do not refresh the char into the screen.
    if (fg_console<0 || fg_console > 3){
        goto fail;
    }
    console_outbyte(ch, fg_console);

    return (int) ch;
fail:
    return (int)(-1);
}

/*
 *  == Segue aqui o suporte a função 'printk' ====
 *
 * #obs:
 * Em user mode temos uma modelo mais tradicional de printk,
 * talvez seja bom implementa-lo aqui também.
 */

// prints:
// It supports printk. 
// #bugbug
// We need to create a cleaner routine.
// This one is a mess.
// '**out' #dangerdanger

int 
prints ( 
    char **out, 
    const char *string, 
    int width, 
    int pad )
{
    const char *ptr;
    int pc = 0;
    int padchar = ' ';
    register int len = 0;

    if (width > 0) 
    {
        // ?? ugly
        // The if statements are outside the for loop. 
        for (ptr = string; *ptr; ++ptr)
            ++len;
        if (len >= width) 
            width = 0;
        else 
            width -= len;
        if (pad & PAD_ZERO) 
            padchar = '0';
    }

    if (!(pad & PAD_RIGHT)) 
    {
        //#ugly
        for ( ; width > 0; --width)
        {
            printchar (out,padchar);
            ++pc;
        };
    }

    //#ugly
    for ( ; *string; ++string )
    {
        printchar (out, *string);
        ++pc;
    };

    //#ugly
    for ( ; width > 0; --width )
    {
        printchar (out,padchar);
        ++pc;
    };

    return (int) pc;
}

// printi:
// Support for printk.
// #todo: '**out' #dangerdanger

int 
printi (
    char **out, 
    int i, 
    int b, 
    int sg, 
    int width, 
    int pad, 
    int letbase )
{
    char print_buf[PRINT_BUF_LEN];
    register char *s;
    register int t, neg = 0, pc = 0;
// loop
    register unsigned int u = i;

    if (i == 0){
        print_buf[0] = '0';
        print_buf[1] = '\0';
        return (int) prints (out, print_buf, width, pad);
    }

    if ( sg && 
         b == 10 && 
         i < 0 )
    {
        neg = 1;
        u = -i;
    }

    s = ( print_buf + ( PRINT_BUF_LEN -1 ) );
    *s = '\0';

    while (u)
    {
        t = (u % b);
        
        // ugly
        
        if ( t >= 10 )
            t += letbase - '0' - 10;
        
        *--s = t + '0';
        u /= b;
    };

    if (neg)
    {
        if ( width && (pad & PAD_ZERO) ){
            printchar (out, '-');
            ++pc;
            --width;
        } else { 
            *--s = '-'; 
        };
    }

// #obs: 
// retorna pc + o retorno da função.
// ugly
    
    return (int) pc + prints(out, s, width, pad);
}


// print:
// Rotina de suporta a printk.
// #bugbug
// E se essa rotina for chamada com o primeiro argumento nulo?
// vai escrever na IVT ?
// Vai chamar alguma rotina passando esse emsmo endereço de buffer.
// Atençao:
// print() nao analisa flags como runlevel ou kernel phase.
// #todo: Update comment

int print(char **out, int *varg)
{
    // #ps:This increament is not good
    char *format = (char *) (*varg++);

    int width = 0;
    int pad = 0;
    int pc = 0;

    char scr[2];

    // Ugly
    for ( ; *format != 0; ++format ) 
    {
        // Switch
        if ( *format == '%' ) 
        {
            ++format;

            width = pad = 0;

            if ( *format == '\0' ) { break; }
            if ( *format == '%' )  { goto ____out; }

            if ( *format == '-' )
            {
                ++format;
                pad = PAD_RIGHT;
            }

            while ( *format == '0' ) 
            {
                ++format;
                pad |= PAD_ZERO;
            };

            // #ugly
            for ( ; 
                *format >= '0' && *format <= '9'; 
                ++format )
            {
                width *= 10;
                width += *format - '0';
            };

            // #ugly
            // String
            if ( *format == 's' ) 
            {
                register char *s = *((char **)varg++);
                 pc += prints ( 
                           out, 
                           s?s:"<NULL>", 
                           width, 
                           pad );

                continue;
            }

            // Integer
            if ( *format == 'd' ){
                pc += printi (out, *varg++, 10, 1, width, pad, 'a');
                continue;
            }

            // Hexa
            if ( *format == 'x' ){
                pc += printi (out, *varg++, 16, 0, width, pad, 'a');
                continue;
            }

            if ( *format == 'X' ){
                pc += printi (out, *varg++, 16, 0, width, pad, 'A');
                continue;
            }

            if ( *format == 'u' ){
                pc += printi (out, *varg++, 10, 0, width, pad, 'a');
                continue;
            }

            // #ugly
            // Char
            // char are converted to int then pushed on the stack. 
            if ( *format == 'c' ) 
            {
                scr[0] = *varg++;
                scr[1] = '\0';
                pc += prints (out, scr, width, pad);
                continue;
            }

            // %f (floating-point)
            // Not inside the kernel for now.
            // if (*format == 'f') { ... }

        // Os caracteres normais diferentes de "%".
        } else {
            ____out:
                printchar (out, *format);
                ++pc;
        };
    };

// Se o buffer existe, finaliza a string?
    if (out){ 
        **out = '\0'; 
    }

    return (int) pc;
}


// print() is a helper function for this one.
/*
int vsprintf(char *string, const char *format, va_list ap);
int vsprintf(char *string, const char *format, va_list ap)
{
}
*/

void 
kinguio_i2hex_versao2(
    unsigned long val, 
    char* dest, 
    int len)
{
    register int i=0; 
    char *cp;
    int x=0;
    unsigned long n=0;

    if (val == 0)
    {
        cp = &dest[0];
        *cp++ = '0';
        *cp = '\0';
        return;
    }

    n = val;
    cp = &dest[len];
    while (cp > dest)
    {
        x = n & 0xF;
        n >>= 4;
        *--cp = x + ((x > 9) ? 'A' - 10 : '0');
    };

    dest[len]='\0';

    cp = &dest[0];
    for (i=0; i<len; i++)
    {
        if (*cp == '0'){
            cp++;
        }else{

            // #bugbug: We need another version of this funcion that
            // uses kernel_strcpy_safe insted of strcpy

            strcpy(dest, cp);
            break;
        };
    };

    cp = &dest[0];
    n = strlen(cp);

    memset(
        dest+n,
        0,
        len-n );
}

// ===================================

void 
kinguio_i2hex( 
    unsigned int val, 
    char *dest, 
    int len )
{
    char *cp;
    register int i=0;
    int x=0;
    unsigned n=0;  //??

    if (val == 0)
    {
        cp = &dest[0];
        *cp++ = '0';
        *cp = '\0';
        return;
    }

    n = val;
    cp = &dest[len];

    while (cp > dest)
    {
        x = (n & 0xF);
        n >>= 4;
        
        // #
        *--cp = x + ((x > (HEX_LEN+1)) ? 'A' - 10 : '0');
    };

    dest[len] = '\0';

    cp = &dest[0];

    for (i=0; i<len; i++)
    {
        if (*cp == '0'){
            cp++;
        } else {

            // #bugbug: We need another version of this funcion that
            // uses kernel_strcpy_safe insted of strcpy

            strcpy (dest,cp);
            break;
        };
    };

    cp = &dest[0];
    n = strlen(cp);

    memset( (dest+n), 0, (8-n) );
}

// Local
static char *__utoa_r (unsigned long val, char *str)
{
    char *valuestring = (char*) str;
    unsigned long value = val;
    char *p;
    char swap;

    p = valuestring;

    do {
        *p++ = (char)(value % 10) + '0';
        value /= 10;

    } while (value);

    *p-- = '\0';

    while (p > valuestring)
    {
        swap = *valuestring;
        *valuestring++ = *p;
        *p-- = swap;
    };

    return str;
}

char *kinguio_utoa(
    unsigned long val, 
    char *dst, 
    int radix )
{
    char *cp = (char *) dst;
    unsigned long lu = (unsigned long)val;

    if (radix == 16)
        kinguio_i2hex_versao2(lu, cp, 16);
    else 
        __utoa_r(lu, cp);
    return dst;

    return dst;  //#bugbug
}

char *kinguio_itoa (int val, char *str) 
{
    int value = val;
    char *valuestring = (char *) str;
    int min_flag=0;
    char swap=0; 
    char *p;

    if (0 > value)
    {
        *valuestring++ = '-';
        value = -____INT_MAX> value ? min_flag = ____INT_MAX : -value;
    }

    p = valuestring;

    do {
         *p++ = (char) (value % 10) + '0';
         value /= 10;
    } while (value);

    if (min_flag != 0)
    {
        ++*valuestring;
    }

    *p-- = '\0';

    while (p > valuestring)
    {
        swap = *valuestring;
        *valuestring++ = *p;
        *p-- = swap;
    };

    return str;
}

static char *_vsputs_r(char *dest, char *src)
{
    unsigned char *usrc = (unsigned char *) src;
    unsigned char *udest = (unsigned char *) dest;

    while ( *usrc )
    { 
        *udest++ = *usrc++; 
    };

    return (char *) udest;
}

/**
 * kinguio_vsprintf - Formats a string and writes the result into the supplied buffer.
 *
 * This function interprets a format string (similar to printf) and writes the corresponding
 * formatted output into the string buffer pointed to by 'str'. It supports a subset of format
 * specifiers including characters ('%c'), strings ('%s' or '%S'), signed integers ('%d' or '%i'),
 * unsigned integers ('%u'), and hexadecimal numbers ('%x' or '%X'). In addition, it supports a
 * 64-bit flag (using the 'l' modifier) for specific unsigned formats.
 *
 * Parameters:
 *   str   - Pointer to the destination character buffer where the formatted string will be written.
 *   fmt   - The format string; it may include the format specifiers mentioned above.
 *   ap    - The variable argument list containing additional values to format.
 *
 * Returns:
 *   The total number of characters written to the destination buffer. This is computed by
 *   calculating the difference between the updated string pointer and the original buffer start.
 */
/*
Additional Details

Function Overview: 
The function iterates through the format string character by character. When it 
encounters a %, it checks if a length modifier (l) exists to signal handling of a 64-bit number. 
Then, it processes the type specifier (e.g., %c, %s, %d, %u, %x) by retrieving the corresponding value 
from the variable argument list and converting it into a string form.

Error Handling: 
Notice that when a NULL string is found (for %s or %S), the function writes "(null)" to the buffer. 
This provides a safe fallback rather than causing a crash.

Return Value: 
The difference between the final pointer and the start of the buffer gives the total number of 
characters written. Casting to long ensures that the pointer difference is computed correctly, 
then the result is cast back to an int for the return value.
*/
// Worker for printf and sprintf.

int 
kinguio_vsprintf(
    char *str, 
    const char *fmt, 
    va_list ap )
{
// A buffer to hold converted numbers as strings.
    static char buffer[1024];

// 'index' tracks the current position in the format string.
    register int index=0;

// Variables for processing individual characters and strings.
    char c=0;  // Temporary storage for a single character
    char *s;   // Pointer to a string argument
    char *str_tmp = str;  // Pointer used to build the result string; initially at the start of 'str'

// _c_r is a two-character array used to store a single character as a null-terminated string.
    char _c_r[] = "\0\0";

    // Variables for handling numerical conversions.
    // d|i|x
    int d=0;  // Temporary storage for int values
    //long ld=0;  // Temporary storage for long integers (signed)

    // Unsigned numbers handling (using either int or long, depending on format specifiers).
    // u
    //unsigned char u=0;
    unsigned int   u=0;
    unsigned long lu=0;

    // Flag indicating a 64-bit format specifier was found.
    int type64bit = FALSE;

// Loop
// Process each character of the format string until the null-terminator is reached.
    while ( fmt[index] )
    {
        // Check for '%' which signals the start of a format specifier.
        switch (fmt[index]){

        case '%':
            // Move to the character following '%'
            ++index;

            // Estamos lidando com 64bit?
            // Vamos para o próximo char e indicaremos essa condição.
            // Check if there is a length modifier (the 'l' for 64-bit values)
            if (fmt[index] == 'l')
            {
                ++index;
                type64bit = TRUE;  // Mark that we are handling a 64-bit value for the next specifier.
            }

            switch (fmt[index]){

            // Process the conversion specifier (e.g., c, s, d, u, x, etc.).
            case 'c':
                // Retrieve the next int argument and convert it to a char.
                // Place the character in _c_r and output it.
                *_c_r = c = (char) va_arg(ap, int);
                str_tmp = _vsputs_r(str_tmp,_c_r);  // print
                break;

            // char*
            // %s or %S: Output a string.
            case 's':
            case 'S':
                // Retrieve the string pointer argument.
                s = va_arg (ap, char*);
                // If string is not NULL, output it; otherwise, output "(null)".
                if ((void*) s != NULL){
                    str_tmp = _vsputs_r(str_tmp,s);
                }
                if ((void*) s == NULL){
                    str_tmp = _vsputs_r(str_tmp,"(null)");
                }
                break;

            // int
            // %d or %i: Output a signed integer.
            case 'd':
            case 'i':
                // Get the next int argument.
                d = va_arg (ap, int);
                // Convert the integer to its ASCII representation and store in buffer.
                kinguio_itoa (d,buffer);
                // Append the converted string to the output.
                str_tmp = _vsputs_r(str_tmp,buffer);
                break;

            // unsigned int or unsigned long
            // %u: Output an unsigned integer.
            case 'u':
                //'lu'
                // Check if a 64-bit unsigned value is expected.
                if (type64bit == TRUE)
                {
                    // Retrieve an unsigned long argument.
                    lu = va_arg (ap, unsigned long);
                    // Convert it to a string in base 10.
                    //kinguio_itoa (lu,buffer);
                    kinguio_utoa(lu, buffer, 10);  //ok
                    str_tmp  = _vsputs_r(str_tmp,buffer);
                    // Reset the flag for future specifiers.
                    type64bit=FALSE;
                    break;
                }

                //if(type64bit==FALSE){
                // For standard (non-64 bit) unsigned int.
                u = va_arg (ap, unsigned int);
                // Convert the unsigned integer to string.
                kinguio_itoa (u,buffer);
                //utoa(u, buffer, 10);
                str_tmp  = _vsputs_r(str_tmp,buffer);
                //}
                break;

            // int  (hexa) or unsigned long
            // %x or %X: Output an integer in hexadecimal format.
            case 'X':
            case 'x':
                // Check if a 64-bit value is indicated.
                //'lx'  #fail
                if (type64bit == TRUE)
                {
                    // Retrieve the next unsigned long argument.
                    lu = va_arg (ap, unsigned long);
                    // Convert the number to a hexadecimal string using base 16.
                    //kinguio_itoa (lu,buffer);
                    kinguio_utoa(lu, buffer, 16);
                    str_tmp  = _vsputs_r(str_tmp,buffer);
                    type64bit=FALSE;
                    break;
                }
                // For non-64-bit numbers, assume int.
                d = va_arg (ap, int);
                //d = va_arg (ap, unsigned int);
                // Convert the integer to hexadecimal (8 digits may be assumed).
                kinguio_i2hex(d,buffer,8);
                str_tmp = _vsputs_r(str_tmp,buffer);
                break;

            // %p
            // Pointer type: typically printed as hexadecimal.
            case 'p':
                // Pointer: treat as unsigned long and print in hexadecimal.
                lu = (unsigned long) va_arg (ap, void*);
                kinguio_utoa(lu, buffer, 16);
                str_tmp = _vsputs_r(str_tmp,"0x");
                str_tmp  = _vsputs_r(str_tmp,buffer);
                break;

            // %f: Print a floating-point number.
            //case 'f':
                //break;

            // Default: If an unknown specifier is met, output a literal "%%".
            default:
                str_tmp = _vsputs_r(str_tmp,"%%");
                break;
            }
            break;

        // For any character that is not '%', simply copy it to the output.
        default:
            *_c_r = fmt[index];
            str_tmp = _vsputs_r(str_tmp,_c_r);
            break;
        }
        // Move to the next character in the format string.
        ++index;
    }

    // #todo: Include this.
    // *str = 0;

// Return the total number of characters written by measuring the difference
// between the final output pointer and the beginning of the destination buffer.
    return (int) ( (long) str_tmp - (long) str );
}

/*
 * kinguio_puts:
 *   Print a null‑terminated string to the foreground console.
 *
 * Behavior:
 *   - Iterates over each character in the input string.
 *   - For each character, calls console_outbyte() to draw and refresh it
 *     on the active console (fg_console).
 *   - If the string is NULL or empty, the function returns immediately.
 *
 * Parameters:
 *   str - Pointer to the null‑terminated string to be printed.
 *
 * Notes:
 *   - This is the printing stage in the printk path:
 *       printk() → kinguio_printf() → kinguio_puts() → console_outbyte() …
 *   - Unlike kinguio_vsprintf(), this function does not format; it only
 *     emits characters to the console.
 *   - Uses console_outbyte(), which refreshes the screen after each char drawing.
 */

void kinguio_puts(const char* str)
{
    size_t StringLen=0;
    register int i=0;
    int _char=0;

// Parameter:
    if (!str){
        return;
    }

// String lenght
    StringLen = (size_t) strlen(str);
    if (StringLen <= 0)
        return;

// Print chars
// Draw, and refresh each a single char
    for (i=0; i<StringLen; i++)
    {
        _char = (int) (str[i] & 0xFF);
        console_outbyte(_char, fg_console);
    };
}

int kputs(const char *str)
{
    if ((void *) str == NULL){
        return -1;
    }
    return (int) printk("%s",str);
    //return (int) printk ("%s",str);
}

/*
 * sprintf_old:
 *     @field 2
 *     int ksprintf ( char * str, const char * format, ... );
 *     Composes a string with the same text that would be 
 * printed if format was used on printk, 
 * but instead of being printed, the content is stored 
 * as a C string in the buffer pointed by str.
 */
// #suspensa
// Essa implementação foi feita para 32bit e não funciona
// por inteiro em long mode.

int sprintf_old ( char *str, const char *format, ... )
{
    register int *varg = (int *) (&format);

    return (int) print(&str, varg);
}    

// mysprintf: (ksprintf)
// Variable parameter form to achieve ksprintf.
int mysprintf(char *buf, const char *fmt, ...)
{
    register int n=0;

// Write the fmt format string to the buffer buf 
    va_list args;
    va_start(args, fmt);
    n = (int) kinguio_vsprintf(buf, fmt, args);
    //buf[n] = '\0';
    va_end(args);

    return (int) n;
}

int k_ungetc(int c, file *f)
{

// Parameters:
    if (c == EOF){ 
        return (int) c;
    }
    if ((void *) f == NULL){
        return EOF;
    }

// #todo: 
// flag eof.

    //stream->flags = (stream->flags & ~_IOEOF);

    f->_p--;
    f->_p[0] = (char) c;

    return (int) c;
}

long k_ftell(file *f)
{
// Parameter:
    if ((void *) f == NULL){
        return EOF;
    }

    return (long) (f->_p - f->_base);
}

// Return the fd.
int k_fileno(file *f)
{
// Parameter:
    if ((void *) f == NULL){
        return EOF;
    }

    return (int) f->_file;  
}

int k_fgetc(file *f)
{
    int ch=0;

// Parameter:
    if ((void *) f == NULL){
        printk ("k_fgetc: f\n");
        goto fail;
    }

    //(--(p)->_r < 0 ? __srget(p) : (int)(*(p)->_p++))

//#fim.
//cnt decrementou e chegou a zero.
//Não há mais caracteres disponíveis entre 
    //stream->_ptr e o tamanho do buffer.
		
		/*
		if ( stream->_cnt <= 0 )
		{
			stream->_flags = (stream->_flags | _IOEOF); 
			stream->_cnt = 0;
		    //printk ("#debug: fgetc: $\n");			
			//isso funciona, significa que a estrutura tem ponteiro e base validos.
			//printk("show fgetc:: %s @\n", stream->_base );
			return EOF;
		};
		*/

		//#debug
		//nao podemos acessar um ponteiro nulo... no caso endereço.

// Buffer pointer
    if (f->_p == 0){
        printk ("k_fgetc: f->_p\n");
        goto fail;
    }

// #obs: 
// Tem que ter a opção de pegarmos usando o posicionamento
// no buffer. O terminal gosta dessas coisas.

// Get the char
    ch = (int) *f->_p;
// Update the pointer
    f->_p++;
    f->_cnt--;
// Return the char
    return (int) ch;

fail:
    printk ("k_fgetc: fail\n");
    return EOF;
}

int k_feof (file *f)
{
    int ch=0;
 
    if ((void *) f == NULL){
        return (int) (-1);
    } else {
        ch = (int) k_fgetc(f);
        if (ch == EOF){
            return (int) 1;
        } else {
            return 0;
        };
    };

//checar se o eof foi atingido.
    // return( (stream->_flag & _IOEOF) );

    return 0;
}

int k_ferror(file *f)
{
    int r=0;

    if ((void *) f == NULL){
        return EOF;
    }
    r = (int) ((f->_flags & _IOERR));

    return (int) r;
}

// k_fseek:
// offset argument is the position that you want to seek to,
// and whence is what that offset is relative to.
// #todo
// Checar limites do offset.
// #dictioonary-ptbr: whence=deonde
// #todo
// IN:
int k_fseek(file *f, long offset, int whence)
{
    char *p;
    register int i=0;

    if ((void *) f == NULL){
        debug_print ("k_fseek: f\n");
        goto fail;
    }
    if (whence<0){
        goto fail;
    }

/*
SEEK_SET
    The file offset is set to offset bytes.
SEEK_CUR
    The file offset is set to its current location plus offset bytes.
SEEK_END
    The file offset is set to the size of the file 'plus' offset bytes.
    (#danger: It goes beyond!)
*/

// Partindo 'de onde'?
// #see: 
// kstdio.h
// https://man7.org/linux/man-pages/man2/lseek.2.html
    switch (whence){

// Não podemos aceitar valores negativos,
// pois ultrapassa o inicio do arquivo.
// Não podemos colocar o ponteiro de leitura
// depois do fim do arquivo.
// Não mexe no offset de escrita.
// continuaremos a escrever de onde paramos.
// Atualiza o offset de leitura.
// A quantidade de bytes disponíveis
// continua a mesma, pois não incluímos ou retiramos 
// dados de dentro do buffer.
// O ponteiro de trabalho para refletir a próxima
// leitura. mas não precisa isso, pois o offset é relativo à base.
    case SEEK_SET:
        if (offset<0){
            offset=0;
        }
        if ( offset > f->_cnt ){
            offset = f->_cnt;
        }
        // Read and write devem começar de (base + offset).
        f->_r = offset;
        f->_w = offset;
        f->_p = (f->_base + offset); 
        //printk("offset: %d\n",offset);
        //while(1){}
        goto done;
        break;

// Levando em consideração o ponteiro de trabalho atual,
// vamos mudar o offset e reposicionar o ponteiro de trabalho.
// Não mexe no offset de escrita.
// continuaremos a escrever de onde paramos.
// A quantidade de bytes disponíveis
// continua a mesma, pois não incluímos ou retiramos 
// dados de dentro do buffer.
// Atualiza o offset de leitura.
// mas agora em relação ao ponteiro de trabalho e 
// não em relação ao ponteiro da base.
// temos que respeitar a quantidade disponivel.
    case SEEK_CUR:
        if ( offset > f->_cnt ){
            offset = f->_cnt;
        }
        // Read and write devem começar de (current + offset).
        f->_p = (f->_p + offset);
        f->_r = (f->_p - f->_base);
        f->_w = (f->_p - f->_base);
        goto done;
        break;

// #todo: 
// For now we can't accept positive values.
// porque vai ultrapassar o fim do arquivo.
// não vamos mexer no ponteiro de escrita,
// Vamos continuar escrevendo de onde paramos,
// pois nenhuma informação foi incluida ou retirada do arquivo.
// Não vamos mexer na quantidade de bytes disponível no buffer,
// pois não estamos incluindo informação no buffer.
    case SEEK_END:
        if(offset>0){
            offset=0;
        }
        // Read and write devem começar de (end of file + offset).
        // Estamos falando do fim do arquivo e não do fim do buffer.
        // #bugbug: 
        // O arquivo não pode ser maior que o buffer disponível pra ele.
        if ( f->_fsize > f->_lbfsize ){
            panic("k_fseek: #todo f->_fsize > f->_lbfsize\n"); 
        }
        if ( (f->_fsize + offset) > f->_lbfsize ){
            panic("k_fseek: #todo (f->_fsize + offset) > f->_lbfsize\n");
        } 
        f->_r = (f->_fsize + offset);
        f->_w = (f->_fsize + offset);
        f->_p = 
            ( f->_base + (f->_fsize + offset) );
        goto done;
        break;

// #see: kstdio.h
// BUFSIZ is the minimum for a valid buffer.
// Lets clear only the first part of the buffer.
    case GRAMADO_SEEK_CLEAR:
        p = (char *) f->_base;
        //#test
        for (i=0; i<BUFSIZ; i++)
        {
           *p = 0;
           p++; 
        };
        f->_p = f->_base;
        f->_r = 0;
        f->_w = 0;
        f->_cnt = f->_lbfsize;
        goto done;
        break;
    
    //case SEEK_DATA:
    //    break;
    //case SEEK_HOLE:
    //    break;

// Default
    default:
        //printk ("default:\n");
        goto fail;
        break;
    };

fail:
    printk ("k_fseek fail\n");
    return (int) (-1);
done:
    return 0;
}

// bsd stuff
/*
 * Various output routines call wsetup to be sure it is safe to write,
 * because either _flags does not include __SWR, or _buf is NULL.
 * _wsetup returns 0 if OK to write, nonzero otherwise.
 */
/*
int __swsetup(file *fp)
int __swsetup(file *fp)
{
    return -1;
}
*/

/*
 * Write the given character into the (probably full) buffer for
 * the given file.  Flush the buffer out if it is or becomes full,
 * or if c=='\n' and the file is line buffered.
 */
// #importante
// Isso é usado em __sputc no bsd.
/*
int __swbuf (int c, file *fp);
int __swbuf (int c, file *fp)
{
    return -1;
}
*/

int k_fputc(int ch, file *f)
{

// Pointer validation
    if ((void *) f == NULL){
        debug_print ("k_fputc: f\n");
        panic       ("k_fputc: f\n");
        return EOF;
    }

// The buffer is not full,
// and the char is not a '\n'.

    if ( f->_cnt > 0 && ch != '\n' )
    {
        // Write it into the buffer
        ksprintf(f->_p, "%c", ch);
        // Update the pointer
        f->_p++;
        // Update the offset for the writer
        f->_w++;
        // Update the counter
        // How many bytes the buffer still have?
        f->_cnt--;
        // The buffer is full
        // #todo: What we need to do now?
        if (f->_cnt <= 0)
        {
            debug_print ("k_fputc: _cnt\n");
            panic       ("k_fputc: _cnt\n");
            f->_cnt = 0;
            return EOF;
        }
        f->_flags |= __SRD;  // Can read
        return (int) ch;  
    }

// Atualizar as flags quando o buffer está cheio.
// se o buffer está cheio.

    /*
    //Now writing
    if (stream->flags & _IORW)
    {
        stream->flags &= ~_IOREAD;
        stream->flags |= _IOWRITE;
    }
    */

    // File is not writable 
    //if (!(stream->flags & _IOWRITE))
        //return (EOF);        

//fail:
    return EOF;
}

int k_fscanf (file *f, const char *format, ... )
{
    if ((void*)f == NULL)
        goto fail;

    panic ("k_fscanf: #todo\n");

    return 0;

fail:
    return (int) -1;
}

/*
int vfprintf ( file *stream, const char *format, stdio_va_list argptr );
int vfprintf ( file *stream, const char *format, stdio_va_list argptr )
{
}
*/

//Writes format output of a stdarg argument list to a file.
/* 
int vfprintf(file *stream, const char *format, va_list ap);
int vfprintf(file *stream, const char *format, va_list ap)
{
	int n;             // Characters written. 
	char buffer[1024]; // Buffer.             
	
	// Format string. 
	n = vsprintf(buffer, format, ap);
	
	// Write formated string to file. 
	if (n > 0)
		fputs(buffer, stream);
	
	return (n);
}
*/

void k_rewind(file *f)
{
    //fseek (f, 0L, SEEK_SET);
    if ((void *) f == NULL){
        return;
    }
    f->_p = f->_base;
}

// Change f->magic to 4321.
int k_fclose (file *f)
{
// Parameter:
    if ((void *) f == NULL){
        return EOF;
    }
    if (f->used != TRUE){
        return EOF;
    }
    if (f->magic != 1234){
        return EOF;
    }

    f->used = TRUE;
    f->magic = 4321;  // Inverted value
    return 0;
}

int k_fputs(const char *str, file *f)
{
    size_t StringSize=0;

// Parameter:
    if ((void*) str == NULL){
        goto fail;
    }
    if ((void *) f == NULL){
        goto fail;
    } 

// String size
    StringSize = (size_t) strlen(str);
    if (StringSize > f->_cnt){
        goto fail;
    }
// Update _cnt
    f->_cnt = (int) (f->_cnt - StringSize);
// Put
    ksprintf(f->_p, str);
// Update _p
    f->_p = (f->_p + StringSize);

    return 0;  // OK

fail:
    return (int) (-1);
}

// k_setbuf:
// see: 
// https://linux.die.net/man/3/setvbuf
void k_setbuf(file *f, char *buf)
{

// Parameters:
    if ((void *) f == NULL){
        debug_print("k_setbuf: f\n");
        return;
    }
    if ((void *) buf == NULL){
        debug_print("k_setbuf: buf\n");
        return;
    }

//#todo
//se o buffer é válido.

    //if (stream->_bf._base != NULL) 
    //{
        //if (stream->cnt > 0)
            //fflush (stream);

        //free (stream->buf);
    //}

// Udate stream.
    f->_bf._base = buf;
    //stream->_lbfsize = size;        
    // ?? stream->bufmode = mode;
    f->_p = buf;
    // f->_p = f->_bf._base
    // f->cnt = 0;

// #todo
// Setup all the buffer elements.
// ...
}

void k_setbuffer (file *f, char *buf, size_t size)
{
  // #todo
  // Check parameters.

    if ((void *) f == NULL)
    {
        // #todo
        // Maybe we need a message here.
        return;
    }

    /*
    if ( (void *) buf == NULL ){
        debug_print("k_setbuffer: buf\n");
        return;
    }
    */

//#todo
//se o buffer é válido.
        
    //if (stream->_bf._base != NULL) 
    //{
        //if (stream->cnt > 0)
             //fflush (stream);
                
            //free (stream->buf);
    //}
        
    // Udate stream.
    f->_bf._base = buf;
    f->_lbfsize = size;        
    // ?? stream->bufmode = mode;
    f->_p = buf;
    // ??stream->cnt = 0;
    //...
}

void k_setlinebuf(file *f)
{
    printk ("k_setlinebuf: #todo\n");
    if ((void *) f == NULL){
        return;
    }

    //...
}

// #todo
// Not implemented yet.
int 
k_setvbuf (
    file *f, 
    char *buf, 
    int mode, 
    size_t size )
{

    if ((void *) f == NULL){
        return -1;
    }

    // #todo: Buffer validation

    //if (f->_bf._base != NULL) 
    //{
        //if (f->cnt > 0)
            //fflush (f);
            //free (f->buf);
    //}
    
    // Udate stream
    f->_bf._base = buf;
    f->_lbfsize = size; 
    // ?? f->bufmode = mode;

    f->_p = buf;
    // ??f->cnt = 0;
    //...

    return 0;
}

// Maybe we can do some operations 
// in a regular file using ioctl.
// EINVAL request or argp is not valid.
int regularfile_ioctl(int fd, unsigned long request, unsigned long arg)
{
    struct te_d *p;
    pid_t current_process;
    file *fp;

    if (fd < 0 || fd >= OPEN_MAX) 
        return -EBADF;

// process
    current_process = get_current_process(0);
    p = (struct te_d *) teList[current_process];
    if (!p) 
        return -EINVAL;
    if (p->magic != 1234) 
        return -EINVAL;

// file pointer
    fp = (file *) p->Objects[fd];
    if (!fp) 
        return -EINVAL;
    if (fp->magic != 1234) 
        return -EINVAL;

// It needs to be a regular file
    if (fp->____object != ObjectTypeFile)
        return -ENOTTY; // not a regular file

    switch (request) {
        case FIONREAD: {
            int available = fp->_fsize - fp->_r;
            if (available < 0) 
                available = 0;
            return available;
        }

        case FIONBIO:
            // Non-blocking mode is meaningless for regular files,
            // but accept for compatibility.
            return 0;

        case FIOQSIZE:
            return fp->_fsize;

        case 4000:
            fp->sync.sender_pid = (pid_t)arg;
            return 0;

        case 4001: return fp->sync.sender_pid;
        case 4002: return fp->sync.can_read ? 1 : 0;
        case 4003: return fp->sync.can_write ? 1 : 0;
        case 4004: return fp->sync.can_execute ? 1 : 0;

        default:
            return -EINVAL;
    }

    return -1;
}

// Called by kstdio_initialize().
file *new_file(object_type_t object_type)
{
    file *new_file;
    int slot = -1;

// stderr
// pega slot em file_table[] para stderr

    slot = get_free_slots_in_the_file_table();
    if ( slot < 0 || slot >= NUMBER_OF_FILES ){
        x_panic("new_file: slot");
    }
    new_file = (file *) file_table[slot];
    if ((void*) new_file == NULL){
        x_panic("new_file: new_file");
    }
    new_file->filetable_index = slot;

// fd
// We don't have this yet.
    //new_file->_file = STDERR_FILENO;  //2
    new_file->_file = -1;

// This is a regular file.
    new_file->____object = object_type;
// sync
    new_file->sync.sender_pid = (pid_t) -1;
    new_file->sync.receiver_pid = (pid_t) -1;
    new_file->sync.can_read    = TRUE;
    new_file->sync.can_write   = TRUE;
    new_file->sync.can_execute = FALSE;
    new_file->sync.can_accept  = FALSE;
    new_file->sync.can_connect = FALSE;
// _flags
    new_file->_flags = (__SWR | __SRD); 

// buffer

    //new_file->_base = &prompt_err[0];  //See: kstdio.h
    //new_file->_p = &prompt_err[0];

    new_file->_base = kmalloc(PROMPT_SIZE);
    if ( (void*) new_file->_base == NULL )
        panic("new_file: new_file->_base");
    new_file->_p = new_file->_base;

    new_file->_bf._base = new_file->_base;
    new_file->_lbfsize = PROMPT_SIZE; //128; //#todo
    new_file->_r = 0;
    new_file->_w = 0;
    new_file->_cnt = PROMPT_SIZE;
    
    // #todo
    new_file->_tmpfname = "NONAME.TXT";

    new_file->fd_counter = 1;
    // ...
    // inode support.
    // pega slot em inode_table[] 
    slot = get_free_slots_in_the_inode_table();
    if (slot<0 || slot >=NUMBER_OF_FILES){
        x_panic("new_file: new_file inode slot\n");
    }
    new_file->inode = (struct inode_d *) inode_table[slot];
    new_file->inodetable_index = slot;
    if ((void*) new_file->inode == NULL){
        x_panic("new_file: new_file inode struct\n");
    }
    new_file->inode->filestruct_counter = 1;  //Inicialize

// Copy the name
    memcpy ( 
        (void*)       new_file->inode->path, 
        (const void*) new_file->_tmpfname, 
              sizeof( new_file->inode->path ) );

    
    // #test
    // Waiting lists
    new_file->writer_head = NULL;
    new_file->reader_head = NULL;
 
    new_file->used = TRUE;
    new_file->magic = 1234;

// Return the pointer for a new stream
    return (file*) new_file;
}

// #warning
// Because the libc has hardcoded file descriptor values for the
// standard streams, we gotta use the same values.
// So, this way we need to use the same file descriptors.
// We're gonna use STDIN_FILENO.
// Called by kstdio_initialize().
static void __initialize_stdin(void)
{
    int fd = STDIN_FILENO;
    int slot = -1;

// stdin
// pega slot em file_table[] para stdin

    slot = get_free_slots_in_the_file_table();
    if ( slot < 0 || slot >= NUMBER_OF_FILES ){
        x_panic("__initialize_stdin: slot");
    }
    stdin = (file *) file_table[slot];
    if ( (void*) stdin == NULL ){
        x_panic("__initialize_stdin: stdin");
    }
    stdin->filetable_index = slot;

// fd
    stdin->_file = fd;  //0
// This is a regular file.
    stdin->____object = ObjectTypeVirtualConsole;
    stdin->isDevice  = TRUE;
// sync
    stdin->sync.sender_pid = (pid_t) -1;
    stdin->sync.receiver_pid = (pid_t) -1;

//
// ------------------------------------------------------------
//  STDIN — Kernel‑level Permission Flags
//
//  These flags control what syscalls are allowed to do with
//  this file descriptor. They are enforced inside sys_read,
//  sys_write, sys_connect, sys_accept, etc.
//
//  can_read:
//      TRUE  → sys_read() is permitted.
//      FALSE → sys_read() fails.
//
//  can_write:
//      TRUE  → sys_write() is permitted.
//      FALSE → sys_write() fails.
//              (This is why writing to stdin normally fails
//               unless sys_setup_stdin() enables it.)
//
//  can_execute:
//      TRUE  → file may be executed (rarely used).
//
//  can_accept:
//      TRUE  → file may accept() connections (sockets only).
//
//  can_connect:
//      TRUE  → file may connect() to remote endpoints.
//
//  NOTE:
//      These are *kernel permissions*. They are independent
//      of libc flags (__SRD, __SWR). Even if __SWR is set,
//      sys_write() will still fail unless can_write == TRUE.
// ------------------------------------------------------------

    stdin->sync.can_read = TRUE;
    stdin->sync.can_write = TRUE;
    stdin->sync.can_execute = FALSE;
    stdin->sync.can_accept  = FALSE;
    stdin->sync.can_connect = FALSE;
// _flags
    stdin->_flags = (__SWR | __SRD); 

// #bugbug
// Esse buffer está sendo usado pelo console.

    stdin->_base = &prompt[0];    //See: kstdio.h
    stdin->_p = &prompt[0];
    stdin->_bf._base = stdin->_base;
    stdin->_lbfsize = PROMPT_SIZE; //128; //#todo
    stdin->_r = 0;
    stdin->_w = 0;
    stdin->_cnt = PROMPT_SIZE;
    stdin->_tmpfname = "KSTDIN  TXT";
    stdin->fd_counter = 1;

    // inode support.
    // pega slot em inode_table[] 
    slot = get_free_slots_in_the_inode_table();
    if (slot<0 || slot >=NUMBER_OF_FILES){
        x_panic("__initialize_stdin: [FAIL] stdin inode slot\n");
    }
    stdin->inode = (struct inode_d *) inode_table[slot];
    stdin->inodetable_index = slot;
    if ((void*) stdin->inode == NULL){
        x_panic("__initialize_stdin: [FAIL] stdin inode struct\n");
    }
    stdin->inode->filestruct_counter = 1; //inicialize

// Copy the name
    memcpy ( 
        (void *)      stdin->inode->path, 
        (const void*) stdin->_tmpfname, 
              sizeof( stdin->inode->path ) );

    // #test
    // Waiting lists
    stdin->writer_head = NULL;
    stdin->reader_head = NULL;

    stdin->used = TRUE;
    stdin->magic = 1234;
}

// #warning
// Because the libc has hardcoded file descriptor values for the
// standard streams, we gotta use the same values.
// So, this way we need to use the same file descriptors.
// We're gonna use STDOUT_FILENO.
// Called by kstdio_initialize().
static void __initialize_stdout(void)
{
    int slot=-1;
    int fd = STDOUT_FILENO;

// stdout
// pega slot em file_table[] para stdout

    slot = get_free_slots_in_the_file_table();
    if ( slot < 0 || slot >= NUMBER_OF_FILES ){
        x_panic("__initialize_stdout: slot");
    }
    stdout = (file *) file_table[slot];
    if ((void*) stdout == NULL){
        x_panic("__initialize_stdout: stdout");
    }
    stdout->filetable_index = slot;

// fd
    stdout->_file = fd;  //1

// This is a virtual console.
// Configurando a estrutura de stdout.
// This is a virtual console device. Used to output
// directly into the virtual console.
// It is a device.

    stdout->____object = ObjectTypeVirtualConsole;
    stdout->isDevice = TRUE;

// sync
    stdout->sync.sender_pid = (pid_t) -1;
    stdout->sync.receiver_pid = (pid_t) -1;

//
// ------------------------------------------------------------
//  STDOUT — Kernel‑level Permission Flags
//
//  Default behavior:
//      - Readable and writable by userland.
//      - Bound to a virtual console TTY.
//      - sys_write(fd=1) always allowed.
//
//  can_read:
//      TRUE  → sys_read() allowed (rarely used).
//
//  can_write:
//      TRUE  → sys_write() allowed (printf, puts, etc.).
//
//  can_execute / can_accept / can_connect:
//      Usually FALSE for stdout.
// ------------------------------------------------------------

    stdout->sync.can_read = TRUE;
    stdout->sync.can_write = TRUE;
    stdout->sync.can_execute = FALSE;
    stdout->sync.can_accept  = FALSE;
    stdout->sync.can_connect = FALSE;
// _flags
    stdout->_flags = (__SWR | __SRD); 

// buffer
    stdout->_base = &prompt_out[0];  //See: kstdio.h
    stdout->_p = &prompt_out[0];
    stdout->_bf._base = stdout->_base;
    stdout->_lbfsize = PROMPT_SIZE; //128; //#todo
    stdout->_r = 0;
    stdout->_w = 0;
    stdout->_cnt = PROMPT_SIZE;
    stdout->_tmpfname = "KSTDOUT DEV";
    stdout->fd_counter = 1;
    // ...
    // inode support.
    // pega slot em inode_table[] 
    slot = get_free_slots_in_the_inode_table();
    if (slot<0 || slot >=NUMBER_OF_FILES){
        x_panic("__initialize_stdout: stdout inode slot\n");
    }
    stdout->inode = (struct inode_d *) inode_table[slot];
    stdout->inodetable_index = slot;
    if ( (void*) stdout->inode == NULL ){
        x_panic("__initialize_stdout: stdout inode struct\n");
    }
    stdout->inode->filestruct_counter = 1; //inicialize

// Copy the name
    memcpy( 
        (void*)       stdout->inode->path, 
        (const void*) stdout->_tmpfname, 
              sizeof( stdout->inode->path ) );

    // #test
    // Waiting lists
    stdout->writer_head = NULL;
    stdout->reader_head = NULL;

    stdout->used = TRUE;
    stdout->magic = 1234;
}

// #warning
// Because the libc has hardcoded file descriptor values for the
// standard streams, we gotta use the same values.
// So, this way we need to use the same file descriptors.
// We're gonna use STDERR_FILENO.
// Called by kstdio_initialize().
static void __initialize_stderr(void)
{
    int fd = STDERR_FILENO;
    int slot = -1;

// stderr
// pega slot em file_table[] para stderr

    slot = get_free_slots_in_the_file_table();
    if ( slot < 0 || slot >= NUMBER_OF_FILES ){
        x_panic("__initialize_stderr: slot");
    }
    stderr = (file *) file_table[slot];
    if ((void*) stderr == NULL){
        x_panic("__initialize_stderr: stderr");
    }
    stderr->filetable_index = slot;

// fd
    stderr->_file = fd;  //2
// This is a regular file.
    stderr->____object = ObjectTypeVirtualConsole;
    stderr->isDevice = TRUE;

// sync
    stderr->sync.sender_pid = (pid_t) -1;
    stderr->sync.receiver_pid = (pid_t) -1;

//
// ------------------------------------------------------------
//  STDERR — Kernel‑level Permission Flags
//
//  Default behavior:
//      - Readable and writable.
//      - Bound to the same TTY as stdout.
//      - Used for diagnostics and error messages.
//
//  can_read:
//      TRUE  → sys_read() allowed.
//
//  can_write:
//      TRUE  → sys_write() allowed (fprintf(stderr, ...)).
//
//  Other flags (execute, accept, connect) remain FALSE.
// ------------------------------------------------------------

    stderr->sync.can_read    = TRUE;
    stderr->sync.can_write   = TRUE;
    stderr->sync.can_execute = FALSE;
    stderr->sync.can_accept  = FALSE;
    stderr->sync.can_connect = FALSE;
// _flags
    stderr->_flags = (__SWR | __SRD); 
// buffer
    stderr->_base = &prompt_err[0];  //See: kstdio.h
    stderr->_p = &prompt_err[0];
    stderr->_bf._base = stderr->_base;
    stderr->_lbfsize = PROMPT_SIZE; //128; //#todo
    stderr->_r = 0;
    stderr->_w = 0;
    stderr->_cnt = PROMPT_SIZE;
    stderr->_tmpfname = "KSTDERR TXT";
    stderr->fd_counter = 1;
    // ...
    // inode support.
    // pega slot em inode_table[] 
    slot = get_free_slots_in_the_inode_table();
    if (slot<0 || slot >=NUMBER_OF_FILES){
        x_panic("__initialize_stderr: stderr inode slot\n");
    }
    stderr->inode = (struct inode_d *) inode_table[slot];
    stderr->inodetable_index = slot;
    if ((void*) stderr->inode == NULL){
        x_panic("__initialize_stderr: stderr inode struct\n");
    }
    stderr->inode->filestruct_counter = 1; //inicialize

// Copy the name
    memcpy ( 
        (void*)       stderr->inode->path, 
        (const void*) stderr->_tmpfname, 
              sizeof( stderr->inode->path ) );

    // #test
    // Waiting lists
    stderr->writer_head = NULL;
    stderr->reader_head = NULL;

    stderr->used = TRUE;
    stderr->magic = 1234;
}

// Os buffers dos arquivos acima.
// prompt[]
// Esses prompts são usados como arquivos.
// São buffers para as streams.
// See: kstdio.h
static void __clear_prompt_buffers(void)
{
    register int i=0;

    for (i=0; i<PROMPT_SIZE; i++)
    {
        prompt[i] = (char) '\0';
        //prompt_in[i] = (char) '\0';  //#todo #maybe
        prompt_out[i] = (char) '\0';
        prompt_err[i] = (char) '\0';
    };
    prompt_pos = 0;
}

// Create n files and put the pointer into the file table.
// #todo
// We need a structure to track te information
// about the file table. file_table[],
// maybe FileTableInfo.xxxx.

static void __initialize_file_table(void)
{
    file *tmp_fp;
    register int i=0;

    FileTableInfo.initialized = FALSE;
    FileTableInfo.size = (int) NUMBER_OF_FILES;

    for (i=0; i<NUMBER_OF_FILES; i++)
    {
        tmp_fp = (void*) kmalloc(sizeof(file));
        if ((void*)tmp_fp == NULL){
           x_panic("__initialize_file_table: tmp_fp\n");
        }
        memset( tmp_fp, 0, sizeof(struct file_d) );

        tmp_fp->____object = ObjectTypeFile;  // Regular file.
        tmp_fp->_flags = 0;                   // (__SWR | __SRD); 
        tmp_fp->fd_counter = 0;
        tmp_fp->_tmpfname = NULL;
        //...
        tmp_fp->used = TRUE;
        tmp_fp->magic = 1234;
        file_table[i] = (unsigned long) tmp_fp;
    };

    FileTableInfo.initialized = TRUE;
}

// Create n inodes and put the pointers into the inode table
static void __initialize_inode_table(void)
{
    struct inode_d *tmp_inode;
    register int i=0;

    for (i=0; i<32; i++)
    {
        tmp_inode = (void*) kmalloc(sizeof(struct inode_d));
        if ((void*)tmp_inode == NULL){
            x_panic("__initialize_inode_table: tmp_inode\n");
        }
        memset( tmp_inode, 0, sizeof(struct inode_d) );

        tmp_inode->filestruct_counter = 0;
        tmp_inode->path[0] = 0;
        //...
        tmp_inode->used = TRUE;
        tmp_inode->magic = 1234;
        inode_table[i] = (unsigned long) tmp_inode; 
    };
}


//
// #
// INITIALIZATION
//

// kstdio_initialize:
// In this routine:
// + Initializing the structures for stdin, stdout and stderr.
// #ps: 
// This is necessary for the full initialization of printk.
// But, at this moment we already have a weak support for printk
// because of the early initialization of the consoles.
// but now we will make the full initialization of the consoles.
// #ps: who is calling it?

int kstdio_initialize(void)
{
    PROGRESS("kstdio_initialize:\n");

    kstdio_standard_streams_initialized = FALSE;
    errno = 0;  // Last registered error

// #bugbug
// We have another definition of input mode.
// A global io structure.

    g_inputmode = INPUT_MODE_MULTIPLE_LINES;

    kstdio_info.kstdio_in_terminalmode = TRUE;
    kstdio_info.kstdio_in_verbosemode = TRUE;

// Buffers used by the standard stream.
// Initialize the global file table.
// Initialize the global inode table.
    __clear_prompt_buffers();
    __initialize_file_table();
    __initialize_inode_table();

// Initializing the file pointers
// stdio, stdout and stderr.
// See: kstdio.h

// Create standard stream.
    __initialize_stdin();
    __initialize_stdout();
    __initialize_stderr();

// Virtual consoles.
// The standard streams was initialized first 
// because we're gonna need them now.
// see: console.c

    VirtualConsole_initialization();

    kstdio_standard_streams_initialized = TRUE;  // Done

    //PROGRESS("BREAKPOINT\n");
    //while(1){}

    return TRUE;

//fail:
    //return FALSE;
}

